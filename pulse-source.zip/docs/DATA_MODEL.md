# Data model

The book lives as CSVs in `data/`, loaded into an in-memory DuckDB at startup (`app/db.py`). They stand
in for STORM's warehouse tables; the column names are chosen to be what those tables plausibly are.
Everything is anchored to `meta.as_of` (2026-09-13) — the SQL uses `as_of()`, never `current_date`.

| Table | Rows | What it is |
|---|---|---|
| `rms` | 6 | RM id, name, region, tenure |
| `clients` | 240 | segment (Affluent / HNI / UHNI), risk profile, IPS equity target, city, age, occupation, onboarded_on, last_review_on, KYC status, engagement tier |
| `holdings` | ~4,300 | one row per position: asset_class, instrument, category (Large Cap, ELSS, Liquid…), sector (stocks), invested_value, current_value, purchase_date, lock_in_until, is_equity |
| `cash_snapshots` | 2,880 | weekly ledger balance per client, 12 weeks — the wealth-account idle cash |
| `sips` | ~320 | monthly SIPs: amount, dates, mandate_expiry, last_debit_status, next_due |
| `transactions` | ~9,000 | buys, SIP debits, redemptions, switches, PMS subscriptions, AIF drawdowns, FD bookings; channel (App / RM-assisted / Web) |
| `interactions` | ~1,700 | RM ↔ client touches: channel, summary, outcome, next_action, product_id when a product was discussed |
| `app_events` | ~20,000 | client-app analytics: app_open, view_portfolio, view_product (with product_id), view_withdraw, initiate_redeem, ask_ai, onb_* onboarding steps… |
| `products` | 10 | the exclusive shelf: PMS / AIF / unlisted, min_ticket, suitable_for (risk profiles), status, closes_on |
| `meta` | 1 | as_of, generator seed |

Derived at load (`app/db.py`): `v_client_aum` (AUM, invested, equity %, cash), `v_last_contact`,
`v_mid_onboarding`, and the `signals` table produced by the engine plus `v_client_priority`.

## Planted stories and base rates

`scripts/generate_data.py` assigns each client a set of flags with these probabilities, then generates
holdings, events and cash so the story is *true in the data* — the SQL has to find it.

| Story | Base rate | What the generator does |
|---|---|---|
| Idle cash | 18% | cash 8–30% of AUM, flat for 12 weeks |
| Liquidity event | 4% | ledger jumps by ₹20 L–₹8 Cr (by segment) 0–2 weeks ago |
| Concentration | 12% (+35% of tech professionals, +20% of promoters) | one stock 22–55% of AUM |
| Allocation drift | 15% | equity share 15–28 pts off the IPS target |
| SIP at risk | 10% of SIP holders | mandate expiring / failed debit / SIP ending |
| Lock-in / maturity | 12% | an ELSS, PMS or FD maturing −5…+28 days |
| Churn | 8% | withdraw/redeem screens in 14 days; 55% also redeem 5–18% of AUM, *after* the warning |
| Engagement drop | 6% | app opens fall to ~15% of the prior rate |
| Buy intent | 9% | 2–5 views of one eligible product in 10 days; last contact ≥ 8 days |
| Onboarding stuck | 3.5% | new client, mostly cash/FD, stalled at a step (55% bank e-mandate) |
| Tax harvest | 12% | 1–2 positions at 55–78% of cost |
| Product interest | 10% | one view of a closing-soon product, or an RM deck-share |
| Fund overlap | 14% (+50% of inheritors) | 4–6 funds in one category |

Everything else is background: engagement tiers (high 25 / medium 40 / low 25 / dormant 10), a
contact-recency mixture (55% within 30 days, 25% 31–60, 20% 61–150), returns drawn per category with a
geometric model, 76 historical onboarding journeys (56% completed) for funnel volume.

The generator is seeded; running it again produces identical files.
