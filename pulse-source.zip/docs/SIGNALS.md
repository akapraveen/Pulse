# Signal catalog

Generated from `app/engine.py` by `scripts/build_signal_docs.py` — edit the code, not this file.

Every signal is one SQL file in `app/signals/` that returns, per client:

```
client_id, impact_inr, urgency (0-1), deadline_on (nullable DATE), ...evidence columns
```

The engine scores each row as **expected value = impact_inr × conversion prior × urgency** and sums per client.
The Morning Brief ranks clients by that sum; the RM sees the top 10 (`daily_capacity_per_rm`).

## Global assumptions

| Knob | Value | Why |
|---|---|---|
| Blended fee rate | 0.8% | revenue ≈ AUM × fee (MF trail + PMS/AIF fees, blended) — for the 'revenue impact' lens only |
| Churn attrition if ignored | 30% | share of AUM assumed lost when a churn signal goes unaddressed |
| Idle-cash yield gap | 3.8% | savings/current account vs liquid fund |
| Daily capacity per RM | 10 | meaningful conversations an RM can have in a day |

## Priors — assumptions to be measured

Conversion priors are my starting estimates of how often an RM action on each signal type produces an outcome. They are deliberately rough. The Morning Brief's Done / Snooze / Not relevant buttons log outcomes per signal type; after the pilot, priors and thresholds are re-fit monthly from those outcomes.

## Opportunity

### ⚡ Liquidity event · `liquidity_event`

Cash balance jumped 2.5×+ in three weeks — proceeds just landed and every bank is calling.

| | |
|---|---|
| Fires when | Latest balance ≥ ₹25 L, up ≥ ₹20 L and ≥ 2.5× vs 3 weeks ago |
| ₹ in play | the inflow amount |
| Urgency | 1.0 if it landed this week, 0.85 last week, 0.7 before |
| Conversion prior | 45% |
| RM playbook | Call within 24h. Ask what the money is earmarked for; propose a parking + phased deployment plan. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- LIQUIDITY EVENT
-- Cash balance jumped 2.5x+ (and >= ₹20 L) versus three weeks ago: a bonus, ESOP sale,
-- property or business proceeds just landed. The client is deciding where it goes *this week* -
-- and every bank they hold an account with is calling.
WITH snaps AS (
    SELECT client_id, as_of, ledger_balance,
           LAG(ledger_balance, 1) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_1w_ago,
           LAG(ledger_balance, 2) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_2w_ago,
           LAG(ledger_balance, 3) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_3w_ago,
           ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY as_of DESC)      AS rn
    FROM cash_snapshots
),
latest AS (
    SELECT *, ledger_balance - bal_3w_ago AS inflow_inr,
           CASE WHEN ledger_balance - bal_1w_ago >= 0.8 * (ledger_balance - bal_3w_ago) THEN 'this week'
                WHEN ledger_balance - bal_2w_ago >= 0.8 * (ledger_balance - bal_3w_ago) THEN 'last week'
                ELSE '2 weeks ago' END AS landed
    FROM snaps WHERE rn = 1
)
SELECT
    client_id,
    inflow_inr                                                              AS impact_inr,
    CASE landed WHEN 'this week' THEN 1.0 WHEN 'last week' THEN 0.85 ELSE 0.7 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    ledger_balance                                                          AS current_cash,
    bal_3w_ago                                                              AS cash_3w_ago,
    inflow_inr,
    landed
FROM latest
WHERE ledger_balance >= 2500000
  AND inflow_inr >= 2000000
  AND ledger_balance >= 2.5 * GREATEST(bal_3w_ago, 1)
ORDER BY impact_inr DESC
```

</details>

### 💤 Idle cash · `idle_cash`

₹10 L+ sitting in the wealth account for 6+ weeks, ≥5% of the book.

| | |
|---|---|
| Fires when | Balance ≥ ₹10 L, ≥ 5% of AUM, and its 6-week minimum ≥ 80% of today's |
| ₹ in play | the idle balance |
| Urgency | 0.8 if ≥ ₹50 L, else 0.6 |
| Conversion prior | 35% |
| RM playbook | Propose a liquid/arbitrage fund for the balance; agree a deployment plan for the rest. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- IDLE CASH
-- A large balance that has sat in the wealth account for 6+ weeks.
-- Money that isn't working costs the client ~3.5-4% a year vs a liquid/arbitrage fund,
-- and it is the cheapest AUM the firm can win: it's already here.
-- Clients mid-way through MF onboarding are excluded: that signal owns the conversation.
WITH latest AS (
    SELECT client_id, ledger_balance AS cash
    FROM cash_snapshots
    WHERE as_of = (SELECT MAX(as_of) FROM cash_snapshots)
),
six_weeks AS (
    SELECT client_id, MIN(ledger_balance) AS min_balance_6w
    FROM cash_snapshots
    WHERE as_of >= as_of() - INTERVAL 42 DAY
    GROUP BY client_id
)
SELECT
    l.client_id,
    l.cash                                              AS impact_inr,
    CASE WHEN l.cash >= 5000000 THEN 0.8 ELSE 0.6 END   AS urgency,
    NULL::DATE                                          AS deadline_on,
    l.cash                                              AS idle_cash,
    ROUND(100.0 * l.cash / a.aum, 1)                    AS pct_of_aum,
    6                                                   AS weeks_idle,
    ROUND(l.cash * 0.038)                               AS annual_drag_inr   -- ~3.8% yield gap vs a liquid fund
FROM latest l
JOIN six_weeks s USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE l.cash >= 1000000                                 -- at least ₹10 L
  AND s.min_balance_6w >= 0.8 * l.cash                  -- it has been sitting there, not just landed
  AND l.cash >= 0.05 * a.aum                            -- material relative to the book
  AND l.client_id NOT IN (SELECT client_id FROM v_mid_onboarding)
ORDER BY impact_inr DESC
```

</details>

### 👀 Buy intent · `buy_intent`

Repeated views of one exclusive product in 10 days, not invested, not yet discussed. Suitability-gated.

| | |
|---|---|
| Fires when | ≥ 2 views of one product in 10 days; not held; not discussed in 10 days; suitability + ticket gates |
| ₹ in play | a plausible first ticket: between 1× and 3× the minimum, bounded by cash + 10% of AUM |
| Urgency | 1.0 if last view ≤ 2 days ago, 0.8 ≤ 5 days, else 0.6 |
| Conversion prior | 40% |
| RM playbook | Send the factsheet with a 2-line note; offer a 15-min call with the fund manager's desk. |
| Shown to the client? | No — RM-only |

<details><summary>SQL</summary>

```sql
-- BUY INTENT
-- The client keeps opening one exclusive product (PMS / AIF / unlisted) in the app - 2+ views
-- in 10 days - hasn't invested in it, and the RM hasn't discussed it in the last 10 days.
-- Hard gates: suitability (risk profile) and ticket size (AUM >= 3x minimum) - never surface
-- a product the client can't or shouldn't buy. Products closing soon are handled by product_closing.
WITH views AS (
    SELECT client_id, product_id,
           COUNT(*)                     AS views_10d,
           COUNT(DISTINCT session_id)   AS sessions_10d,
           MAX(ts)                      AS last_view_ts
    FROM app_events
    WHERE event_name = 'view_product'
      AND product_id IS NOT NULL AND product_id <> ''
      AND ts >= as_of() - INTERVAL 10 DAY
    GROUP BY client_id, product_id
    HAVING COUNT(*) >= 2
),
ranked AS (
    SELECT v.*, ROW_NUMBER() OVER (PARTITION BY v.client_id ORDER BY v.views_10d DESC, v.last_view_ts DESC) AS rn
    FROM views v
    JOIN products p USING (product_id)
    WHERE p.status <> 'Closing Soon'
)
SELECT
    r.client_id,
    GREATEST(p.min_ticket, LEAST(a.cash + 0.10 * a.aum, 3 * p.min_ticket))  AS impact_inr,   -- plausible first ticket
    CASE WHEN datediff('day', r.last_view_ts::DATE, as_of()) <= 2 THEN 1.0
         WHEN datediff('day', r.last_view_ts::DATE, as_of()) <= 5 THEN 0.8 ELSE 0.6 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    r.product_id,
    p.name                                                                  AS product_name,
    p.type                                                                  AS product_type,
    p.min_ticket,
    r.views_10d,
    r.sessions_10d,
    r.last_view_ts,
    lc.days_since_contact,
    a.cash                                                                  AS available_cash
FROM ranked r
JOIN products p USING (product_id)
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
LEFT JOIN v_last_contact lc USING (client_id)
WHERE r.rn = 1
  AND list_contains(string_split(p.suitable_for, '|'), c.risk_profile)          -- suitability gate
  AND a.aum >= 3 * p.min_ticket                                                 -- ticket-size gate
  AND NOT EXISTS (SELECT 1 FROM holdings h
                  WHERE h.client_id = r.client_id AND h.instrument = p.name)    -- not already invested
  AND NOT EXISTS (SELECT 1 FROM interactions i
                  WHERE i.client_id = r.client_id AND i.product_id = r.product_id
                    AND i.occurred_on >= as_of() - INTERVAL 10 DAY)             -- RM hasn't already discussed it
ORDER BY urgency DESC, r.views_10d DESC
```

</details>

### ⏳ Product closing · `product_closing`

A product the client showed interest in closes its window within 21 days.

| | |
|---|---|
| Fires when | Closing-soon product ≤ 21 days out; ≥ 2 app views in 30 days or an RM deck-share in 45; gates as above |
| ₹ in play | the product's minimum ticket |
| Urgency | 1.0 if ≤ 7 days to close, 0.8 ≤ 14, else 0.6 |
| Conversion prior | 30% |
| RM playbook | Confirm interest today; walk through the term sheet and the drawdown timeline before the close. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- PRODUCT CLOSING
-- An exclusive product the client has shown real interest in (2+ in-app views in 30 days, or an RM
-- shared the deck in the last 45 days) closes its window within 21 days. Same suitability and
-- ticket-size gates as buy_intent. Impact = minimum ticket.
WITH closing AS (
    SELECT * FROM products
    WHERE status = 'Closing Soon'
      AND closes_on BETWEEN as_of() AND as_of() + INTERVAL 21 DAY
),
interest AS (
    SELECT client_id, product_id, ts AS seen_at, 'app_view' AS source
    FROM app_events
    WHERE event_name = 'view_product' AND ts >= as_of() - INTERVAL 30 DAY
    UNION ALL
    SELECT client_id, product_id, occurred_on::TIMESTAMP, 'rm_shared_deck'
    FROM interactions
    WHERE product_id IS NOT NULL AND product_id <> '' AND occurred_on >= as_of() - INTERVAL 45 DAY
),
candidates AS (
    SELECT i.client_id, p.product_id, p.name AS product_name, p.type AS product_type, p.min_ticket, p.closes_on,
           p.suitable_for, MAX(i.seen_at) AS last_interest_at, COUNT(*) AS interest_touches,
           COUNT(*) FILTER (WHERE i.source = 'rm_shared_deck') AS rm_touches,
           ROW_NUMBER() OVER (PARTITION BY i.client_id ORDER BY p.closes_on) AS rn
    FROM interest i
    JOIN closing p USING (product_id)
    GROUP BY 1, 2, 3, 4, 5, 6, 7
    HAVING COUNT(*) >= 2 OR COUNT(*) FILTER (WHERE i.source = 'rm_shared_deck') >= 1   -- one stray tap isn't interest
)
SELECT
    k.client_id,
    k.min_ticket                                                            AS impact_inr,
    CASE WHEN datediff('day', as_of(), k.closes_on) <= 7 THEN 1.0
         WHEN datediff('day', as_of(), k.closes_on) <= 14 THEN 0.8 ELSE 0.6 END AS urgency,
    k.closes_on                                                             AS deadline_on,
    k.product_id,
    k.product_name,
    k.product_type,
    k.min_ticket,
    datediff('day', as_of(), k.closes_on)                                   AS days_to_close,
    k.interest_touches,
    k.rm_touches,
    k.last_interest_at
FROM candidates k
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE k.rn = 1
  AND list_contains(string_split(k.suitable_for, '|'), c.risk_profile)
  AND a.aum >= 3 * k.min_ticket
  AND NOT EXISTS (SELECT 1 FROM holdings h WHERE h.client_id = k.client_id AND h.instrument = k.product_name)
ORDER BY urgency DESC, impact_inr DESC
```

</details>

### 🔓 Lock-in / maturity · `lockin_maturity`

ELSS lock-ins, PMS exit-load windows and FDs maturing in the next 30 days (or last 7).

| | |
|---|---|
| Fires when | lock_in_until between 7 days ago and 30 days ahead |
| ₹ in play | the maturing value |
| Urgency | 0.9 if ≤ 7 days, 0.75 ≤ 14, else 0.55 |
| Conversion prior | 40% |
| RM playbook | Reach out a week before maturity with a re-deployment option; pre-empt the bank's FD renewal call. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- LOCK-IN / MATURITY
-- Money about to come free: ELSS lock-ins ending, PMS exit-load windows closing,
-- FDs maturing (last 7 days to next 30). The natural moment for a re-deployment conversation
-- and the moment competitor banks call about the FD.
WITH maturing AS (
    SELECT client_id, instrument, asset_class, category, current_value, lock_in_until,
           datediff('day', as_of(), lock_in_until) AS days_to_maturity
    FROM holdings
    WHERE lock_in_until IS NOT NULL
      AND lock_in_until BETWEEN as_of() - INTERVAL 7 DAY AND as_of() + INTERVAL 30 DAY
)
SELECT
    client_id,
    SUM(current_value)                                                       AS impact_inr,
    CASE WHEN MIN(days_to_maturity) <= 7 THEN 0.9
         WHEN MIN(days_to_maturity) <= 14 THEN 0.75 ELSE 0.55 END            AS urgency,
    MIN(lock_in_until)                                                       AS deadline_on,
    COUNT(*)                                                                 AS holdings_maturing,
    string_agg(instrument || ' (' || asset_class || ')', '; ' ORDER BY lock_in_until) AS instruments,
    MIN(days_to_maturity)                                                    AS days_to_maturity,
    SUM(current_value)                                                       AS maturing_value
FROM maturing
GROUP BY client_id
ORDER BY urgency DESC, impact_inr DESC
```

</details>

### 🧱 Onboarding stuck · `onboarding_stuck`

Started MF onboarding in the app, stalled 48h+ at a step (usually the e-mandate).

| | |
|---|---|
| Fires when | Last onb_* step ≠ complete, ≥ 48h old, within 30 days |
| ₹ in play | typical first MF ticket by segment (₹5 L / ₹15 L / ₹50 L) |
| Urgency | 0.9 if stuck ≤ 4 days, 0.7 ≤ 10, else 0.5 |
| Conversion prior | 45% |
| RM playbook | Call and unblock the exact step; screen-share if needed. Most stalls are the e-NACH bank page. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- ONBOARDING STUCK
-- Started MF onboarding in the app, hasn't finished, and the last step is 48h+ old
-- (within the last 30 days). The step they stalled on tells the RM exactly what to unblock -
-- almost always the e-mandate. Impact = the segment's typical first MF ticket.
WITH steps AS (
    SELECT client_id, session_id, event_name, ts,
           ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY ts DESC) AS rn
    FROM app_events
    WHERE event_name LIKE 'onb_%'
),
latest AS (
    SELECT client_id, session_id, event_name AS last_step, ts AS last_step_at
    FROM steps WHERE rn = 1
),
journey AS (
    SELECT l.client_id, l.last_step, l.last_step_at, MIN(s.ts) AS started_at,
           datediff('hour', l.last_step_at, as_of()::TIMESTAMP + INTERVAL 23 HOUR) AS hours_stuck
    FROM latest l
    JOIN steps s ON s.client_id = l.client_id AND s.session_id = l.session_id
    GROUP BY 1, 2, 3
)
SELECT
    j.client_id,
    CASE c.segment WHEN 'UHNI' THEN 5000000 WHEN 'HNI' THEN 1500000 ELSE 500000 END AS impact_inr,
    CASE WHEN j.hours_stuck <= 96 THEN 0.9 WHEN j.hours_stuck <= 240 THEN 0.7 ELSE 0.5 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    j.last_step,
    j.last_step_at,
    j.started_at,
    j.hours_stuck,
    a.cash                                                                  AS parked_cash
FROM journey j
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE j.last_step <> 'onb_complete'
  AND j.hours_stuck >= 48
  AND j.last_step_at >= as_of() - INTERVAL 30 DAY
ORDER BY urgency DESC, impact_inr DESC
```

</details>

## Retention

### 🚨 Churn risk · `churn_risk`

Withdraw/redeem screens in the last 14 days, or app usage collapsing — and no RM contact for 3+ weeks.

| | |
|---|---|
| Fires when | Withdraw/redeem screens in 14 days, or opens ≤ 40% of prior-month rate; and no contact > 21 days |
| ₹ in play | AUM × 30% assumed attrition |
| Urgency | 1.0 if a redemption was initiated/completed, 0.8 if withdraw viewed, else 0.6 |
| Conversion prior | 30% |
| RM playbook | Call today, no agenda. Listen for the trigger (service issue, competitor, need for funds) before proposing anything. |
| Shown to the client? | No — RM-only |

<details><summary>SQL</summary>

```sql
-- CHURN RISK
-- Behavioural early warning from the client app: withdraw/redeem screens in the last 14 days,
-- or app usage collapsing to <40% of the prior month's rate - and no RM contact for 3+ weeks.
-- Impact = AUM at risk, discounted by an assumed 30% attrition if unaddressed.
WITH activity AS (
    SELECT client_id,
           COUNT(*) FILTER (WHERE event_name IN ('view_withdraw', 'initiate_redeem')
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS withdraw_events_14d,
           COUNT(*) FILTER (WHERE event_name = 'initiate_redeem'
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS redeem_initiated_14d,
           COUNT(*) FILTER (WHERE event_name = 'app_open'
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS opens_last_14d,
           COUNT(*) FILTER (WHERE event_name = 'app_open'
                              AND ts >= as_of() - INTERVAL 42 DAY
                              AND ts <  as_of() - INTERVAL 14 DAY) / 2.0                AS opens_prior_14d_avg
    FROM app_events
    GROUP BY client_id
),
redemptions AS (
    SELECT client_id, SUM(amount) AS redeemed_30d
    FROM transactions
    WHERE txn_type = 'Redeem' AND status = 'Completed' AND txn_date >= as_of() - INTERVAL 30 DAY
    GROUP BY client_id
)
SELECT
    e.client_id,
    a.aum * 0.30                                                            AS impact_inr,
    CASE WHEN e.redeem_initiated_14d > 0 OR COALESCE(r.redeemed_30d, 0) > 0 THEN 1.0
         WHEN e.withdraw_events_14d > 0 THEN 0.8 ELSE 0.6 END               AS urgency,
    NULL::DATE                                                              AS deadline_on,
    CASE WHEN e.withdraw_events_14d > 0 THEN 'withdraw_intent' ELSE 'engagement_drop' END AS trigger,
    e.withdraw_events_14d,
    e.redeem_initiated_14d,
    e.opens_last_14d,
    ROUND(e.opens_prior_14d_avg, 1)                                         AS opens_prior_14d_avg,
    COALESCE(r.redeemed_30d, 0)                                             AS redeemed_30d,
    lc.days_since_contact
FROM activity e
JOIN v_client_aum a USING (client_id)
LEFT JOIN v_last_contact lc USING (client_id)
LEFT JOIN redemptions r USING (client_id)
WHERE (e.withdraw_events_14d >= 1
       OR (e.opens_prior_14d_avg >= 3 AND e.opens_last_14d <= 0.4 * e.opens_prior_14d_avg))
  AND COALESCE(lc.days_since_contact, 999) > 21
ORDER BY urgency DESC, impact_inr DESC
```

</details>

### 🔁 SIP at risk · `sip_at_risk`

A failed debit, an e-mandate expiring within 30 days, or a SIP ending within 45 days.

| | |
|---|---|
| Fires when | Failed debit, mandate expiring ≤ 30 days, or SIP ending ≤ 45 days |
| ₹ in play | 12 × affected monthly SIP amount |
| Urgency | 1.0 if ≤ 7 days, 0.8 ≤ 14, 0.6 ≤ 30, else 0.45 |
| Conversion prior | 55% |
| RM playbook | WhatsApp the one-tap mandate renewal link; for failed debits, check balance/limit and re-trigger. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- SIP AT RISK
-- Recurring flows about to stop: a failed debit, an e-mandate expiring within 30 days,
-- or a SIP reaching its end date within 45 days. Impact = 12 months of the affected SIPs.
WITH at_risk AS (
    SELECT sip_id, client_id, instrument, amount,
           CASE WHEN last_debit_status = 'Failed'                          THEN 'debit_failed'
                WHEN mandate_expiry <= as_of() + INTERVAL 30 DAY           THEN 'mandate_expiring'
                WHEN end_date       <= as_of() + INTERVAL 45 DAY           THEN 'sip_ending' END AS reason,
           CASE WHEN last_debit_status = 'Failed'                          THEN 0
                WHEN mandate_expiry <= as_of() + INTERVAL 30 DAY           THEN datediff('day', as_of(), mandate_expiry)
                ELSE datediff('day', as_of(), end_date) END               AS days_left
    FROM sips
    WHERE status = 'Active'
      AND (last_debit_status = 'Failed'
           OR mandate_expiry <= as_of() + INTERVAL 30 DAY
           OR end_date <= as_of() + INTERVAL 45 DAY)
)
SELECT
    client_id,
    SUM(amount) * 12                                                         AS impact_inr,
    CASE WHEN MIN(days_left) <= 7 THEN 1.0 WHEN MIN(days_left) <= 14 THEN 0.8
         WHEN MIN(days_left) <= 30 THEN 0.6 ELSE 0.45 END                     AS urgency,
    as_of() + to_days(MIN(days_left)::INTEGER)                               AS deadline_on,
    COUNT(*)                                                                 AS sips_affected,
    SUM(amount)                                                              AS monthly_amount,
    string_agg(DISTINCT reason, ', ')                                        AS reasons,
    MIN(days_left)                                                           AS days_left,
    string_agg(instrument, '; ')                                             AS instruments
FROM at_risk
GROUP BY client_id
ORDER BY urgency DESC, impact_inr DESC
```

</details>

## Portfolio health

### 🎯 Concentration risk · `concentration_risk`

One security above 20% of total AUM (ESOPs, promoter stakes, inherited blocks).

| | |
|---|---|
| Fires when | Largest single listed/unlisted security ≥ 20% of AUM |
| ₹ in play | the amount above a 10% ceiling |
| Urgency | 0.7 if ≥ 35% of AUM, else 0.5 |
| Conversion prior | 20% |
| RM playbook | Propose a phased diversification plan (tax-aware, over 4-6 quarters); never 'sell it all'. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- CONCENTRATION RISK
-- A single listed or unlisted security above 20% of the client's total AUM
-- (ESOPs, promoter stakes, inherited blocks). Impact = the amount above a 10% single-name ceiling.
WITH positions AS (
    SELECT h.client_id, h.instrument, h.sector, h.asset_class, h.current_value, a.aum,
           100.0 * h.current_value / a.aum AS pct_of_aum,
           ROW_NUMBER() OVER (PARTITION BY h.client_id ORDER BY h.current_value DESC) AS rn
    FROM holdings h
    JOIN v_client_aum a USING (client_id)
    WHERE h.asset_class IN ('Direct Equity', 'Unlisted')
)
SELECT
    client_id,
    current_value - 0.10 * aum                            AS impact_inr,
    CASE WHEN pct_of_aum >= 35 THEN 0.7 ELSE 0.5 END      AS urgency,
    NULL::DATE                                            AS deadline_on,
    instrument,
    sector,
    asset_class,
    ROUND(pct_of_aum, 1)                                  AS pct_of_aum,
    current_value                                         AS position_value
FROM positions
WHERE rn = 1 AND pct_of_aum >= 20
ORDER BY impact_inr DESC
```

</details>

### ⚖️ Allocation drift · `allocation_drift`

Invested equity share 12+ points away from the IPS target.

| | |
|---|---|
| Fires when | |invested equity % − IPS target| ≥ 12 points |
| ₹ in play | the amount to move to get back to target |
| Urgency | 0.6 if ≥ 20 points, else 0.45 |
| Conversion prior | 30% |
| RM playbook | Share a one-page rebalance proposal; frame it as sticking to the plan the client signed off. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- ALLOCATION DRIFT
-- Invested equity share vs the client's IPS target. Measured on invested assets only,
-- so parked cash is handled by the idle-cash signal and this one owns the *mix*.
-- 12 points of drift is the review threshold; 20+ is a rebalance conversation.
SELECT
    a.client_id,
    ABS(a.equity_pct_invested - c.ips_equity_target) / 100.0 * a.invested_aum   AS impact_inr,   -- amount to move
    CASE WHEN ABS(a.equity_pct_invested - c.ips_equity_target) >= 20 THEN 0.6 ELSE 0.45 END AS urgency,
    NULL::DATE                                                                  AS deadline_on,
    ROUND(a.equity_pct_invested, 1)                                             AS actual_equity_pct,
    c.ips_equity_target                                                         AS target_equity_pct,
    ROUND(a.equity_pct_invested - c.ips_equity_target, 1)                       AS drift_pts,
    CASE WHEN a.equity_pct_invested > c.ips_equity_target THEN 'over' ELSE 'under' END AS direction,
    c.risk_profile
FROM v_client_aum a
JOIN clients c USING (client_id)
WHERE a.invested_aum > 0
  AND ABS(a.equity_pct_invested - c.ips_equity_target) >= 12
  AND a.client_id NOT IN (SELECT client_id FROM v_mid_onboarding)
ORDER BY impact_inr DESC
```

</details>

### 🧩 Fund overlap · `fund_overlap`

4+ equity funds in one category (or 9+ overall) — the same stocks bought several times over.

| | |
|---|---|
| Fires when | ≥ 4 equity funds in one category, or ≥ 3 with ≥ 9 equity funds overall |
| ₹ in play | everything in the crowded category except its largest fund |
| Urgency | 0.4 flat |
| Conversion prior | 25% |
| RM playbook | Show the overlap; propose consolidating into the best 1-2 funds in the category. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- FUND OVERLAP
-- Four or more equity funds in the same category (or 9+ equity funds overall): the same
-- underlying stocks bought several times over, with several expense ratios.
-- Impact = everything in the crowded category except its largest fund (the consolidation amount).
WITH by_category AS (
    SELECT client_id, category,
           COUNT(*)                                            AS funds_in_category,
           SUM(current_value)                                  AS category_value,
           SUM(current_value) - MAX(current_value)             AS consolidatable_value,
           string_agg(instrument, '; ' ORDER BY current_value DESC) AS funds
    FROM holdings
    WHERE asset_class = 'Equity MF'
    GROUP BY client_id, category
),
totals AS (
    SELECT client_id, COUNT(*) AS equity_funds
    FROM holdings WHERE asset_class = 'Equity MF' GROUP BY client_id
),
crowded AS (
    SELECT b.*, t.equity_funds,
           ROW_NUMBER() OVER (PARTITION BY b.client_id ORDER BY b.funds_in_category DESC, b.category_value DESC) AS rn
    FROM by_category b
    JOIN totals t USING (client_id)
    WHERE b.funds_in_category >= 4 OR (b.funds_in_category >= 3 AND t.equity_funds >= 9)
)
SELECT
    client_id,
    consolidatable_value                                                    AS impact_inr,
    0.4                                                                     AS urgency,
    NULL::DATE                                                              AS deadline_on,
    category                                                                AS crowded_category,
    funds_in_category,
    category_value,
    consolidatable_value,
    equity_funds                                                            AS total_equity_funds,
    funds
FROM crowded
WHERE rn = 1
ORDER BY impact_inr DESC
```

</details>

### 🧾 Tax-loss harvest · `tax_harvest`

Unrealised equity losses (≥₹2 L) that could offset realised gains this FY.

| | |
|---|---|
| Fires when | Unrealised equity losses ≥ ₹1.5 L per position, ≥ ₹5 L and ≥ 1.5% of AUM in total |
| ₹ in play | the harvestable loss |
| Urgency | 0.9 within 45 days of 31 March, 0.7 within 90, else 0.35 |
| Conversion prior | 30% |
| RM playbook | Coordinate with the client's CA; harvest and redeploy into a like-for-like fund the same day. |
| Shown to the client? | Yes — as an insight card in the client app |

<details><summary>SQL</summary>

```sql
-- TAX-LOSS HARVEST
-- Equity positions on unrealised losses (>= ₹1.5 L each) that add up to something material -
-- at least ₹5 L and 1.5% of the book - and could offset realised gains this FY.
-- Urgency climbs as 31 March approaches.
WITH fy_end AS (
    SELECT make_date(year(as_of()) + CASE WHEN month(as_of()) > 3 THEN 1 ELSE 0 END, 3, 31) AS fy_end_on
),
losses AS (
    SELECT client_id, instrument, asset_class, invested_value, current_value,
           invested_value - current_value                 AS unrealised_loss,
           datediff('day', purchase_date, as_of())        AS holding_days
    FROM holdings
    WHERE asset_class IN ('Equity MF', 'Direct Equity')
      AND invested_value - current_value >= 150000
)
SELECT
    l.client_id,
    SUM(l.unrealised_loss)                                                  AS impact_inr,
    CASE WHEN datediff('day', as_of(), f.fy_end_on) <= 45 THEN 0.9
         WHEN datediff('day', as_of(), f.fy_end_on) <= 90 THEN 0.7 ELSE 0.35 END AS urgency,
    f.fy_end_on                                                             AS deadline_on,
    COUNT(*)                                                                AS positions,
    SUM(l.unrealised_loss)                                                  AS harvestable_loss,
    ROUND(SUM(CASE WHEN l.holding_days > 365 THEN l.unrealised_loss * 0.125
                   ELSE l.unrealised_loss * 0.20 END))                      AS est_tax_offset_inr,
    ROUND(100.0 * SUM(l.unrealised_loss) / a.aum, 1)                        AS pct_of_aum,
    string_agg(l.instrument || ' (-' || ROUND(l.unrealised_loss / 100000.0, 1) || ' L)', '; '
               ORDER BY l.unrealised_loss DESC)                             AS positions_detail
FROM losses l
JOIN v_client_aum a USING (client_id)
CROSS JOIN fy_end f
GROUP BY l.client_id, f.fy_end_on, a.aum
HAVING SUM(l.unrealised_loss) >= GREATEST(500000, 0.015 * a.aum)
ORDER BY impact_inr DESC
```

</details>

## Relationship

### 📅 Overdue review · `overdue_review`

No logged contact beyond the segment cadence (UHNI 35d / HNI 60d / Affluent 90d).

| | |
|---|---|
| Fires when | Days since last logged contact > cadence (UHNI 35 / HNI 60 / Affluent 90) |
| ₹ in play | 5% of AUM (relationship-risk proxy) |
| Urgency | 0.7 if ≥ 60 days over cadence, 0.55 ≥ 30, else 0.4 |
| Conversion prior | 15% |
| RM playbook | A short check-in call or a personal note with the portfolio summary; book the review. |
| Shown to the client? | No — RM-only |

<details><summary>SQL</summary>

```sql
-- OVERDUE REVIEW
-- Relationship hygiene: no logged RM contact beyond the segment's cadence
-- (UHNI 35 days, HNI 60, Affluent 90). Impact is a relationship-risk proxy (5% of AUM),
-- so the biggest silent books rise to the top rather than the longest silences.
WITH cadence AS (
    SELECT c.client_id, c.segment, c.last_review_on,
           CASE c.segment WHEN 'UHNI' THEN 35 WHEN 'HNI' THEN 60 ELSE 90 END AS threshold_days,
           COALESCE(lc.days_since_contact, 999)                              AS days_since_contact,
           lc.last_contact_on
    FROM clients c
    LEFT JOIN v_last_contact lc USING (client_id)
)
SELECT
    k.client_id,
    a.aum * 0.05                                                            AS impact_inr,
    CASE WHEN k.days_since_contact - k.threshold_days >= 60 THEN 0.7
         WHEN k.days_since_contact - k.threshold_days >= 30 THEN 0.55 ELSE 0.4 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    k.last_contact_on,
    k.days_since_contact,
    k.threshold_days,
    k.days_since_contact - k.threshold_days                                 AS days_over,
    k.last_review_on,
    datediff('day', k.last_review_on, as_of())                              AS days_since_review
FROM cadence k
JOIN v_client_aum a USING (client_id)
WHERE k.days_since_contact > k.threshold_days
ORDER BY impact_inr DESC
```

</details>

## False positives I expect, and what to do about them

- **Idle cash** — money earmarked for a known purchase (property, tax). Fix: an RM 'snooze until <date>' with a reason, and a client-set 'earmarked' flag in the app.
- **Churn risk** — a client checking the withdraw screen to *understand* it, not to leave. Fix: require intent + silence (already), and log 'Not relevant' reasons to tune the threshold.
- **Concentration** — promoter holdings that are structurally illiquid. Fix: an 'acknowledged concentration' flag on the IPS so it stops firing.
- **Overdue review** — contact happened but wasn't logged. Fix: this is a STORM data-quality metric in its own right; surface it to sales leadership.
- **Buy intent** — an RM already spoke about the product by phone without logging. Same fix as above; the 10-day interaction check is the guard.
