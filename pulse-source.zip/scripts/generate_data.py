#!/usr/bin/env python3
"""
Pulse — synthetic wealth-book generator.

Builds a realistic, deterministic HNI book for an Indian wealth firm: RMs, clients,
holdings, SIPs, transactions, RM interactions, client-app events, weekly cash
snapshots and the exclusive-product shelf.

Every "story" the signal engine is meant to detect (idle cash, allocation drift,
withdraw intent, buy intent, stuck onboarding, expiring lock-ins ...) is planted
here at a believable base rate, so the SQL has something true to find — and
plenty of clients where it should stay quiet.

Output: CSV files in data/ (human-readable, git-friendly). The app loads them into
DuckDB at startup. Re-running always produces identical files (seeded RNG).

    python scripts/generate_data.py
"""
from __future__ import annotations

import csv
import json
import math
import os
import random
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

AS_OF = date(2026, 9, 13)
SEED = 20260913
OUT_DIR = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data"))
rng = random.Random(SEED)

L = 100_000        # ₹1 lakh
CR = 10_000_000    # ₹1 crore


# --------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------
def days_ago(n: float) -> date:
    return AS_OF - timedelta(days=int(n))


def ts_ago(days: float, hour: int | None = None, minute: int | None = None) -> datetime:
    h = hour if hour is not None else rng.choice([7, 8, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 22, 23])
    m = minute if minute is not None else rng.randint(0, 59)
    base = datetime.combine(AS_OF - timedelta(days=int(days)), datetime.min.time())
    return base.replace(hour=h, minute=m, second=rng.randint(0, 59))


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def log_uniform(lo: float, hi: float) -> float:
    return math.exp(rng.uniform(math.log(lo), math.log(hi)))


def weighted(choices: dict):
    items = list(choices.items())
    r = rng.random() * sum(w for _, w in items)
    acc = 0.0
    for k, w in items:
        acc += w
        if r <= acc:
            return k
    return items[-1][0]


def split_amount(total: float, n: int, concentration: float = 1.0) -> list[float]:
    """Split `total` into n positive parts with random (dirichlet-like) weights."""
    ws = [rng.gammavariate(concentration, 1.0) for _ in range(n)]
    s = sum(ws)
    return [total * w / s for w in ws]


def round_inr(x: float, step: int = 1000) -> float:
    return float(int(round(x / step)) * step)


# --------------------------------------------------------------------------------------
# reference data
# --------------------------------------------------------------------------------------
RMS = [
    ("RM01", "Priya Deshmukh", "Mumbai", 52, 46),
    ("RM02", "Rohan Mehta", "Mumbai", 31, 40),
    ("RM03", "Ananya Iyer", "Bengaluru", 38, 42),
    ("RM04", "Karan Malhotra", "Delhi NCR", 64, 38),
    ("RM05", "Devika Rao", "Hyderabad", 44, 44),
    ("RM06", "Arjun Nair", "Mumbai", 14, 30),
]

CITIES = {
    "Mumbai": {"Mumbai": 0.7, "Pune": 0.12, "Thane": 0.08, "Ahmedabad": 0.06, "Surat": 0.04},
    "Bengaluru": {"Bengaluru": 0.72, "Chennai": 0.14, "Kochi": 0.08, "Mysuru": 0.06},
    "Delhi NCR": {"New Delhi": 0.45, "Gurugram": 0.28, "Noida": 0.12, "Chandigarh": 0.08, "Jaipur": 0.07},
    "Hyderabad": {"Hyderabad": 0.72, "Visakhapatnam": 0.1, "Chennai": 0.1, "Vijayawada": 0.08},
}

FIRST_NAMES = [
    "Aarav", "Vihaan", "Rohan", "Kunal", "Nikhil", "Siddharth", "Rahul", "Amit", "Manish", "Sanjay",
    "Rajesh", "Vikram", "Anil", "Deepak", "Harsh", "Kabir", "Aditya", "Varun", "Arjun", "Karan",
    "Rohit", "Gaurav", "Ankit", "Sumit", "Vivek", "Abhishek", "Aman", "Tarun", "Rajat", "Nitin",
    "Sahil", "Yash", "Arvind", "Karthik", "Srinivas", "Venkatesh", "Ramesh", "Suresh", "Ganesh",
    "Harish", "Kiran", "Naveen", "Pradeep", "Vinay", "Sandeep", "Anand", "Balaji", "Murali",
    "Raghav", "Adithya", "Sameer", "Farhan", "Imran", "Zubin", "Cyrus", "Neville", "Jehangir",
    "Neha", "Pooja", "Sneha", "Priya", "Anjali", "Kavita", "Meera", "Shweta", "Rupali", "Nisha",
    "Ritu", "Shalini", "Madhuri", "Sunita", "Manisha", "Deepa", "Simran", "Aditi", "Shreya", "Tanya",
    "Ishita", "Divya", "Ridhima", "Mansi", "Payal", "Kritika", "Lakshmi", "Deepika", "Anitha",
    "Sowmya", "Shruti", "Aishwarya", "Pavithra", "Nandini", "Keerthi", "Radhika", "Gayathri",
    "Swathi", "Preethi", "Zara", "Sana", "Ayesha", "Freny", "Dilnaz",
]
SURNAMES = {
    "Mumbai": ["Shah", "Mehta", "Desai", "Patel", "Joshi", "Kulkarni", "Deshpande", "Patil", "Jadhav",
               "Gokhale", "Wadia", "Mistry", "Irani", "Parekh", "Sanghvi", "Doshi", "Gandhi", "Thakkar",
               "Khan", "Sheikh", "Shroff", "Bhansali", "Lalwani", "Advani", "Chandiramani", "Kotak"],
    "Bengaluru": ["Iyer", "Iyengar", "Rao", "Reddy", "Naidu", "Nair", "Menon", "Pillai", "Krishnan",
                  "Raman", "Subramanian", "Venkataraman", "Murthy", "Shetty", "Hegde", "Kamath", "Bhat",
                  "Prabhu", "Chandrasekhar", "Srinivasan", "Gowda", "Kurup"],
    "Delhi NCR": ["Malhotra", "Kapoor", "Khanna", "Chopra", "Sethi", "Ahuja", "Arora", "Bhatia", "Chadha",
                  "Grover", "Sachdeva", "Talwar", "Gill", "Bedi", "Anand", "Aggarwal", "Garg", "Goel",
                  "Bansal", "Mittal", "Jain", "Singhal", "Gupta", "Sharma", "Verma", "Saxena", "Batra"],
    "Hyderabad": ["Reddy", "Rao", "Naidu", "Chowdary", "Prasad", "Sharma", "Kumar", "Varma", "Raju",
                  "Murthy", "Sastry", "Pillai", "Nair", "Krishnan", "Menon", "Reddy", "Hussain", "Ali"],
}

OCCUPATIONS = {
    "Business Owner / Promoter": 0.22, "CXO / Senior Executive": 0.20, "Tech Professional": 0.15,
    "Startup Founder": 0.10, "Doctor": 0.08, "Lawyer / CA": 0.08, "Inheritor / Family Office": 0.07,
    "Retired": 0.05, "Film / Media": 0.03, "Real Estate Developer": 0.02,
}

SEGMENTS = {"Affluent": 0.25, "HNI": 0.58, "UHNI": 0.17}
AUM_RANGE = {"Affluent": (50 * L, 2 * CR), "HNI": (2 * CR, 10 * CR), "UHNI": (10 * CR, 60 * CR)}
RISK = {"Conservative": 0.22, "Moderate": 0.48, "Aggressive": 0.30}
IPS_TARGET = {"Conservative": (30, 42), "Moderate": (50, 62), "Aggressive": (65, 80)}

EQUITY_MF = {
    "Large Cap": ["Mirae Asset Large Cap Fund", "ICICI Pru Bluechip Fund", "Axis Bluechip Fund",
                  "SBI Bluechip Fund", "Nippon India Large Cap Fund", "HDFC Top 100 Fund",
                  "Canara Robeco Bluechip Equity Fund"],
    "Flexi Cap": ["Parag Parikh Flexi Cap Fund", "HDFC Flexi Cap Fund", "Kotak Flexicap Fund",
                  "UTI Flexi Cap Fund", "PGIM India Flexi Cap Fund", "Franklin India Flexi Cap Fund"],
    "Mid Cap": ["Kotak Emerging Equity Fund", "HDFC Mid-Cap Opportunities Fund", "Motilal Oswal Midcap Fund",
                "Axis Midcap Fund", "PGIM India Midcap Opportunities Fund", "Nippon India Growth Fund"],
    "Small Cap": ["Nippon India Small Cap Fund", "SBI Small Cap Fund", "Quant Small Cap Fund",
                  "Axis Small Cap Fund", "HDFC Small Cap Fund", "Tata Small Cap Fund"],
    "ELSS": ["Axis ELSS Tax Saver Fund", "Mirae Asset ELSS Tax Saver Fund", "Quant ELSS Tax Saver Fund",
             "Parag Parikh ELSS Tax Saver Fund", "DSP ELSS Tax Saver Fund"],
}
DEBT_MF = {
    "Liquid": ["ICICI Pru Liquid Fund", "HDFC Liquid Fund", "Axis Liquid Fund", "SBI Liquid Fund"],
    "Corporate Bond": ["ICICI Pru Corporate Bond Fund", "HDFC Corporate Bond Fund",
                       "Aditya Birla SL Corporate Bond Fund", "Kotak Corporate Bond Fund"],
    "Short Duration": ["HDFC Short Term Debt Fund", "ICICI Pru Short Term Fund", "Axis Short Term Fund"],
    "Banking & PSU": ["Bandhan Banking & PSU Debt Fund", "Kotak Banking & PSU Debt Fund"],
    "Arbitrage": ["Kotak Equity Arbitrage Fund", "ICICI Pru Equity Arbitrage Fund", "Edelweiss Arbitrage Fund"],
}
HYBRID_MF = {
    "Balanced Advantage": ["ICICI Pru Balanced Advantage Fund", "HDFC Balanced Advantage Fund",
                           "Edelweiss Balanced Advantage Fund", "Kotak Balanced Advantage Fund"],
}
# annualised return assumptions (mean, sd) used only to back out invested_value from current_value
CATEGORY_RETURN = {
    "Large Cap": (0.12, 0.06), "Flexi Cap": (0.14, 0.07), "Mid Cap": (0.18, 0.10), "Small Cap": (0.20, 0.14),
    "ELSS": (0.13, 0.07), "Liquid": (0.068, 0.004), "Corporate Bond": (0.072, 0.01),
    "Short Duration": (0.07, 0.01), "Banking & PSU": (0.071, 0.01), "Arbitrage": (0.065, 0.005),
    "Balanced Advantage": (0.10, 0.05), "Stock": (0.15, 0.28), "PMS": (0.16, 0.10), "AIF": (0.14, 0.08),
    "Unlisted": (0.22, 0.45), "FD": (0.071, 0.003), "Bond": (0.078, 0.01),
}
STOCKS = [
    ("Reliance Industries", "Energy"), ("HDFC Bank", "Financials"), ("ICICI Bank", "Financials"),
    ("Infosys", "IT"), ("TCS", "IT"), ("Wipro", "IT"), ("HCL Technologies", "IT"),
    ("Bharti Airtel", "Telecom"), ("Larsen & Toubro", "Industrials"), ("ITC", "FMCG"),
    ("Hindustan Unilever", "FMCG"), ("Bajaj Finance", "Financials"), ("Kotak Mahindra Bank", "Financials"),
    ("Axis Bank", "Financials"), ("State Bank of India", "Financials"), ("Tata Motors", "Auto"),
    ("Maruti Suzuki", "Auto"), ("Mahindra & Mahindra", "Auto"), ("Sun Pharma", "Pharma"),
    ("Dr Reddy's Labs", "Pharma"), ("Cipla", "Pharma"), ("Titan Company", "Consumer"),
    ("Asian Paints", "Consumer"), ("Nestle India", "FMCG"), ("UltraTech Cement", "Materials"),
    ("Tata Steel", "Materials"), ("JSW Steel", "Materials"), ("NTPC", "Utilities"), ("Power Grid", "Utilities"),
    ("Adani Ports", "Industrials"), ("Eternal (Zomato)", "Consumer Tech"), ("Trent", "Consumer"),
    ("Dixon Technologies", "Electronics"), ("Persistent Systems", "IT"), ("Bajaj Finserv", "Financials"),
    ("HDFC AMC", "Financials"), ("Divi's Labs", "Pharma"), ("Pidilite Industries", "Materials"),
    ("Avenue Supermarts", "Consumer"), ("InterGlobe Aviation", "Aviation"), ("Polycab India", "Industrials"),
    ("Coforge", "IT"), ("Bharat Electronics", "Defence"), ("Hindustan Aeronautics", "Defence"),
]
ESOP_STOCKS = ["Infosys", "TCS", "Wipro", "HCL Technologies", "Persistent Systems", "Coforge"]
SECTOR = dict(STOCKS)

# Exclusive shelf. Names double as instrument names so holdings/transactions join to products.
PRODUCTS = [
    # id, name, type, strategy, manager, min_ticket, suitable_for, status, closes_on(days from AS_OF or None), note
    ("P01", "Aurelius Multi-cap Growth PMS", "PMS", "Multi-cap growth, 20-25 stocks", "Aurelius Capital",
     50 * L, "Moderate|Aggressive", "Open", None, "Concentrated growth book; 1-yr exit load"),
    ("P02", "Meridian Small & Mid Cap PMS", "PMS", "Small & mid cap, high-conviction", "Meridian Investment Managers",
     50 * L, "Aggressive", "Open", None, "Higher drawdown tolerance required"),
    ("P03", "Harbor Quality Compounders PMS", "PMS", "Large-cap quality, low churn", "Harbor Asset",
     50 * L, "Conservative|Moderate|Aggressive", "Open", None, "Suitable as core equity sleeve"),
    ("P04", "Vantage Long-Short Fund (Cat III)", "AIF", "Long-short equity, market-neutral tilt", "Vantage Alternatives",
     1 * CR, "Moderate|Aggressive", "Closing Soon", 11, "Series closes; next window in Q1"),
    ("P05", "Ridge Private Credit Opportunities (Cat II)", "AIF", "Senior secured private credit", "Ridge Capital",
     1 * CR, "Conservative|Moderate", "Open", None, "Quarterly distributions; 4-yr tenure"),
    ("P06", "Nova Pre-IPO & Late-Stage Fund (Cat II)", "AIF", "Late-stage private companies", "Nova Ventures",
     1 * CR, "Aggressive", "Closing Soon", 19, "Final close; drawdown over 24 months"),
    ("P07", "Sentinel Real Estate Yield Fund (Cat II)", "AIF", "Commercial real-estate yield", "Sentinel RE",
     1 * CR, "Conservative|Moderate", "Open", None, "Rental-yield backed; 5-yr tenure"),
    ("P08", "NSE (unlisted)", "Unlisted", "Pre-IPO exchange operator", "Unlisted desk",
     10 * L, "Moderate|Aggressive", "Open", None, "Lot-based; 6-month post-listing lock-in applies"),
    ("P09", "Chennai Super Kings (unlisted)", "Unlisted", "Sports franchise", "Unlisted desk",
     5 * L, "Aggressive", "Open", None, "Illiquid; long-hold only"),
    ("P10", "SBI Funds Management (unlisted)", "Unlisted", "Pre-IPO asset manager", "Unlisted desk",
     10 * L, "Moderate|Aggressive", "Limited stock", None, "Limited inventory this month"),
]
PRODUCT_BY_ID = {p[0]: p for p in PRODUCTS}
PMS_NAMES = [p[1] for p in PRODUCTS if p[2] == "PMS"]
AIF_NAMES = [p[1] for p in PRODUCTS if p[2] == "AIF"]
UNLISTED_NAMES = [p[1] for p in PRODUCTS if p[2] == "Unlisted"]
PRODUCT_ID_BY_NAME = {p[1]: p[0] for p in PRODUCTS}

FD_BANKS = ["HDFC Bank FD", "ICICI Bank FD", "Bajaj Finance FD", "SBI FD", "Kotak Mahindra Bank FD"]
BONDS = ["NHAI Tax-free Bonds 2031", "REC 54EC Capital Gain Bonds", "Muthoot Finance NCD 2028",
         "GoI 7.18% GS 2033", "PFC Tax-free Bonds 2030", "Shriram Finance NCD 2027"]


# --------------------------------------------------------------------------------------
# entities
# --------------------------------------------------------------------------------------
@dataclass
class Client:
    client_id: str
    name: str
    rm_id: str
    region: str
    segment: str
    risk_profile: str
    ips_equity_target: int
    city: str
    age: int
    occupation: str
    onboarded_on: date
    last_review_on: date
    kyc_status: str
    engagement: str
    aum: float
    flags: dict = field(default_factory=dict)
    cash: float = 0.0
    holdings: list = field(default_factory=list)
    sips: list = field(default_factory=list)
    last_contact_days: int = 30
    interest_product: str | None = None
    redeem_days_ago: int | None = None


def make_clients() -> list[Client]:
    clients: list[Client] = []
    n = 0
    used_names = set()
    for rm_id, _rm_name, region, _tenure, capacity in RMS:
        for _ in range(capacity):
            n += 1
            segment = weighted(SEGMENTS)
            aum = round_inr(log_uniform(*AUM_RANGE[segment]), 10_000)
            risk = weighted(RISK)
            occupation = weighted(OCCUPATIONS)
            if occupation == "Retired":
                risk = weighted({"Conservative": 0.6, "Moderate": 0.35, "Aggressive": 0.05})
            if occupation in ("Startup Founder",):
                risk = weighted({"Conservative": 0.05, "Moderate": 0.35, "Aggressive": 0.6})
            age = {"Retired": rng.randint(61, 76), "Startup Founder": rng.randint(30, 45),
                   "Tech Professional": rng.randint(31, 48)}.get(occupation, rng.randint(34, 68))
            while True:
                name = f"{rng.choice(FIRST_NAMES)} {rng.choice(SURNAMES[region])}"
                if name not in used_names:
                    used_names.add(name)
                    break
            onboarded = days_ago(rng.randint(60, 1500) if segment != "UHNI" else rng.randint(120, 1500))
            engagement = weighted({"high": 0.25, "medium": 0.40, "low": 0.25, "dormant": 0.10})
            c = Client(
                client_id=f"C{n:04d}", name=name, rm_id=rm_id, region=region, segment=segment,
                risk_profile=risk, ips_equity_target=rng.randint(*IPS_TARGET[risk]),
                city=weighted(CITIES[region]), age=age, occupation=occupation, onboarded_on=onboarded,
                last_review_on=days_ago(rng.choice([rng.randint(10, 120)] * 3 + [rng.randint(121, 400)])),
                kyc_status=weighted({"Verified": 0.94, "Re-KYC due": 0.06}), engagement=engagement, aum=aum,
            )
            clients.append(c)

    # ---- plant the stories (independent draws, then a few coherence fixes) ----
    for c in clients:
        f = {
            "idle_cash": rng.random() < 0.18,
            "liquidity_event": rng.random() < 0.04,
            "concentrated": rng.random() < 0.12 or (c.occupation == "Tech Professional" and rng.random() < 0.35)
                            or (c.occupation == "Business Owner / Promoter" and rng.random() < 0.2),
            "drift": rng.random() < 0.15,
            "sip_risk": rng.random() < 0.10,
            "lockin": rng.random() < 0.12,
            "churn": rng.random() < 0.08,
            "engagement_drop": rng.random() < 0.06,
            "buy_intent": rng.random() < 0.09,
            "onboarding_stuck": rng.random() < 0.035,
            "tax_harvest": rng.random() < 0.12,
            "product_interest": rng.random() < 0.10,
            "overlap": rng.random() < 0.14 or (c.occupation == "Inheritor / Family Office" and rng.random() < 0.5),
        }
        if f["liquidity_event"]:
            f["idle_cash"] = False
        if f["onboarding_stuck"]:
            # a new client whose money is parked: no MF book yet, no SIPs, little history
            c.onboarded_on = days_ago(rng.randint(4, 45))
            f.update(idle_cash=False, liquidity_event=False, sip_risk=False, lockin=False, churn=False,
                     engagement_drop=False, overlap=False, tax_harvest=False, drift=False)
            c.engagement = rng.choice(["medium", "low"])
        if f["churn"] or f["engagement_drop"]:
            if c.engagement in ("low", "dormant"):
                c.engagement = "medium"
        if f["buy_intent"] and c.engagement in ("low", "dormant"):
            c.engagement = "medium"
        c.flags = f

        # days since last RM contact: mixture, then forced by stories
        bucket = weighted({"recent": 0.55, "mid": 0.25, "stale": 0.20})
        c.last_contact_days = {"recent": rng.randint(1, 30), "mid": rng.randint(31, 60),
                               "stale": rng.randint(61, 150)}[bucket]
        if c.segment == "UHNI" and c.last_contact_days > 60 and rng.random() < 0.6:
            c.last_contact_days = rng.randint(8, 45)
        if f["churn"]:
            c.last_contact_days = max(c.last_contact_days, rng.randint(22, 70))
        if f["buy_intent"]:
            c.last_contact_days = max(c.last_contact_days, rng.randint(8, 40))
        if f["onboarding_stuck"]:
            c.last_contact_days = rng.randint(3, 25)
            c.last_contact_days = min(c.last_contact_days, (AS_OF - c.onboarded_on).days)
    return clients


# --------------------------------------------------------------------------------------
# holdings
# --------------------------------------------------------------------------------------
HOLDING_SEQ = 0


def new_holding(client: Client, asset_class: str, instrument: str, category: str, sector: str, manager: str,
                current_value: float, years_held: float, is_equity: int, lock_in_until: date | None = None,
                growth_override: float | None = None, purchase_date: date | None = None) -> dict:
    global HOLDING_SEQ
    HOLDING_SEQ += 1
    mean, sd = CATEGORY_RETURN.get(category, CATEGORY_RETURN["Stock"])
    if growth_override is not None:
        growth = growth_override
    else:
        # geometric growth: dispersion scales with sqrt(time), so long-held positions don't
        # compound one unlucky year into a 60% loss
        mu_log = math.log(1 + mean) - 0.5 * sd * sd
        growth = math.exp(years_held * mu_log + math.sqrt(years_held) * sd * rng.gauss(0, 1))
        growth = max(0.45, growth)
    invested = round_inr(current_value / growth, 100)
    current_value = round_inr(current_value, 100)
    pd_ = purchase_date or (AS_OF - timedelta(days=int(years_held * 365.25)))
    return {
        "holding_id": f"H{HOLDING_SEQ:05d}", "client_id": client.client_id, "asset_class": asset_class,
        "instrument": instrument, "category": category, "sector": sector, "manager": manager,
        "invested_value": invested, "current_value": current_value, "purchase_date": pd_.isoformat(),
        "lock_in_until": lock_in_until.isoformat() if lock_in_until else "", "is_equity": is_equity,
    }


def years_since_onboarding(c: Client, min_years: float = 0.15, max_years: float = 6.0) -> float:
    tenure = (AS_OF - c.onboarded_on).days / 365.25
    hi = max(min_years, min(max_years, tenure - 0.05))
    return rng.uniform(min_years, hi) if hi > min_years else min_years


def build_holdings(c: Client) -> None:
    f = c.flags
    aum = c.aum
    if f["onboarding_stuck"]:
        cash_pct = rng.uniform(0.35, 0.70)
    elif f["idle_cash"]:
        cash_pct = rng.uniform(0.08, 0.30)
    else:
        cash_pct = rng.uniform(0.005, 0.045)
    cash = aum * cash_pct
    investable = aum - cash

    target = c.ips_equity_target / 100
    if f["drift"]:
        eq_share = clamp(target + rng.choice([-1, 1]) * rng.uniform(0.15, 0.28), 0.05, 0.95)
    else:
        eq_share = clamp(target + rng.uniform(-0.07, 0.07), 0.05, 0.95)
    # note: cash is non-equity, so measured equity % = eq_share * (1 - cash_pct)
    equity_amt = investable * eq_share
    nonequity_amt = investable - equity_amt
    H: list[dict] = []

    # ---------------- equity ----------------
    remaining_eq = equity_amt
    if f["concentrated"]:
        pos = aum * rng.uniform(0.22, 0.55)
        if c.occupation == "Tech Professional":
            stock = rng.choice(ESOP_STOCKS)
        else:
            stock = rng.choice(STOCKS)[0]
        H.append(new_holding(c, "Direct Equity", stock, "Stock", SECTOR[stock], "Demat", pos,
                             rng.uniform(2.5, 9.0), 1, purchase_date=AS_OF - timedelta(days=int(rng.uniform(2.5, 9) * 365))))
        remaining_eq = max(equity_amt - pos, equity_amt * 0.25)

    if f["onboarding_stuck"]:
        # new client: a couple of stocks transferred in (or nothing) + FDs. No mutual funds yet.
        if rng.random() < 0.6:
            for stock, amt in zip(rng.sample(STOCKS, 3), split_amount(remaining_eq, 3)):
                H.append(new_holding(c, "Direct Equity", stock[0], "Stock", stock[1], "Demat", amt, rng.uniform(1, 6), 1))
        else:
            nonequity_amt += remaining_eq
        for bank, amt in zip(rng.sample(FD_BANKS, 2), split_amount(nonequity_amt, 2)):
            yrs = rng.uniform(0.2, 1.5)
            H.append(new_holding(c, "FD", bank, "FD", "", bank.replace(" FD", ""), amt, yrs, 0,
                                 lock_in_until=AS_OF + timedelta(days=int(rng.uniform(60, 700)))))
        c.holdings = H
        c.cash = round_inr(cash, 1000)
        return

    sleeves = {"Equity MF": rng.uniform(0.40, 0.75), "Direct Equity": rng.uniform(0.10, 0.35)}
    if c.segment in ("HNI", "UHNI") and rng.random() < 0.6:
        sleeves["PMS"] = rng.uniform(0.15, 0.40)
    if (c.segment == "UHNI" and rng.random() < 0.7) or (c.segment == "HNI" and rng.random() < 0.2):
        sleeves["AIF"] = rng.uniform(0.10, 0.25)
    if (c.occupation == "Startup Founder" or c.risk_profile == "Aggressive") and rng.random() < 0.5:
        sleeves["Unlisted"] = rng.uniform(0.05, 0.15)
    tot = sum(sleeves.values())
    amts = {k: remaining_eq * v / tot for k, v in sleeves.items()}

    # fold sub-minimum exclusive sleeves back into MFs
    for k, minimum in (("PMS", 50 * L), ("AIF", 1 * CR), ("Unlisted", 5 * L)):
        if k in amts and amts[k] < minimum:
            amts["Equity MF"] += amts.pop(k)

    # equity MFs
    if f["overlap"]:
        crowded = rng.choice(["Large Cap", "Flexi Cap", "Mid Cap", "Small Cap"])
        n_crowded = rng.randint(4, 6)
        picks = [(crowded, fn) for fn in rng.sample(EQUITY_MF[crowded], min(n_crowded, len(EQUITY_MF[crowded])))]
        others = [cat for cat in EQUITY_MF if cat != crowded]
        for cat in rng.sample(others, rng.randint(2, 4)):
            picks.append((cat, rng.choice(EQUITY_MF[cat])))
    else:
        n_funds = rng.randint(3, 7)
        picks, seen = [], set()
        cats = list(EQUITY_MF.keys())
        while len(picks) < n_funds:
            cat = weighted({"Large Cap": 0.25, "Flexi Cap": 0.3, "Mid Cap": 0.2, "Small Cap": 0.15, "ELSS": 0.1})
            fn = rng.choice(EQUITY_MF[cat])
            if fn in seen:
                continue
            seen.add(fn)
            picks.append((cat, fn))
    for (cat, fn), amt in zip(picks, split_amount(amts["Equity MF"], len(picks), 1.5)):
        yrs = years_since_onboarding(c)
        lock = (AS_OF - timedelta(days=int(yrs * 365.25)) + timedelta(days=int(3 * 365.25))) if cat == "ELSS" else None
        H.append(new_holding(c, "Equity MF", fn, cat, "", fn.split(" ")[0], amt, yrs, 1, lock_in_until=lock))

    # direct equity
    n_stocks = rng.randint(3, 12)
    have = {h["instrument"] for h in H}
    pool = [s for s in STOCKS if s[0] not in have]
    for (stock, sector), amt in zip(rng.sample(pool, n_stocks), split_amount(amts["Direct Equity"], n_stocks, 1.2)):
        yrs = rng.uniform(0.3, 8.0)
        H.append(new_holding(c, "Direct Equity", stock, "Stock", sector, "Demat", amt, yrs, 1,
                             purchase_date=AS_OF - timedelta(days=int(yrs * 365.25))))

    # PMS (min 50L each)
    if "PMS" in amts:
        n = 2 if amts["PMS"] >= 1.2 * CR and rng.random() < 0.4 else 1
        for name, amt in zip(rng.sample(PMS_NAMES, n), split_amount(amts["PMS"], n)):
            yrs = years_since_onboarding(c, 0.2, 5)
            pd_ = AS_OF - timedelta(days=int(yrs * 365.25))
            H.append(new_holding(c, "PMS", name, "PMS", "", name.split(" ")[0], max(amt, 50 * L), yrs, 1,
                                 lock_in_until=pd_ + timedelta(days=365), purchase_date=pd_))
    # AIF (min 1Cr each)
    if "AIF" in amts:
        n = 2 if amts["AIF"] >= 2.5 * CR and rng.random() < 0.4 else 1
        for name, amt in zip(rng.sample(AIF_NAMES, n), split_amount(amts["AIF"], n)):
            yrs = years_since_onboarding(c, 0.3, 4)
            pd_ = AS_OF - timedelta(days=int(yrs * 365.25))
            H.append(new_holding(c, "AIF", name, "AIF", "", name.split(" ")[0], max(amt, 1 * CR), yrs, 1,
                                 lock_in_until=pd_ + timedelta(days=int(rng.uniform(4, 7) * 365)), purchase_date=pd_))
    # Unlisted
    if "Unlisted" in amts:
        n = rng.randint(1, 2)
        for name, amt in zip(rng.sample(UNLISTED_NAMES, n), split_amount(amts["Unlisted"], n)):
            yrs = years_since_onboarding(c, 0.2, 4)
            H.append(new_holding(c, "Unlisted", name, "Unlisted", "", "Unlisted desk", amt, yrs, 1))

    # ---------------- non-equity ----------------
    ne = {"Debt MF": rng.uniform(0.30, 0.60), "FD": rng.uniform(0.15, 0.40)}
    if rng.random() < 0.55:
        ne["Bonds"] = rng.uniform(0.05, 0.25)
    if rng.random() < 0.5:
        ne["Hybrid MF"] = rng.uniform(0.05, 0.25)
    tot = sum(ne.values())
    ne_amts = {k: nonequity_amt * v / tot for k, v in ne.items()}

    n_debt = rng.randint(1, 3)
    cats = rng.sample(list(DEBT_MF.keys()), n_debt)
    for cat, amt in zip(cats, split_amount(ne_amts["Debt MF"], n_debt)):
        fn = rng.choice(DEBT_MF[cat])
        H.append(new_holding(c, "Debt MF", fn, cat, "", fn.split(" ")[0], amt, years_since_onboarding(c, 0.1, 4), 0))
    n_fd = rng.randint(1, 2)
    for bank, amt in zip(rng.sample(FD_BANKS, n_fd), split_amount(ne_amts["FD"], n_fd)):
        yrs = rng.uniform(0.1, 2.5)
        tenure_days = int(rng.choice([365, 540, 730, 1095]))
        pd_ = AS_OF - timedelta(days=int(yrs * 365.25))
        H.append(new_holding(c, "FD", bank, "FD", "", bank.replace(" FD", ""), amt, yrs, 0,
                             lock_in_until=pd_ + timedelta(days=tenure_days), purchase_date=pd_))
    if "Bonds" in ne_amts:
        n_b = rng.randint(1, 2)
        for name, amt in zip(rng.sample(BONDS, n_b), split_amount(ne_amts["Bonds"], n_b)):
            H.append(new_holding(c, "Bonds", name, "Bond", "", "Bond desk", amt, years_since_onboarding(c, 0.2, 5), 0))
    if "Hybrid MF" in ne_amts:
        fn = rng.choice(HYBRID_MF["Balanced Advantage"])
        H.append(new_holding(c, "Hybrid MF", fn, "Balanced Advantage", "", fn.split(" ")[0], ne_amts["Hybrid MF"],
                             years_since_onboarding(c, 0.2, 5), 0))

    # ---------------- story overrides ----------------
    if f["tax_harvest"]:
        cands = [h for h in H if h["asset_class"] in ("Equity MF", "Direct Equity") and h["current_value"] >= max(5 * L, aum * 0.03)]
        for h in rng.sample(cands, min(len(cands), rng.randint(1, 2))):
            h["invested_value"] = round_inr(h["current_value"] / rng.uniform(0.55, 0.78), 100)
            pd_ = AS_OF - timedelta(days=rng.randint(120, 700))
            h["purchase_date"] = pd_.isoformat()
    if f["lockin"]:
        cands = [h for h in H if h["asset_class"] in ("Equity MF", "PMS", "FD") and
                 (h["asset_class"] != "Equity MF" or h["category"] == "ELSS")]
        if not cands:
            fd = new_holding(c, "FD", rng.choice(FD_BANKS), "FD", "", "Bank", max(5 * L, aum * 0.04), 1.0, 0)
            H.append(fd)
            cands = [fd]
        h = rng.choice(cands)
        lock = AS_OF + timedelta(days=rng.randint(-5, 28))
        tenure = {"ELSS": 3 * 365, "PMS": 365, "FD": rng.choice([365, 540, 730])}[h["category"] if h["category"] in ("ELSS", "PMS") else "FD"]
        h["lock_in_until"] = lock.isoformat()
        h["purchase_date"] = (lock - timedelta(days=tenure)).isoformat()
        h["manager"] = h["manager"]

    c.holdings = H
    c.cash = round_inr(cash, 1000)


# --------------------------------------------------------------------------------------
# SIPs
# --------------------------------------------------------------------------------------
SIP_SEQ = 0


def build_sips(c: Client) -> None:
    global SIP_SEQ
    f = c.flags
    eq_funds = [h for h in c.holdings if h["asset_class"] == "Equity MF"]
    if not eq_funds or f["onboarding_stuck"]:
        return
    p = {"Affluent": 0.75, "HNI": 0.65, "UHNI": 0.45}[c.segment]
    if rng.random() > p:
        return
    n = rng.randint(1, min(4, len(eq_funds)))
    lo, hi = {"Affluent": (10_000, 50_000), "HNI": (25_000, 200_000), "UHNI": (50_000, 500_000)}[c.segment]
    risk_sip_index = rng.randrange(n) if f["sip_risk"] else -1
    for i, h in enumerate(rng.sample(eq_funds, n)):
        SIP_SEQ += 1
        amount = round_inr(rng.uniform(lo, hi), 5000)
        start = AS_OF - timedelta(days=rng.randint(90, 1400))
        start = max(start, c.onboarded_on + timedelta(days=7))
        end = start + timedelta(days=365 * 10)
        mandate_expiry = start + timedelta(days=rng.choice([365 * 3, 365 * 5, 365 * 10, 365 * 30]))
        status, last_debit, reason = "Active", "Success", ""
        next_due = date(AS_OF.year, AS_OF.month, min(rng.choice([1, 5, 7, 10, 15, 20, 25]), 28))
        if next_due < AS_OF:
            m = AS_OF.month + 1
            next_due = date(AS_OF.year + (m > 12), (m - 1) % 12 + 1, next_due.day)
        if i == risk_sip_index:
            reason = weighted({"mandate_expiring": 0.45, "debit_failed": 0.35, "sip_ending": 0.20})
            if reason == "mandate_expiring":
                mandate_expiry = AS_OF + timedelta(days=rng.randint(2, 28))
            elif reason == "debit_failed":
                last_debit = "Failed"
                next_due = AS_OF - timedelta(days=rng.randint(1, 8))
            else:
                end = AS_OF + timedelta(days=rng.randint(5, 44))
        c.sips.append({
            "sip_id": f"S{SIP_SEQ:05d}", "client_id": c.client_id, "instrument": h["instrument"],
            "amount": amount, "start_date": start.isoformat(), "end_date": end.isoformat(), "status": status,
            "mandate_expiry": mandate_expiry.isoformat(), "last_debit_status": last_debit,
            "next_due": next_due.isoformat(),
        })


# --------------------------------------------------------------------------------------
# transactions
# --------------------------------------------------------------------------------------
TXN_SEQ = 0


def txn(c: Client, when: date, ttype: str, asset_class: str, instrument: str, amount: float,
        channel: str | None = None, status: str = "Completed") -> dict:
    global TXN_SEQ
    TXN_SEQ += 1
    if channel is None:
        if asset_class in ("PMS", "AIF", "Unlisted", "Bonds"):
            channel = "RM-assisted"
        else:
            channel = weighted({"App": 0.58, "RM-assisted": 0.30, "Web": 0.12})
    return {"txn_id": f"T{TXN_SEQ:06d}", "client_id": c.client_id, "txn_date": when.isoformat(),
            "txn_type": ttype, "asset_class": asset_class, "instrument": instrument,
            "amount": round_inr(amount, 100), "channel": channel, "status": status}


def build_transactions(c: Client) -> list[dict]:
    T: list[dict] = []
    sip_funds = {s["instrument"]: s for s in c.sips}
    for h in c.holdings:
        pd_ = date.fromisoformat(h["purchase_date"])
        ac = h["asset_class"]
        if ac in ("Equity MF", "Debt MF", "Hybrid MF"):
            if h["instrument"] in sip_funds:
                continue  # SIP debits generated below
            n = rng.choice([1, 1, 2, 3])
            for part in split_amount(h["invested_value"], n):
                when = pd_ + timedelta(days=rng.randint(0, 45) if n > 1 else 0)
                T.append(txn(c, min(when, AS_OF), "Lumpsum Buy", ac, h["instrument"], part))
        elif ac == "Direct Equity":
            if pd_ >= c.onboarded_on:
                T.append(txn(c, pd_, "Equity Buy", ac, h["instrument"], h["invested_value"]))
        elif ac == "PMS":
            T.append(txn(c, pd_, "PMS Subscription", ac, h["instrument"], h["invested_value"]))
        elif ac == "AIF":
            n = rng.randint(2, 4)
            for i, part in enumerate(split_amount(h["invested_value"], n, 3)):
                T.append(txn(c, min(pd_ + timedelta(days=i * 120), AS_OF), "AIF Drawdown", ac, h["instrument"], part))
        elif ac == "Unlisted":
            T.append(txn(c, pd_, "Unlisted Buy", ac, h["instrument"], h["invested_value"]))
        elif ac == "FD":
            T.append(txn(c, pd_, "FD Booking", ac, h["instrument"], h["invested_value"]))
        elif ac == "Bonds":
            T.append(txn(c, pd_, "Bond Purchase", ac, h["instrument"], h["invested_value"]))
    # SIP debits (last 24 months at most)
    for s in c.sips:
        start = date.fromisoformat(s["start_date"])
        day = date.fromisoformat(s["next_due"]).day
        first = max(start, AS_OF - timedelta(days=730))
        y, m = first.year, first.month
        while True:
            when = date(y, m, min(day, 28))
            if when > AS_OF:
                break
            if when >= start:
                status = "Completed"
                if s["last_debit_status"] == "Failed" and when == date.fromisoformat(s["next_due"]):
                    status = "Failed"
                T.append(txn(c, when, "SIP Debit", "Equity MF", s["instrument"], s["amount"], "App", status))
            m += 1
            if m > 12:
                m, y = 1, y + 1
        if s["last_debit_status"] == "Failed":
            nd = date.fromisoformat(s["next_due"])
            if not any(t["txn_date"] == nd.isoformat() and t["instrument"] == s["instrument"] for t in T):
                T.append(txn(c, nd, "SIP Debit", "Equity MF", s["instrument"], s["amount"], "App", "Failed"))
    # redemptions
    if c.flags["churn"] and rng.random() < 0.55:
        src = [h for h in c.holdings if h["asset_class"] in ("Debt MF", "Equity MF")]
        if src:
            h = rng.choice(src)
            c.redeem_days_ago = rng.randint(1, 8)   # the app warnings (below) are planted *before* this
            T.append(txn(c, days_ago(c.redeem_days_ago), "Redeem", h["asset_class"], h["instrument"],
                         c.aum * rng.uniform(0.05, 0.18), "App"))
    elif rng.random() < 0.12 and not c.flags["onboarding_stuck"]:
        src = [h for h in c.holdings if h["asset_class"] in ("Debt MF", "Equity MF")]
        if src:
            h = rng.choice(src)
            T.append(txn(c, days_ago(rng.randint(30, 180)), "Redeem", h["asset_class"], h["instrument"],
                         h["current_value"] * rng.uniform(0.1, 0.5)))
    if rng.random() < 0.1 and len(c.holdings) > 5:
        h = rng.choice([h for h in c.holdings if h["asset_class"] == "Equity MF"] or c.holdings)
        T.append(txn(c, days_ago(rng.randint(10, 300)), "Switch", h["asset_class"], h["instrument"],
                     h["current_value"] * rng.uniform(0.2, 0.6)))
    return T


# --------------------------------------------------------------------------------------
# interactions
# --------------------------------------------------------------------------------------
INT_SEQ = 0
CALL_NOTES = [
    ("Quarterly portfolio review call — walked through allocation vs plan; client asked about mid-cap valuations.", "Follow-up scheduled", "Send rebalancing proposal"),
    ("Discussed idle balance; client prefers to wait for a market dip before deploying.", "Awaiting client", "Call after 15th to revisit deployment"),
    ("Service call: updated nominee and bank mandate details.", "No action needed", ""),
    ("Shared performance summary; client comfortable with PMS drawdown, no changes.", "No action needed", ""),
    ("Birthday call. Client mentioned daughter's US admission next year — will need USD liquidity.", "Follow-up scheduled", "Discuss LRS / USD deposit options"),
    ("Discussed SIP top-up; client to confirm after annual bonus credit.", "Awaiting client", "Follow up on SIP top-up"),
    ("Client asked about AIF drawdown schedule and capital call timing.", "No action needed", ""),
    ("Follow-up on unlisted shares allotment; DIS signed.", "Transaction initiated", ""),
    ("Client concerned about market volatility; reassured on asset allocation, no redemptions.", "No action needed", "Share volatility note"),
    ("Discussed ELSS lock-in ending; client open to switching to flexi-cap on maturity.", "Follow-up scheduled", "Switch proposal on lock-in expiry"),
]
WA_NOTES = [
    ("Sent monthly statement and market note.", "No action needed", ""),
    ("Confirmed steps for SIP mandate renewal; client will approve e-NACH on the app.", "Awaiting client", "Check mandate status"),
    ("Client asked for capital-gains statement for CA; sent.", "No action needed", ""),
    ("Shared liquid-fund comparison for parked cash.", "Awaiting client", "Confirm liquid fund deployment"),
    ("Client requested a call next week regarding a property sale proceeds.", "Follow-up scheduled", "Plan deployment of sale proceeds"),
]
MEET_NOTES = [
    ("Annual review at client's office — reaffirmed IPS; agreed to trim single-stock exposure gradually.", "Follow-up scheduled", "Send phased selling plan"),
    ("Met client and spouse; discussed estate and succession planning needs; will loop in trust desk.", "Follow-up scheduled", "Intro to trust & estate desk"),
    ("Coffee catch-up; client mentioned possible liquidity from a business stake sale in Q4.", "Follow-up scheduled", "Prepare deployment plan"),
    ("Portfolio review with family; consolidated legacy funds discussion started.", "Awaiting client", "Send consolidation proposal"),
]
EMAIL_NOTES = [
    ("Sent proposal for debt-sleeve rebalancing.", "Awaiting client", "Follow up on proposal"),
    ("Sent KYC re-validation reminder and document list.", "Awaiting client", "Chase re-KYC documents"),
    ("Sent factsheets requested by client.", "No action needed", ""),
]


def build_interactions(c: Client, rm_id: str) -> list[dict]:
    global INT_SEQ
    I: list[dict] = []
    per_year = {"UHNI": 14, "HNI": 8, "Affluent": 5}[c.segment]
    tenure_days = (AS_OF - c.onboarded_on).days
    n = max(1, int(per_year * min(tenure_days, 365) / 365 * rng.uniform(0.6, 1.4)))
    n = min(n, 24)
    days = [c.last_contact_days]
    for _ in range(n - 1):
        days.append(rng.randint(c.last_contact_days + 5, max(c.last_contact_days + 6, min(tenure_days, 365))))
    days = sorted(set(days))
    for i, dd in enumerate(days):
        INT_SEQ += 1
        channel = weighted({"Call": 0.45, "WhatsApp": 0.30, "Meeting": 0.12, "Email": 0.13})
        pool = {"Call": CALL_NOTES, "WhatsApp": WA_NOTES, "Meeting": MEET_NOTES, "Email": EMAIL_NOTES}[channel]
        summary, outcome, next_action = rng.choice(pool)
        product_id = ""
        # product interest planted in the most recent-but-one conversation
        if c.interest_product and i == 0 and rng.random() < 0.5:
            pname = PRODUCT_BY_ID[c.interest_product][1]
            channel = rng.choice(["WhatsApp", "Call"])
            summary = f"Shared {pname} deck; client will review and revert."
            outcome, next_action, product_id = "Deck shared", f"Follow up on {pname}", c.interest_product
        if c.flags["onboarding_stuck"] and i == 0:
            summary = "Welcome call; walked through app onboarding for mutual funds. Client will complete KYC & mandate on the app."
            outcome, next_action = "Awaiting client", "Check onboarding completion"
        next_on = ""
        if next_action:
            next_on = (AS_OF - timedelta(days=dd) + timedelta(days=rng.randint(3, 21))).isoformat()
        I.append({"interaction_id": f"I{INT_SEQ:05d}", "client_id": c.client_id, "rm_id": rm_id,
                  "occurred_on": (AS_OF - timedelta(days=dd)).isoformat(), "channel": channel, "summary": summary,
                  "outcome": outcome, "next_action": next_action, "next_action_on": next_on, "product_id": product_id})
    return I


# --------------------------------------------------------------------------------------
# app events
# --------------------------------------------------------------------------------------
EV_SEQ = 0
OPENS_PER_WEEK = {"high": 5.0, "medium": 2.0, "low": 0.5, "dormant": 0.0}
ONB_STEPS = ["onb_kyc", "onb_fatca", "onb_bank_mandate", "onb_nominee", "onb_complete"]


def ev(c: Client, when: datetime, name: str, screen: str, session_id: str, product_id: str = "", platform: str = "iOS") -> dict:
    global EV_SEQ
    EV_SEQ += 1
    return {"event_id": f"E{EV_SEQ:06d}", "client_id": c.client_id, "ts": when.strftime("%Y-%m-%d %H:%M:%S"),
            "event_name": name, "screen": screen, "product_id": product_id, "session_id": session_id,
            "platform": platform}


def eligible_products(c: Client) -> list[str]:
    out = []
    for p in PRODUCTS:
        pid, _, ptype, _, _, min_ticket, suitable, status, _, _ = p
        if c.risk_profile not in suitable.split("|"):
            continue
        if c.aum < 3 * min_ticket:
            continue
        out.append(pid)
    return out


def build_app_events(c: Client) -> list[dict]:
    E: list[dict] = []
    platform = rng.choice(["iOS", "iOS", "Android", "Web"])
    rate = OPENS_PER_WEEK[c.engagement]
    f = c.flags
    sess_no = 0

    def session(day_ago: float, extra: list[tuple[str, str, str]] | None = None, n_extra_random: int | None = None):
        nonlocal sess_no
        sess_no += 1
        sid = f"{c.client_id}-{sess_no:03d}"
        t = ts_ago(day_ago)
        E.append(ev(c, t, "app_open", "home", sid, platform=platform))
        k = n_extra_random if n_extra_random is not None else rng.randint(1, 5)
        menu = {"view_portfolio": 0.8, "view_holdings": 0.5, "view_insights": 0.35, "ask_ai": 0.15,
                "view_transactions": 0.3, "view_product": 0.05, "view_sip": 0.2, "view_reports": 0.12,
                "tap_call_rm": 0.05}
        for j in range(k):
            name = weighted(menu)
            t = t + timedelta(seconds=rng.randint(20, 240))
            if name == "view_product":
                elig = eligible_products(c) or ["P08"]
                pid = rng.choice(elig)
                E.append(ev(c, t, name, f"product/{pid}", sid, product_id=pid, platform=platform))
            else:
                E.append(ev(c, t, name, name.replace("view_", ""), sid, platform=platform))
        for (name, screen, pid) in (extra or []):
            t = t + timedelta(seconds=rng.randint(20, 240))
            E.append(ev(c, t, name, screen, sid, product_id=pid, platform=platform))

    # baseline sessions over 60 days
    for day in range(1, 61):
        p_open = rate / 7.0
        if f["engagement_drop"] and day <= 14:
            p_open *= 0.15
        if rng.random() < p_open:
            session(day - rng.random())

    # churn intent: withdraw screens in the last 14 days
    if f["churn"]:
        for _ in range(rng.randint(1, 3)):
            extra = [("view_withdraw", "withdraw", "")]
            if rng.random() < 0.5:
                extra.append(("initiate_redeem", "withdraw/confirm", ""))
            if c.redeem_days_ago:   # the warning comes before the money leaves
                when = c.redeem_days_ago + rng.uniform(0.5, 6.0)
            else:
                when = rng.uniform(0.5, 13.5)
            session(when, extra=extra, n_extra_random=rng.randint(1, 3))

    # buy intent: repeated views of one exclusive product in the last 10 days
    if f["buy_intent"]:
        elig = eligible_products(c)
        if elig:
            pid = rng.choice(elig)
            c.interest_product = c.interest_product or pid
            for _ in range(rng.randint(2, 5)):
                session(rng.uniform(0.3, 9.5), extra=[("view_product", f"product/{pid}", pid)], n_extra_random=rng.randint(0, 2))

    # product interest (for closing-soon products)
    if f["product_interest"]:
        elig = [p for p in eligible_products(c) if p in ("P04", "P06")]
        if elig:
            pid = rng.choice(elig)
            c.interest_product = c.interest_product or pid
            session(rng.uniform(1, 28), extra=[("view_product", f"product/{pid}", pid)], n_extra_random=1)

    # onboarding journeys
    if f["onboarding_stuck"]:
        start = rng.uniform(3, 20)
        stuck_at = weighted({"onb_bank_mandate": 0.55, "onb_fatca": 0.25, "onb_nominee": 0.12, "onb_kyc": 0.08})
        _journey(c, E, platform, start, stop_after=stuck_at, sess_no_ref=[sess_no])
    return E


def _journey(c: Client, E: list[dict], platform: str, start_days_ago: float, stop_after: str | None,
             sess_no_ref: list[int]) -> None:
    """Emit an MF onboarding journey. stop_after = last step reached (None = completed)."""
    sess_no_ref[0] += 1
    sid = f"{c.client_id}-onb{sess_no_ref[0]:02d}"
    t = ts_ago(start_days_ago)
    E.append(ev(c, t, "onb_start", "onboarding/start", sid, platform=platform))
    for step in ONB_STEPS:
        t = t + timedelta(minutes=rng.randint(2, 25))
        E.append(ev(c, t, step, f"onboarding/{step[4:]}", sid, platform=platform))
        if step == stop_after:
            break


def build_funnel_journeys(clients: list[Client]) -> list[dict]:
    """Historical onboarding journeys (last 90 days) so the funnel has volume."""
    E: list[dict] = []
    pool = [c for c in clients if not c.flags["onboarding_stuck"]]
    for c in rng.sample(pool, 76):
        platform = rng.choice(["iOS", "Android", "Web"])
        completed = rng.random() < 0.56
        stop = None if completed else weighted({"onb_kyc": 0.15, "onb_fatca": 0.25, "onb_bank_mandate": 0.45, "onb_nominee": 0.15})
        _journey(c, E, platform, rng.uniform(21, 90), stop, [50])
    return E


# --------------------------------------------------------------------------------------
# cash snapshots
# --------------------------------------------------------------------------------------
def build_cash_snapshots(c: Client) -> list[dict]:
    rows = []
    f = c.flags
    base = c.cash
    series = []
    if f["idle_cash"] or f["onboarding_stuck"]:
        series = [base * rng.uniform(0.97, 1.03) for _ in range(12)]
        series[-1] = base
    elif f["liquidity_event"]:
        lo, hi = {"Affluent": (20 * L, 60 * L), "HNI": (50 * L, 2.5 * CR), "UHNI": (2 * CR, 8 * CR)}[c.segment]
        jump = round_inr(rng.uniform(lo, hi), 10_000)
        event_week = rng.choice([0, 1, 1, 2])   # weeks ago
        small = base
        series = [small * rng.uniform(0.9, 1.1) for _ in range(12)]
        for w in range(12):
            weeks_ago = 11 - w
            if weeks_ago <= event_week:
                series[w] = small + jump
        c.cash = round_inr(small + jump, 1000)
        c.aum = c.aum + jump
        series[-1] = c.cash
    else:
        # random walk, occasionally a dip (money got deployed 3-5 weeks ago)
        level = base * rng.uniform(1.0, 1.3) if rng.random() < 0.2 else base
        drop_week = rng.randint(3, 5) if level != base else None
        for w in range(12):
            weeks_ago = 11 - w
            if drop_week is not None and weeks_ago < drop_week:
                level = base
            series.append(level * rng.uniform(0.94, 1.06))
        series[-1] = base
    for w in range(12):
        weeks_ago = 11 - w
        rows.append({"client_id": c.client_id, "as_of": (AS_OF - timedelta(days=7 * weeks_ago)).isoformat(),
                     "ledger_balance": round_inr(max(series[w], 0), 1000)})
    return rows


# --------------------------------------------------------------------------------------
# write
# --------------------------------------------------------------------------------------
def write_csv(name: str, rows: list[dict], fields: list[str]) -> None:
    path = os.path.join(OUT_DIR, f"{name}.csv")
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def main() -> None:
    os.makedirs(OUT_DIR, exist_ok=True)
    clients = make_clients()
    holdings, sips, txns, inters, events, cash = [], [], [], [], [], []
    for c in clients:
        build_holdings(c)
        build_sips(c)
    for c in clients:
        cash.extend(build_cash_snapshots(c))   # may bump aum/cash for liquidity events
    for c in clients:
        holdings.extend(c.holdings)
        sips.extend(c.sips)
        txns.extend(build_transactions(c))
        events.extend(build_app_events(c))      # sets interest_product
        inters.extend(build_interactions(c, c.rm_id))
    events.extend(build_funnel_journeys(clients))

    write_csv("rms", [{"rm_id": r[0], "name": r[1], "region": r[2], "tenure_months": r[3],
                       "email": r[1].lower().replace(" ", ".") + "@pulse.demo"} for r in RMS],
              ["rm_id", "name", "region", "tenure_months", "email"])
    write_csv("clients", [{
        "client_id": c.client_id, "name": c.name, "rm_id": c.rm_id, "segment": c.segment,
        "risk_profile": c.risk_profile, "ips_equity_target": c.ips_equity_target, "city": c.city, "age": c.age,
        "occupation": c.occupation, "onboarded_on": c.onboarded_on.isoformat(),
        "last_review_on": c.last_review_on.isoformat(), "kyc_status": c.kyc_status,
        "engagement_tier": c.engagement,
    } for c in clients], ["client_id", "name", "rm_id", "segment", "risk_profile", "ips_equity_target", "city", "age",
                          "occupation", "onboarded_on", "last_review_on", "kyc_status", "engagement_tier"])
    write_csv("holdings", holdings, ["holding_id", "client_id", "asset_class", "instrument", "category", "sector",
                                     "manager", "invested_value", "current_value", "purchase_date", "lock_in_until",
                                     "is_equity"])
    write_csv("sips", sips, ["sip_id", "client_id", "instrument", "amount", "start_date", "end_date", "status",
                             "mandate_expiry", "last_debit_status", "next_due"])
    txns.sort(key=lambda t: t["txn_date"])
    write_csv("transactions", txns, ["txn_id", "client_id", "txn_date", "txn_type", "asset_class", "instrument",
                                     "amount", "channel", "status"])
    inters.sort(key=lambda i: i["occurred_on"])
    write_csv("interactions", inters, ["interaction_id", "client_id", "rm_id", "occurred_on", "channel", "summary",
                                       "outcome", "next_action", "next_action_on", "product_id"])
    events.sort(key=lambda e: e["ts"])
    write_csv("app_events", events, ["event_id", "client_id", "ts", "event_name", "screen", "product_id",
                                     "session_id", "platform"])
    write_csv("cash_snapshots", cash, ["client_id", "as_of", "ledger_balance"])
    write_csv("products", [{
        "product_id": p[0], "name": p[1], "type": p[2], "strategy": p[3], "manager": p[4], "min_ticket": p[5],
        "suitable_for": p[6], "status": p[7], "closes_on": (AS_OF + timedelta(days=p[8])).isoformat() if p[8] else "",
        "note": p[9],
    } for p in PRODUCTS], ["product_id", "name", "type", "strategy", "manager", "min_ticket", "suitable_for", "status",
                           "closes_on", "note"])
    write_csv("meta", [{"as_of": AS_OF.isoformat(), "generator_seed": SEED}], ["as_of", "generator_seed"])

    flag_counts = {k: sum(1 for c in clients if c.flags[k]) for k in clients[0].flags}
    manifest = {
        "as_of": AS_OF.isoformat(), "seed": SEED,
        "rows": {"rms": len(RMS), "clients": len(clients), "holdings": len(holdings), "sips": len(sips),
                 "transactions": len(txns), "interactions": len(inters), "app_events": len(events),
                 "cash_snapshots": len(cash), "products": len(PRODUCTS)},
        "planted_stories": flag_counts,
        "total_aum_inr": round(sum(sum(h["current_value"] for h in c.holdings) + c.cash for c in clients)),
    }
    with open(os.path.join(OUT_DIR, "manifest.json"), "w") as fh:
        json.dump(manifest, fh, indent=2)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
