#!/usr/bin/env python3
"""
Static build of Pulse for hosting without a server (e.g. as a claude.ai Artifact).

Pre-renders every page through the FastAPI app, embeds the book as an in-browser SQLite database
(so the SQL console and Ask STORM still run), and ships the prompt context + template brief for every
client. In the published page, Claude features run through the viewer's own claude.ai account
(`claude.use("sample")`); without it the page degrades to template briefs and canned queries.

    python scripts/build_static.py    # writes dist/
"""
from __future__ import annotations

import base64
import json
import os
import re
import sqlite3
import sys
from datetime import date, datetime

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)
DIST = os.path.join(ROOT, "dist")

from app import ai, db  # noqa: E402
from app.engine import CATALOG  # noqa: E402

SQLITE_SCHEMA_DOC = """Tables (SQLite; dates are TEXT 'YYYY-MM-DD', timestamps TEXT 'YYYY-MM-DD HH:MM:SS', money is INR as REAL):
- rms(rm_id, name, region, tenure_months, email)
- clients(client_id, name, rm_id, segment['Affluent'|'HNI'|'UHNI'], risk_profile['Conservative'|'Moderate'|'Aggressive'], ips_equity_target, city, age, occupation, onboarded_on, last_review_on, kyc_status, engagement_tier)
- holdings(holding_id, client_id, asset_class['Equity MF'|'Debt MF'|'Hybrid MF'|'Direct Equity'|'PMS'|'AIF'|'Unlisted'|'FD'|'Bonds'], instrument, category, sector, manager, invested_value, current_value, purchase_date, lock_in_until, is_equity)
- cash_snapshots(client_id, as_of, ledger_balance)  -- weekly; latest = idle cash in the wealth account
- sips(sip_id, client_id, instrument, amount, start_date, end_date, status, mandate_expiry, last_debit_status, next_due)
- transactions(txn_id, client_id, txn_date, txn_type, asset_class, instrument, amount, channel, status)
- interactions(interaction_id, client_id, rm_id, occurred_on, channel, summary, outcome, next_action, next_action_on, product_id)
- app_events(event_id, client_id, ts, event_name, screen, product_id, session_id, platform)  -- client-app analytics
- products(product_id, name, type['PMS'|'AIF'|'Unlisted'], strategy, manager, min_ticket, suitable_for, status, closes_on, note)
- signals(signal_id, client_id, signal_type, family, headline, rm_action, impact_inr, urgency, conversion_prior, expected_value_inr, deadline_on, evidence_json)  -- the engine's output
- v_client_aum(client_id, aum, invested_aum, equity_value, cash, equity_pct, equity_pct_invested)
- v_last_contact(client_id, last_contact_on, days_since_contact)
- v_client_priority(client_id, rm_id, name, segment, risk_profile, aum, cash, signal_count, expected_value_inr, impact_inr, max_urgency, signal_types, top_signal, top_headline, top_action, next_deadline, days_since_contact)
Functions: as_of() returns the book date '2026-09-13'. Date math is SQLite: date(as_of(), '-14 days'), julianday(as_of()) - julianday(d) for day differences, strftime('%Y-%m', d).
Not available: INTERVAL, FILTER (use SUM(CASE WHEN ... THEN 1 ELSE 0 END)), list functions, string_agg (use group_concat).
signal_type values: idle_cash, liquidity_event, buy_intent, product_closing, lockin_maturity, onboarding_stuck, churn_risk, sip_at_risk, concentration_risk, allocation_drift, fund_overlap, tax_harvest, overdue_review."""


def _sqlite_value(v):
    if v is None or isinstance(v, (int, float, str)):
        return v
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    return str(v)


def build_sqlite(path: str) -> None:
    if os.path.exists(path):
        os.remove(path)
    lite = sqlite3.connect(path)
    tables = ["rms", "clients", "holdings", "cash_snapshots", "sips", "transactions", "interactions", "app_events",
              "products", "meta", "signals", "v_client_aum", "v_last_contact", "v_client_priority"]
    for t in tables:
        rows = db.q(f"SELECT * FROM {t}")
        if not rows:
            continue
        cols = list(rows[0].keys())
        # infer a column type from the first non-null value
        types = []
        for c in cols:
            sample = next((r[c] for r in rows if r[c] is not None), None)
            types.append("INTEGER" if isinstance(sample, int) and not isinstance(sample, bool)
                         else "REAL" if isinstance(sample, float) else "TEXT")
        lite.execute(f"CREATE TABLE {t} ({', '.join(f'{c} {ty}' for c, ty in zip(cols, types))})")
        lite.executemany(f"INSERT INTO {t} VALUES ({', '.join('?' for _ in cols)})",
                         [[_sqlite_value(r[c]) for c in cols] for r in rows])
    for stmt in ["CREATE INDEX ix_h_client ON holdings(client_id)", "CREATE INDEX ix_e_client ON app_events(client_id)",
                 "CREATE INDEX ix_e_name ON app_events(event_name)", "CREATE INDEX ix_t_client ON transactions(client_id)",
                 "CREATE INDEX ix_i_client ON interactions(client_id)", "CREATE INDEX ix_s_client ON signals(client_id)",
                 "CREATE INDEX ix_c_rm ON clients(rm_id)"]:
        lite.execute(stmt)
    lite.commit()
    lite.execute("VACUUM")
    lite.close()


MAIN_RE = re.compile(r'<main class="content">(.*?)</main>', re.S)
TITLE_RE = re.compile(r"<title>(.*?) · Pulse</title>", re.S)


def main() -> None:
    os.makedirs(DIST, exist_ok=True)
    db.connect()

    # The rendered badges should say "Claude": in the published page Claude runs through the viewer's account.
    ai.ai_status = lambda: {"live": True, "model": "claude", "label": "Claude via claude.ai"}
    ai.SCHEMA_DOC = SQLITE_SCHEMA_DOC
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)

    rms = db.q("SELECT rm_id, name, region FROM rms ORDER BY rm_id")
    clients = db.q("SELECT client_id FROM clients ORDER BY client_id")
    pages: dict[str, dict] = {}

    def grab(path: str, key: str, kind: str, rm_id: str = "RM01") -> None:
        client.cookies.set("pulse_rm", rm_id)
        r = client.get(path)
        assert r.status_code == 200, (path, r.status_code)
        html = r.text
        m = MAIN_RE.search(html)
        t = TITLE_RE.search(html)
        pages[key] = {"title": t.group(1) if t else "Pulse", "kind": kind, "html": m.group(1).strip()}

    for rm in rms:
        rid = rm["rm_id"]
        grab("/", f"/brief/{rid}", "brief", rid)
        grab("/signals", f"/signals@{rid}", "signals", rid)
        grab("/ask", f"/ask@{rid}", "ask", rid)
        for stype in CATALOG:
            grab(f"/signals/{stype}", f"/signals/{stype}@{rid}", "signal", rid)
    for c in clients:
        grab(f"/clients/{c['client_id']}", f"/clients/{c['client_id']}", "client")
    grab("/analytics", "/analytics", "analytics")
    grab("/about", "/about", "about")
    pages["/404"] = {"title": "Not found", "kind": "plain",
                     "html": '<div class="card empty">That page isn\'t in this build. <a href="/">Back to the Morning brief</a></div>'}

    contexts, briefs = {}, {}
    for c in clients:
        ctx = ai.client_context(c["client_id"])
        contexts[c["client_id"]] = ai._prompt_context(ctx)
        briefs[c["client_id"]] = ai._brief_template(ctx)

    canned = {}
    for rm in rms:
        out = []
        for keys, label, sql in ai.CANNED:
            res = ai.run_sql(sql.format(rm=rm["rm_id"]), max_rows=50)
            out.append({"keys": keys, "label": label, "sql": res["sql"], "columns": res["columns"], "rows": res["rows"]})
        top = ai.run_sql("SELECT name, segment, aum, signal_count, top_signal, top_headline, expected_value_inr FROM v_client_priority "
                         f"WHERE rm_id='{rm['rm_id']}' ORDER BY expected_value_inr DESC", max_rows=50)
        out.append({"keys": [], "label": "Your top priorities today (by expected value).", "sql": top["sql"],
                    "columns": top["columns"], "rows": top["rows"]})
        canned[rm["rm_id"]] = out

    lite_path = os.path.join(DIST, "pulse.sqlite")
    build_sqlite(lite_path)
    with open(lite_path, "rb") as fh:
        b64 = base64.b64encode(fh.read()).decode("ascii")
    os.remove(lite_path)

    book = {
        "as_of": str(db.scalar("SELECT as_of FROM meta")),
        "rms": {r["rm_id"]: r for r in rms},
        "contexts": contexts, "briefs": briefs, "canned": canned,
        "brief_system": ai.BRIEF_SYSTEM, "ask_schema": SQLITE_SCHEMA_DOC,
        "suggested": ai.SUGGESTED_QUESTIONS,
        "sqlite_b64": b64,
    }
    with open(os.path.join(DIST, "pages.js"), "w", encoding="utf-8") as fh:
        fh.write("window.PAGES = " + json.dumps(pages, ensure_ascii=False) + ";\n")
    with open(os.path.join(DIST, "book.js"), "w", encoding="utf-8") as fh:
        fh.write("window.BOOK = " + json.dumps(book, ensure_ascii=False) + ";\n")
    with open(os.path.join(ROOT, "app", "static", "app.js"), encoding="utf-8") as src, \
         open(os.path.join(DIST, "app.js"), "w", encoding="utf-8") as dst:
        dst.write(src.read())
    with open(os.path.join(ROOT, "app", "static", "app.css"), encoding="utf-8") as fh:
        css = fh.read()
    with open(os.path.join(ROOT, "scripts", "static_shell.html"), encoding="utf-8") as fh:
        shell = fh.read()
    with open(os.path.join(DIST, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(shell.replace("/*__APP_CSS__*/", css))
    sizes = {f: os.path.getsize(os.path.join(DIST, f)) for f in os.listdir(DIST)}
    print(json.dumps({"pages": len(pages), "clients": len(contexts), "sizes_kb": {k: v // 1024 for k, v in sizes.items()}}, indent=2))


if __name__ == "__main__":
    main()
