#!/usr/bin/env python3
"""Render docs/SIGNALS.md from the catalog in app/engine.py, so the docs never drift from the code."""
from __future__ import annotations

import os
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)

from app.engine import ASSUMPTIONS, CATALOG, FAMILY_LABEL, MATH, sql_for  # noqa: E402

CLIENT_FACING = {k: bool(v.get("client_copy")) for k, v in CATALOG.items()}

out = ["# Signal catalog", "",
       "Generated from `app/engine.py` by `scripts/build_signal_docs.py` — edit the code, not this file.", "",
       "Every signal is one SQL file in `app/signals/` that returns, per client:", "",
       "```", "client_id, impact_inr, urgency (0-1), deadline_on (nullable DATE), ...evidence columns", "```", "",
       "The engine scores each row as **expected value = impact_inr × conversion prior × urgency** and sums per client.",
       "The Morning Brief ranks clients by that sum; the RM sees the top 10 (`daily_capacity_per_rm`).", "",
       "## Global assumptions", "", "| Knob | Value | Why |", "|---|---|---|",
       f"| Blended fee rate | {ASSUMPTIONS['blended_fee_rate']:.1%} | revenue ≈ AUM × fee (MF trail + PMS/AIF fees, blended) — for the 'revenue impact' lens only |",
       f"| Churn attrition if ignored | {ASSUMPTIONS['churn_attrition_if_ignored']:.0%} | share of AUM assumed lost when a churn signal goes unaddressed |",
       f"| Idle-cash yield gap | {ASSUMPTIONS['idle_cash_yield_gap']:.1%} | savings/current account vs liquid fund |",
       f"| Daily capacity per RM | {ASSUMPTIONS['daily_capacity_per_rm']} | meaningful conversations an RM can have in a day |",
       "", "## Priors — assumptions to be measured", "",
       "Conversion priors are my starting estimates of how often an RM action on each signal type produces an outcome. "
       "They are deliberately rough. The Morning Brief's Done / Snooze / Not relevant buttons log outcomes per signal type; "
       "after the pilot, priors and thresholds are re-fit monthly from those outcomes.", ""]

for fam in ("opportunity", "retention", "portfolio", "relationship"):
    out += [f"## {FAMILY_LABEL[fam]}", ""]
    for key, m in CATALOG.items():
        if m["family"] != fam:
            continue
        trig, imp, urg = MATH[key]
        out += [f"### {m['icon']} {m['title']} · `{key}`", "",
                m["blurb"], "",
                "| | |", "|---|---|",
                f"| Fires when | {trig} |",
                f"| ₹ in play | {imp} |",
                f"| Urgency | {urg} |",
                f"| Conversion prior | {m['prior']:.0%} |",
                f"| RM playbook | {m['rm_action']} |",
                f"| Shown to the client? | {'Yes — as an insight card in the client app' if CLIENT_FACING[key] else 'No — RM-only'} |",
                "", "<details><summary>SQL</summary>", "", "```sql", sql_for(key).strip(), "```", "", "</details>", ""]

out += ["## False positives I expect, and what to do about them", "",
        "- **Idle cash** — money earmarked for a known purchase (property, tax). Fix: an RM 'snooze until <date>' with a reason, and a client-set 'earmarked' flag in the app.",
        "- **Churn risk** — a client checking the withdraw screen to *understand* it, not to leave. Fix: require intent + silence (already), and log 'Not relevant' reasons to tune the threshold.",
        "- **Concentration** — promoter holdings that are structurally illiquid. Fix: an 'acknowledged concentration' flag on the IPS so it stops firing.",
        "- **Overdue review** — contact happened but wasn't logged. Fix: this is a STORM data-quality metric in its own right; surface it to sales leadership.",
        "- **Buy intent** — an RM already spoke about the product by phone without logging. Same fix as above; the 10-day interaction check is the guard.",
        ""]

path = os.path.join(ROOT, "docs", "SIGNALS.md")
with open(path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(out))
print(f"wrote {path} ({len(out)} lines)")
