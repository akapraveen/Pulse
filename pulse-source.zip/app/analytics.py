"""
Book-health diagnostics — the "find what's broken" half of the job.

Each function is one SQL question a PM would ask of STORM's data on day one. They return plain
dicts so the analytics page can render numbers + charts, and so the numbers can be quoted in the
case study. Every query is readable on its own; that is deliberate.
"""
from __future__ import annotations

from app.db import q, q1, scalar
from app.engine import ASSUMPTIONS

FEE = ASSUMPTIONS["blended_fee_rate"]


def coverage_gap() -> dict:
    buckets = q("""
        WITH base AS (
            SELECT c.client_id, c.segment, a.aum, COALESCE(lc.days_since_contact, 999) AS d
            FROM clients c JOIN v_client_aum a USING (client_id) LEFT JOIN v_last_contact lc USING (client_id)
        )
        SELECT CASE WHEN d <= 30 THEN '0-30 days' WHEN d <= 60 THEN '31-60 days'
                    WHEN d <= 90 THEN '61-90 days' ELSE '90+ days' END AS bucket,
               MIN(CASE WHEN d <= 30 THEN 1 WHEN d <= 60 THEN 2 WHEN d <= 90 THEN 3 ELSE 4 END) AS ord,
               COUNT(*) AS clients, SUM(aum) AS aum,
               ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM base), 1) AS pct_clients,
               ROUND(100.0 * SUM(aum) / (SELECT SUM(aum) FROM base), 1) AS pct_aum
        FROM base GROUP BY 1 ORDER BY ord
    """)
    over60 = q1("""
        SELECT COUNT(*) AS clients, SUM(a.aum) AS aum,
               ROUND(100.0 * SUM(a.aum) / (SELECT SUM(aum) FROM v_client_aum), 1) AS pct_aum
        FROM clients c JOIN v_client_aum a USING (client_id) LEFT JOIN v_last_contact lc USING (client_id)
        WHERE COALESCE(lc.days_since_contact, 999) > 60
    """)
    by_rm = q("""
        SELECT r.rm_id, r.name, COUNT(*) AS clients,
               COUNT(*) FILTER (WHERE COALESCE(lc.days_since_contact, 999) > 60) AS silent_60,
               ROUND(100.0 * SUM(a.aum) FILTER (WHERE COALESCE(lc.days_since_contact, 999) > 60) / SUM(a.aum), 1) AS pct_aum_silent
        FROM rms r JOIN clients c USING (rm_id) JOIN v_client_aum a USING (client_id)
        LEFT JOIN v_last_contact lc USING (client_id)
        GROUP BY 1, 2 ORDER BY 1
    """)
    return {"buckets": buckets, "over60": over60, "by_rm": by_rm}


def onboarding_funnel() -> dict:
    steps = ["onb_start", "onb_kyc", "onb_fatca", "onb_bank_mandate", "onb_nominee", "onb_complete"]
    labels = {"onb_start": "Started", "onb_kyc": "KYC", "onb_fatca": "FATCA", "onb_bank_mandate": "Bank e-mandate",
              "onb_nominee": "Nominee", "onb_complete": "Completed"}
    rows = q("""
        SELECT event_name, COUNT(DISTINCT session_id) AS journeys
        FROM app_events
        WHERE event_name LIKE 'onb_%' AND ts >= as_of() - INTERVAL 90 DAY
        GROUP BY 1
    """)
    counts = {r["event_name"]: r["journeys"] for r in rows}
    funnel, prev, prev_label = [], None, None
    for s in steps:
        n = counts.get(s, 0)
        step_conv = round(100.0 * n / prev, 1) if prev else 100.0
        funnel.append({"step": labels[s], "journeys": n, "step_conversion": step_conv,
                       "drop": (prev - n) if prev else 0,          # people who reached the previous step and stalled there
                       "stalled_at": prev_label,
                       "overall": round(100.0 * n / max(counts.get("onb_start", 1), 1), 1)})
        prev, prev_label = (n if n else prev), labels[s]
    worst = max(funnel[1:], key=lambda x: x["drop"]) if len(funnel) > 1 else None
    ttc = q1("""
        WITH j AS (
            SELECT session_id, MIN(ts) AS s, MAX(ts) FILTER (WHERE event_name = 'onb_complete') AS e
            FROM app_events WHERE event_name LIKE 'onb_%' AND ts >= as_of() - INTERVAL 90 DAY GROUP BY 1
        )
        SELECT ROUND(median(datediff('minute', s, e)), 0) AS median_minutes FROM j WHERE e IS NOT NULL
    """)
    stalled_value = q1("""
        SELECT COUNT(*) AS clients, SUM(impact_inr) AS expected_first_ticket
        FROM signals WHERE signal_type = 'onboarding_stuck'
    """)
    return {"funnel": funnel, "worst": worst, "median_minutes": ttc["median_minutes"] if ttc else None,
            "stalled": stalled_value}


def idle_cash() -> dict:
    tot = q1("""
        SELECT COUNT(*) AS clients, SUM(impact_inr) AS idle_inr,
               SUM(impact_inr) * ? AS annual_drag_inr, SUM(impact_inr) * ? AS annual_revenue_inr
        FROM signals WHERE signal_type = 'idle_cash'
    """, [ASSUMPTIONS["idle_cash_yield_gap"], FEE])
    liq = q1("SELECT COUNT(*) AS clients, SUM(impact_inr) AS inflow_inr FROM signals WHERE signal_type = 'liquidity_event'")
    all_cash = q1("""
        SELECT SUM(cash) AS total_cash, ROUND(100.0 * SUM(cash) / SUM(aum), 1) AS pct_of_aum FROM v_client_aum
    """)
    by_seg = q("""
        SELECT c.segment, COUNT(*) AS clients, SUM(s.impact_inr) AS idle_inr
        FROM signals s JOIN clients c USING (client_id) WHERE s.signal_type = 'idle_cash'
        GROUP BY 1 ORDER BY idle_inr DESC
    """)
    return {"total": tot, "liquidity": liq, "all_cash": all_cash, "by_segment": by_seg}


def intent_leakage() -> dict:
    row = q1("""
        WITH views AS (
            SELECT e.client_id, e.product_id, COUNT(*) AS views
            FROM app_events e
            WHERE e.event_name = 'view_product' AND e.product_id <> '' AND e.ts >= as_of() - INTERVAL 30 DAY
            GROUP BY 1, 2 HAVING COUNT(*) >= 2
        ),
        discussed AS (
            SELECT DISTINCT client_id, product_id FROM interactions
            WHERE product_id <> '' AND occurred_on >= as_of() - INTERVAL 30 DAY
        )
        SELECT COUNT(*) AS interested_pairs,
               COUNT(*) FILTER (WHERE d.client_id IS NULL) AS never_discussed,
               ROUND(100.0 * COUNT(*) FILTER (WHERE d.client_id IS NULL) / COUNT(*), 0) AS pct_never_discussed,
               SUM(p.min_ticket) FILTER (WHERE d.client_id IS NULL) AS min_tickets_inr
        FROM views v
        JOIN products p USING (product_id)
        LEFT JOIN discussed d ON d.client_id = v.client_id AND d.product_id = v.product_id
    """)
    by_product = q("""
        SELECT p.name, p.type, COUNT(DISTINCT e.client_id) AS clients_viewing
        FROM app_events e JOIN products p USING (product_id)
        WHERE e.event_name = 'view_product' AND e.ts >= as_of() - INTERVAL 30 DAY
        GROUP BY 1, 2 ORDER BY 3 DESC LIMIT 6
    """)
    return {"summary": row, "by_product": by_product}


def redemption_lead_indicator() -> dict:
    """Did the app warn us before money left? Withdraw-screen views in the 14 days before a redemption."""
    return q1("""
        WITH red AS (
            SELECT client_id, txn_date, amount FROM transactions
            WHERE txn_type = 'Redeem' AND status = 'Completed' AND txn_date >= as_of() - INTERVAL 60 DAY
        )
        SELECT COUNT(*) AS redemptions, SUM(amount) AS amount,
               COUNT(*) FILTER (WHERE EXISTS (
                   SELECT 1 FROM app_events e WHERE e.client_id = red.client_id
                     AND e.event_name IN ('view_withdraw', 'initiate_redeem')
                     AND e.ts::DATE BETWEEN red.txn_date - INTERVAL 14 DAY AND red.txn_date)) AS with_warning,
               COUNT(*) FILTER (WHERE NOT EXISTS (
                   SELECT 1 FROM interactions i WHERE i.client_id = red.client_id
                     AND i.occurred_on BETWEEN red.txn_date - INTERVAL 21 DAY AND red.txn_date)) AS no_contact_before
        FROM red
    """)


def rm_load() -> list[dict]:
    return q("""
        SELECT r.rm_id, r.name, r.region, r.tenure_months,
               COUNT(DISTINCT c.client_id) AS clients,
               SUM(a.aum) AS aum,
               COUNT(DISTINCT c.client_id) FILTER (WHERE c.segment = 'UHNI') AS uhni,
               (SELECT COUNT(*) FROM interactions i JOIN clients cc USING (client_id)
                 WHERE cc.rm_id = r.rm_id AND i.occurred_on >= as_of() - INTERVAL 30 DAY) AS touches_30d,
               (SELECT COUNT(*) FROM signals s JOIN clients cc USING (client_id) WHERE cc.rm_id = r.rm_id) AS open_signals,
               (SELECT COUNT(DISTINCT client_id) FROM v_client_priority p WHERE p.rm_id = r.rm_id) AS clients_flagged,
               (SELECT SUM(expected_value_inr) FROM v_client_priority p WHERE p.rm_id = r.rm_id) AS ev_inr
        FROM rms r JOIN clients c USING (rm_id) JOIN v_client_aum a USING (client_id)
        GROUP BY 1, 2, 3, 4 ORDER BY 1
    """)


def signal_mix() -> list[dict]:
    return q("""
        SELECT signal_type, family, COUNT(*) AS n, SUM(impact_inr) AS impact_inr, SUM(expected_value_inr) AS ev_inr
        FROM signals GROUP BY 1, 2 ORDER BY ev_inr DESC
    """)


def book_summary() -> dict:
    return q1("""
        SELECT (SELECT COUNT(*) FROM clients) AS clients, (SELECT COUNT(*) FROM rms) AS rms,
               (SELECT SUM(aum) FROM v_client_aum) AS aum,
               (SELECT COUNT(*) FROM signals) AS signals,
               (SELECT COUNT(DISTINCT client_id) FROM signals) AS clients_flagged,
               (SELECT SUM(expected_value_inr) FROM signals) AS ev_inr,
               (SELECT SUM(impact_inr) FROM signals) AS impact_inr,
               (SELECT as_of FROM meta) AS as_of
    """)
