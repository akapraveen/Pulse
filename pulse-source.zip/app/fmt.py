"""Indian-number formatting helpers shared by the engine, templates and AI prompts."""
from __future__ import annotations

from datetime import date, datetime


def inr(x, compact: bool = True) -> str:
    """₹4.2 Cr / ₹38 L / ₹85,000 — the way an Indian RM reads money."""
    if x is None:
        return "—"
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    sign = "-" if x < 0 else ""
    x = abs(x)
    if x >= 1e7:
        v = x / 1e7
        s = f"{v:.2f}".rstrip("0").rstrip(".") if v < 100 else f"{v:,.0f}"
        return f"{sign}₹{s} Cr"
    if x >= 1e5:
        v = x / 1e5
        s = f"{v:.1f}".rstrip("0").rstrip(".")
        return f"{sign}₹{s} L"
    return f"{sign}₹{x:,.0f}"


def pct(x, digits: int = 0) -> str:
    if x is None:
        return "—"
    return f"{float(x):.{digits}f}%"


def dmy(d) -> str:
    """13 Sep 2026"""
    if d is None or d == "":
        return "—"
    if isinstance(d, str):
        try:
            d = datetime.fromisoformat(d)
        except ValueError:
            return d
    if isinstance(d, datetime):
        d = d.date()
    if isinstance(d, date):
        return d.strftime("%d %b %Y").lstrip("0")
    return str(d)


def days_word(n) -> str:
    if n is None:
        return "—"
    n = int(n)
    if n == 0:
        return "today"
    if n == 1:
        return "1 day"
    return f"{n} days"
