"""
Pulse — FastAPI app.

Server-rendered pages (Jinja2) over DuckDB, plus three JSON endpoints the pages call:
  POST /api/brief   → Claude call brief for a client
  POST /api/ask     → NL → SQL agent
  POST /api/sql     → read-only SQL console

The "current RM" is a cookie (set via /set-rm) so the whole app is one RM's view, like STORM.
"""
from __future__ import annotations

import json
import os
from datetime import datetime

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from app import ai, analytics, db
from app.engine import ASSUMPTIONS, CATALOG, FAMILY_LABEL, catalog_list, signal_meta, sql_for
from app.fmt import days_word, dmy, inr, pct

HERE = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="Pulse", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(HERE, "templates"))
templates.env.filters.update({"inr": inr, "pct": pct, "dmy": dmy, "days": days_word})
templates.env.globals.update({"FAMILY_LABEL": FAMILY_LABEL, "CATALOG": CATALOG, "ASSUMPTIONS": ASSUMPTIONS})


def _static_version() -> str:
    """Cache-buster for the CSS/JS links: changes whenever a static file changes."""
    st = os.path.join(HERE, "static")
    return str(int(max(os.path.getmtime(os.path.join(st, f)) for f in os.listdir(st))))


templates.env.globals["static_v"] = _static_version()

DEFAULT_RM = "RM01"


@app.on_event("startup")
def _warm() -> None:
    db.connect()


# ------------------------------------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------------------------------------
def current_rm(request: Request) -> dict:
    rm_id = request.query_params.get("rm") or request.cookies.get("pulse_rm") or DEFAULT_RM
    rm = db.q1("""
        SELECT r.*, COUNT(c.client_id) AS clients, SUM(a.aum) AS aum
        FROM rms r LEFT JOIN clients c USING (rm_id) LEFT JOIN v_client_aum a USING (client_id)
        WHERE r.rm_id = ? GROUP BY ALL
    """, [rm_id])
    if not rm:
        rm = db.q1("SELECT r.*, COUNT(c.client_id) AS clients, SUM(a.aum) AS aum FROM rms r LEFT JOIN clients c USING (rm_id) "
                   "LEFT JOIN v_client_aum a USING (client_id) WHERE r.rm_id = ? GROUP BY ALL", [DEFAULT_RM])
    return rm


def base_ctx(request: Request, page: str, title: str) -> dict:
    rm = current_rm(request)
    return {
        "request": request, "page": page, "title": title, "rm": rm,
        "rms": db.q("SELECT rm_id, name, region FROM rms ORDER BY rm_id"),
        "as_of": db.scalar("SELECT as_of FROM meta"),
        "ai": ai.ai_status(),
        "book": analytics.book_summary(),
    }


def render(name: str, ctx: dict) -> HTMLResponse:
    resp = templates.TemplateResponse(ctx["request"], name, ctx)
    resp.set_cookie("pulse_rm", ctx["rm"]["rm_id"], max_age=60 * 60 * 24 * 30, samesite="lax")
    return resp


def greeting() -> str:
    h = datetime.now().hour
    return "Good morning" if h < 12 else ("Good afternoon" if h < 17 else "Good evening")


# ------------------------------------------------------------------------------------------------
# pages
# ------------------------------------------------------------------------------------------------
@app.get("/set-rm")
def set_rm(rm: str, next: str = "/"):
    resp = RedirectResponse(url=next if next.startswith("/") else "/", status_code=303)
    resp.set_cookie("pulse_rm", rm, max_age=60 * 60 * 24 * 30, samesite="lax")
    return resp


@app.get("/", response_class=HTMLResponse)
def morning_brief(request: Request):
    ctx = base_ctx(request, "brief", "Morning brief")
    rm_id = ctx["rm"]["rm_id"]
    clients = db.q("""
        SELECT p.*, lc.last_contact_on
        FROM v_client_priority p LEFT JOIN v_last_contact lc USING (client_id)
        WHERE p.rm_id = ? ORDER BY p.expected_value_inr DESC
    """, [rm_id])
    # per-client signal detail for the chips + family filter
    sig_rows = db.q("""
        SELECT s.client_id, s.signal_type, s.family, s.headline, s.rm_action, s.impact_inr, s.urgency, s.deadline_on,
               s.expected_value_inr
        FROM signals s JOIN clients c USING (client_id) WHERE c.rm_id = ? ORDER BY s.expected_value_inr DESC
    """, [rm_id])
    by_client: dict[str, list] = {}
    for s in sig_rows:
        s["title"] = CATALOG[s["signal_type"]]["title"]
        s["icon"] = CATALOG[s["signal_type"]]["icon"]
        by_client.setdefault(s["client_id"], []).append(s)
    for c in clients:
        c["signals"] = by_client.get(c["client_id"], [])
        c["families"] = sorted({s["family"] for s in c["signals"]})
    cap = ASSUMPTIONS["daily_capacity_per_rm"]
    top = clients[:cap]
    mix = db.q("""
        SELECT s.signal_type, s.family, COUNT(*) AS n, SUM(s.expected_value_inr) AS ev
        FROM signals s JOIN clients c USING (client_id) WHERE c.rm_id = ? GROUP BY 1, 2 ORDER BY n DESC
    """, [rm_id])
    for m in mix:
        m["title"] = CATALOG[m["signal_type"]]["title"]
        m["icon"] = CATALOG[m["signal_type"]]["icon"]
    deadlines = db.q("""
        SELECT s.client_id, c.name, s.signal_type, s.headline, s.deadline_on, datediff('day', as_of(), s.deadline_on) AS days_left
        FROM signals s JOIN clients c USING (client_id)
        WHERE c.rm_id = ? AND s.deadline_on IS NOT NULL AND s.deadline_on <= as_of() + INTERVAL 14 DAY
        ORDER BY s.deadline_on LIMIT 8
    """, [rm_id])
    for d in deadlines:
        d["icon"] = CATALOG[d["signal_type"]]["icon"]
        d["title"] = CATALOG[d["signal_type"]]["title"]
    stats = {
        "flagged": len(clients), "book_clients": ctx["rm"]["clients"], "cap": cap,
        "top_in_play": sum(c["impact_inr"] for c in top), "top_ev": sum(c["expected_value_inr"] for c in top),
        "revenue": sum(c["expected_value_inr"] for c in top) * ASSUMPTIONS["blended_fee_rate"],
        "deadlines_week": sum(1 for d in deadlines if d["days_left"] is not None and d["days_left"] <= 7),
        "total_signals": sum(m["n"] for m in mix), "total_ev": sum(c["expected_value_inr"] for c in clients),
    }
    ctx.update({"clients": clients, "top": top, "stats": stats, "mix": mix, "deadlines": deadlines,
                "greeting": greeting(), "max_mix": max([m["n"] for m in mix] or [1])})
    return render("brief.html", ctx)


@app.get("/clients/{client_id}", response_class=HTMLResponse)
def client_360(request: Request, client_id: str):
    ctx = base_ctx(request, "client", "Client 360")
    data = ai.client_context(client_id)
    if data is None:
        raise HTTPException(404, "Unknown client")
    c = data["client"]
    ctx["title"] = c["name"]
    max_opens = max([d["opens"] for d in data["daily_opens"]] or [1]) or 1
    ctx.update(data)
    ctx.update({"max_opens": max_opens,
                "client_cards": [s for s in data["signals"] if s.get("client_copy")],
                "in_play": sum(s["impact_inr"] for s in data["signals"]),
                "ev": sum(s["expected_value_inr"] for s in data["signals"])})
    return render("client.html", ctx)


@app.get("/signals", response_class=HTMLResponse)
def signals_index(request: Request):
    ctx = base_ctx(request, "signals", "Signal explorer")
    counts = {r["signal_type"]: r for r in db.q("""
        SELECT signal_type, COUNT(*) AS n, SUM(impact_inr) AS impact, SUM(expected_value_inr) AS ev,
               COUNT(*) FILTER (WHERE client_id IN (SELECT client_id FROM clients WHERE rm_id = ?)) AS mine
        FROM signals GROUP BY 1
    """, [ctx["rm"]["rm_id"]])}
    cards = []
    for m in catalog_list():
        r = counts.get(m["type"], {})
        m.update({"n": r.get("n", 0), "impact": r.get("impact", 0) or 0, "ev": r.get("ev", 0) or 0, "mine": r.get("mine", 0)})
        cards.append(m)
    families = ["opportunity", "retention", "portfolio", "relationship"]
    ctx.update({"cards": cards, "families": families,
                "grouped": {f: [c for c in cards if c["family"] == f] for f in families}})
    return render("signals.html", ctx)


@app.get("/signals/{signal_type}", response_class=HTMLResponse)
def signal_detail(request: Request, signal_type: str):
    if signal_type not in CATALOG:
        raise HTTPException(404, "Unknown signal")
    ctx = base_ctx(request, "signals", CATALOG[signal_type]["title"])
    rows = db.q("""
        SELECT s.*, c.name, c.segment, c.rm_id, r.name AS rm_name, a.aum
        FROM signals s JOIN clients c USING (client_id) JOIN rms r USING (rm_id) JOIN v_client_aum a USING (client_id)
        WHERE s.signal_type = ? ORDER BY s.expected_value_inr DESC
    """, [signal_type])
    for r in rows:
        r["evidence"] = json.loads(r.pop("evidence_json") or "{}")
    evidence_cols = [k for k in (rows[0]["evidence"].keys() if rows else []) if k not in ("deadline_on",)][:6]
    ctx.update({"meta": signal_meta(signal_type), "sql": sql_for(signal_type), "rows": rows, "evidence_cols": evidence_cols,
                "total_impact": sum(r["impact_inr"] for r in rows), "total_ev": sum(r["expected_value_inr"] for r in rows),
                "mine": sum(1 for r in rows if r["rm_id"] == ctx["rm"]["rm_id"])})
    return render("signal_detail.html", ctx)


@app.get("/analytics", response_class=HTMLResponse)
def analytics_page(request: Request):
    ctx = base_ctx(request, "analytics", "Book health")
    ctx.update({
        "coverage": analytics.coverage_gap(), "funnel": analytics.onboarding_funnel(), "idle": analytics.idle_cash(),
        "intent": analytics.intent_leakage(), "lead": analytics.redemption_lead_indicator(), "rm_load": analytics.rm_load(),
        "mix": analytics.signal_mix(),
    })
    for m in ctx["mix"]:
        m["title"] = CATALOG[m["signal_type"]]["title"]
    ctx["max_mix_ev"] = max([m["ev_inr"] for m in ctx["mix"]] or [1])
    ctx["max_rm_aum"] = max([r["aum"] for r in ctx["rm_load"]] or [1])
    return render("analytics.html", ctx)


@app.get("/ask", response_class=HTMLResponse)
def ask_page(request: Request):
    ctx = base_ctx(request, "ask", "Ask STORM")
    ctx.update({"suggested": ai.SUGGESTED_QUESTIONS, "schema": ai.SCHEMA_DOC})
    return render("ask.html", ctx)


@app.get("/about", response_class=HTMLResponse)
def about(request: Request):
    ctx = base_ctx(request, "about", "About Pulse")
    manifest_path = os.path.join(db.DATA_DIR, "manifest.json")
    with open(manifest_path) as fh:
        ctx["manifest"] = json.load(fh)
    return render("about.html", ctx)


# ------------------------------------------------------------------------------------------------
# JSON API
# ------------------------------------------------------------------------------------------------
class BriefReq(BaseModel):
    client_id: str


class AskReq(BaseModel):
    question: str


class SqlReq(BaseModel):
    sql: str


@app.post("/api/brief")
def api_brief(req: BriefReq):
    try:
        return ai.generate_brief(req.client_id)
    except KeyError:
        raise HTTPException(404, "Unknown client")


@app.post("/api/ask")
def api_ask(req: AskReq, request: Request):
    q = req.question.strip()
    if not q:
        raise HTTPException(400, "Ask something.")
    rm_id = request.cookies.get("pulse_rm") or DEFAULT_RM
    return ai.ask(q[:1000], rm_id)


@app.post("/api/sql")
def api_sql(req: SqlReq):
    try:
        return ai.run_sql(req.sql)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except Exception as e:  # noqa: BLE001 — surface DuckDB's message to the console
        return JSONResponse({"error": str(e).split("\n")[0][:400]}, status_code=400)


@app.get("/api/status")
def api_status():
    return {"ai": ai.ai_status(), "book": analytics.book_summary()}


@app.get("/health")
def health():
    return {"ok": True}
