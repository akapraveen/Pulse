/* Pulse — small, dependency-free client code. */
window.Pulse = (function () {
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));

  function inr(x) {
    if (x === null || x === undefined || x === '') return '—';
    const n = Number(x); if (Number.isNaN(n)) return String(x);
    const s = n < 0 ? '-' : ''; const a = Math.abs(n);
    if (a >= 1e7) return s + '₹' + (a / 1e7).toFixed(2).replace(/\.?0+$/, '') + ' Cr';
    if (a >= 1e5) return s + '₹' + (a / 1e5).toFixed(1).replace(/\.?0+$/, '') + ' L';
    return s + '₹' + Math.round(a).toLocaleString('en-IN');
  }
  const MONEY = /(inr|aum|amount|value|cash|ticket|balance|monthly|sip|redeemed|inflow|impact|loss|drag|revenue)/i;
  function fmtCell(col, v) {
    if (v === null || v === undefined) return '';
    if (typeof v === 'number' && MONEY.test(col) && Math.abs(v) >= 1000) return inr(v);
    if (typeof v === 'number' && !Number.isInteger(v)) return v.toFixed(2);
    return String(v);
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  async function post(url, body) {
    if (window.PulseTransport) return window.PulseTransport(url, body);   // static build: in-browser handlers
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await r.json().catch(() => ({ error: 'Bad response' }));
    if (!r.ok) throw new Error(data.error || data.detail || ('HTTP ' + r.status));
    return data;
  }
  function copyButtons() {
    $$('.copy').forEach(b => b.addEventListener('click', () => {
      const t = $(b.dataset.copy); if (!t) return;
      navigator.clipboard.writeText(t.innerText).then(() => { const o = b.textContent; b.textContent = 'Copied'; setTimeout(() => b.textContent = o, 1200); });
    }));
  }
  function renderTable(tbl, cols, rows) {
    if (!cols.length) { tbl.innerHTML = '<tr><td class="muted">No rows.</td></tr>'; return; }
    tbl.innerHTML = '<thead><tr>' + cols.map(c => `<th class="${MONEY.test(c) ? 'num' : ''}">${esc(c)}</th>`).join('') + '</tr></thead>' +
      '<tbody>' + rows.map(r => '<tr>' + r.map((v, i) => `<td class="${typeof v === 'number' ? 'num' : ''}">${esc(fmtCell(cols[i], v))}</td>`).join('') + '</tr>').join('') + '</tbody>';
  }

  /* ---------------- morning brief ---------------- */
  function brief() {
    const queue = $('#queue'); if (!queue) return;
    const rmId = (window.PulseStatic && window.PulseStatic.rm()) || (document.cookie.match(/pulse_rm=([^;]+)/) || [])[1];
    const key = 'pulse.actions.' + rmId;
    const load = () => { try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch (e) { return {}; } };
    const save = s => { try { localStorage.setItem(key, JSON.stringify(s)); } catch (e) {} };
    let state = load();
    const apply = () => {
      let n = 0;
      $$('.qrow', queue).forEach(row => {
        const a = state[row.dataset.client];
        row.classList.remove('done', 'snoozed', 'dismissed');
        if (a) { n++; row.classList.add(a.act); if (a.reason) row.dataset.reason = a.reason; }
      });
      const c = $('#actioned-count'); if (c) c.textContent = n ? `${n} actioned today` : '';
      const r = $('#reset-actions'); if (r) r.hidden = !n;
    };
    queue.addEventListener('click', e => {
      const b = e.target.closest('.act'); if (!b) return;
      const row = b.closest('.qrow');
      state[row.dataset.client] = { act: b.dataset.act === 'done' ? 'done' : 'snoozed', at: Date.now() };
      save(state); apply();
    });
    queue.addEventListener('change', e => {
      const s = e.target.closest('.dismiss'); if (!s || !s.value) return;
      const row = s.closest('.qrow');
      state[row.dataset.client] = { act: 'dismissed', reason: s.value, at: Date.now() };
      save(state); apply(); s.value = '';
    });
    $('#reset-actions')?.addEventListener('click', () => { state = {}; save(state); apply(); });
    $('#show-all')?.addEventListener('click', e => {
      const on = queue.classList.toggle('show-all');
      e.target.textContent = on ? `Show top ${queue.dataset.cap}` : `Show all ${e.target.dataset.total}`;
    });
    $('#family-filter')?.addEventListener('click', e => {
      const chip = e.target.closest('.chip'); if (!chip) return;
      $$('#family-filter .chip').forEach(c => c.classList.toggle('active', c === chip));
      const fam = chip.dataset.family;
      $$('.qrow', queue).forEach(row => row.classList.toggle('filtered-out', fam !== 'all' && !row.dataset.families.split(' ').includes(fam)));
    });
    apply();
  }

  /* ---------------- client 360 ---------------- */
  function client() {
    copyButtons();
    $('#more-holdings')?.addEventListener('click', e => { $('#holdings').classList.add('show-more'); e.target.remove(); });
    const btn = $('#gen-brief'); if (!btn) return;
    btn.addEventListener('click', async () => {
      const out = $('#brief-out');
      btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Writing the brief…';
      out.hidden = false; out.innerHTML = '<div class="muted small">Reading the 360, the open signals and the last conversations…</div>';
      try {
        const b = await post('/api/brief', { client_id: btn.dataset.client });
        out.innerHTML = renderBrief(b);
        copyButtons();
        btn.textContent = 'Regenerate';
      } catch (err) {
        out.innerHTML = `<div class="err">Couldn't generate the brief: ${esc(err.message)}</div>`;
        btn.textContent = 'Try again';
      } finally { btn.disabled = false; }
    });
  }
  function renderBrief(b) {
    const pts = (b.talking_points || []).map(p => `<li><b>${esc(p.point)}</b><span class="ev">${esc(p.evidence)}</span><span class="ask">→ ${esc(p.ask)}</span></li>`).join('');
    const obj = (b.objections || []).map(o => `<dt>“${esc(o.objection)}”</dt><dd>${esc(o.response)}</dd>`).join('');
    const chk = (b.compliance_checks || []).map(c => `<li>${esc(c)}</li>`).join('');
    const avoid = (b.do_not_say || []).map(c => `<span>${esc(c)}</span>`).join('');
    const meta = b.mode === 'claude' ? `Written by ${esc(b.model)} · ${b.usage ? b.usage.input_tokens + ' in / ' + b.usage.output_tokens + ' out tokens' : ''}` : esc(b.note || 'Template brief');
    return `
      <div class="b-section"><h4>Situation</h4><div class="b-situation">${esc(b.situation)}</div></div>
      <div class="b-section"><h4>Talking points</h4><ol class="b-points">${pts}</ol></div>
      <div class="b-section"><h4>WhatsApp draft</h4><div class="b-draft" id="draft-text">${esc(b.message_draft)}<button class="btn small ghost copy" data-copy="#draft-text">Copy</button></div></div>
      <div class="b-section"><h4>Likely objections</h4><dl class="b-obj">${obj}</dl></div>
      <div class="b-section"><h4>Before you act</h4><ul class="b-checks">${chk}</ul></div>
      <div class="b-section"><h4>Don't say</h4><div class="b-avoid">${avoid}</div></div>
      <div class="b-meta">${meta}</div>`;
  }

  /* ---------------- ask ---------------- */
  function ask() {
    copyButtons();
    let mode = 'nl';
    const nl = $('#ask-input'), sql = $('#sql-input'), status = $('#ask-status');
    $('#ask-tabs').addEventListener('click', e => {
      const t = e.target.closest('.tab'); if (!t) return;
      mode = t.dataset.mode;
      $$('#ask-tabs .tab').forEach(x => x.classList.toggle('active', x === t));
      nl.hidden = mode !== 'nl'; sql.hidden = mode !== 'sql';
      $('#suggested').hidden = mode !== 'nl';
    });
    $('#suggested').addEventListener('click', e => {
      const c = e.target.closest('.chip'); if (!c) return;
      nl.value = c.dataset.q; run();
    });
    nl.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); run(); } });
    sql.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); run(); } });
    $('#ask-form').addEventListener('submit', e => { e.preventDefault(); run(); });

    async function run() {
      const btn = $('#ask-run'); const out = $('#ask-out');
      const q = (mode === 'nl' ? nl.value : sql.value).trim(); if (!q) return;
      btn.disabled = true; status.innerHTML = '<span class="spinner"></span>' + (mode === 'nl' ? 'Thinking, writing SQL, running it…' : 'Running…');
      try {
        const res = mode === 'nl' ? await post('/api/ask', { question: q }) : await post('/api/sql', { sql: q });
        out.hidden = false;
        const ans = $('#ask-answer');
        if (mode === 'nl') {
          ans.hidden = false;
          ans.innerHTML = esc(res.answer) + (res.note ? `<span class="note">${esc(res.note)}</span>` : '');
        } else { ans.hidden = true; }
        $('#ask-sql').textContent = res.sql || q;
        $('#ask-rows').textContent = `· ${res.rows.length} row${res.rows.length === 1 ? '' : 's'}`;
        renderTable($('#ask-table'), res.columns || [], res.rows || []);
        const att = (res.attempts || []).filter(a => !a.ok);
        $('#ask-attempts').innerHTML = att.length ? `The agent fixed ${att.length} failed quer${att.length === 1 ? 'y' : 'ies'} on the way: ` + att.map(a => esc(a.error)).join(' · ') : '';
        status.textContent = '';
      } catch (err) {
        out.hidden = false; $('#ask-answer').hidden = false;
        $('#ask-answer').innerHTML = `<span class="err">${esc(err.message)}</span>`;
        $('#ask-sql').textContent = q; $('#ask-table').innerHTML = ''; $('#ask-rows').textContent = ''; $('#ask-attempts').innerHTML = '';
        status.textContent = '';
      } finally { btn.disabled = false; }
    }
  }

  return { brief, client, ask, copyButtons };
})();
document.addEventListener('DOMContentLoaded', () => window.Pulse.copyButtons());
