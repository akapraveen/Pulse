"""
AI layer — the "agent working alongside the RM".

Two capabilities, both grounded in the book (never free-floating):

1. Call brief   — given a client's 360 (profile, allocation, signals, last conversations, app
                  behaviour), Claude writes a 5-point brief, a WhatsApp-ready draft, likely
                  objections and the compliance checks the RM must do first. Structured output,
                  so the UI never parses prose.
2. Ask STORM    — natural language → SQL over the same DuckDB, via a read-only `run_sql` tool in
                  an agentic loop. The RM sees the answer *and* the SQL that produced it.

Both degrade gracefully: with no API credentials the brief is templated from the signals and Ask
falls back to keyword-matched canned queries. The demo never breaks; the UI shows which mode is on.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from app import db
from app.engine import ASSUMPTIONS, CATALOG
from app.fmt import dmy, inr

MODEL = os.environ.get("PULSE_MODEL", "claude-opus-5")
EFFORT = os.environ.get("PULSE_EFFORT", "medium")   # low | medium | high — medium keeps a brief under ~15s


# ------------------------------------------------------------------------------------------------
# credentials / status
# ------------------------------------------------------------------------------------------------
def ai_available() -> bool:
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return True
    return os.path.isdir(os.path.expanduser("~/.config/anthropic"))   # `ant auth login` profile


def ai_status() -> dict[str, Any]:
    live = ai_available()
    return {"live": live, "model": MODEL if live else None,
            "label": f"Claude · {MODEL}" if live else "Offline mode · template briefs & canned queries"}


def _client():
    import anthropic
    return anthropic.Anthropic()


# ------------------------------------------------------------------------------------------------
# client context (shared by the brief and the client page)
# ------------------------------------------------------------------------------------------------
def client_context(client_id: str) -> dict[str, Any] | None:
    c = db.q1("""
        SELECT c.*, r.name AS rm_name, a.aum, a.cash, a.invested_aum, a.equity_value,
               ROUND(a.equity_pct, 1) AS equity_pct, ROUND(a.equity_pct_invested, 1) AS equity_pct_invested,
               lc.last_contact_on, lc.days_since_contact,
               datediff('month', c.onboarded_on, as_of()) AS tenure_months, as_of() AS as_of
        FROM clients c JOIN rms r USING (rm_id) JOIN v_client_aum a USING (client_id)
        LEFT JOIN v_last_contact lc USING (client_id)
        WHERE c.client_id = ?
    """, [client_id])
    if not c:
        return None
    by_class = db.q("""
        SELECT asset_class, SUM(current_value) AS value, ROUND(100.0 * SUM(current_value) / ?, 1) AS pct,
               COUNT(*) AS n
        FROM holdings WHERE client_id = ? GROUP BY 1 ORDER BY value DESC
    """, [c["aum"] or 1, client_id])
    if c["cash"]:
        by_class.append({"asset_class": "Cash", "value": c["cash"], "pct": round(100.0 * c["cash"] / (c["aum"] or 1), 1), "n": 1})
    holdings = db.q("""
        SELECT holding_id, asset_class, instrument, category, sector, invested_value, current_value,
               ROUND(100.0 * current_value / ?, 1) AS pct_of_aum,
               ROUND(100.0 * (current_value - invested_value) / NULLIF(invested_value, 0), 1) AS gain_pct,
               purchase_date, lock_in_until
        FROM holdings WHERE client_id = ? ORDER BY current_value DESC
    """, [c["aum"] or 1, client_id])
    signals = db.q("""
        SELECT signal_id, signal_type, family, headline, rm_action, client_copy, client_cta, impact_inr, urgency,
               conversion_prior, expected_value_inr, deadline_on, evidence_json
        FROM signals WHERE client_id = ? ORDER BY expected_value_inr DESC
    """, [client_id])
    for s in signals:
        s["evidence"] = json.loads(s.pop("evidence_json") or "{}")
        s["title"] = CATALOG[s["signal_type"]]["title"]
        s["icon"] = CATALOG[s["signal_type"]]["icon"]
    interactions = db.q("""
        SELECT occurred_on, channel, summary, outcome, next_action, next_action_on, product_id
        FROM interactions WHERE client_id = ? ORDER BY occurred_on DESC LIMIT 8
    """, [client_id])
    sips = db.q("""
        SELECT instrument, amount, next_due, mandate_expiry, end_date, last_debit_status, status
        FROM sips WHERE client_id = ? ORDER BY amount DESC
    """, [client_id])
    activity = db.q1("""
        SELECT COUNT(*) FILTER (WHERE event_name = 'app_open' AND ts >= as_of() - INTERVAL 14 DAY) AS opens_14d,
               COUNT(*) FILTER (WHERE event_name = 'app_open' AND ts >= as_of() - INTERVAL 42 DAY
                                  AND ts < as_of() - INTERVAL 14 DAY) / 2.0 AS opens_prior_14d_avg,
               COUNT(*) FILTER (WHERE event_name IN ('view_withdraw', 'initiate_redeem') AND ts >= as_of() - INTERVAL 14 DAY) AS withdraw_views_14d,
               COUNT(*) FILTER (WHERE event_name = 'ask_ai' AND ts >= as_of() - INTERVAL 30 DAY) AS ai_questions_30d,
               MAX(ts) AS last_seen
        FROM app_events WHERE client_id = ?
    """, [client_id])
    product_views = db.q("""
        SELECT p.name, p.type, COUNT(*) AS views, MAX(e.ts) AS last_view
        FROM app_events e JOIN products p USING (product_id)
        WHERE e.client_id = ? AND e.event_name = 'view_product' AND e.ts >= as_of() - INTERVAL 30 DAY
        GROUP BY 1, 2 ORDER BY views DESC LIMIT 5
    """, [client_id])
    daily = db.q("""
        SELECT d.day, COALESCE(x.n, 0) AS opens
        FROM (SELECT as_of() - to_days(i) AS day FROM range(29, -1, -1) t(i)) d
        LEFT JOIN (SELECT ts::DATE AS day, COUNT(*) AS n FROM app_events
                   WHERE client_id = ? AND event_name = 'app_open' GROUP BY 1) x USING (day)
        ORDER BY d.day
    """, [client_id])
    recent_txns = db.q("""
        SELECT txn_date, txn_type, instrument, amount, channel, status FROM transactions
        WHERE client_id = ? ORDER BY txn_date DESC LIMIT 8
    """, [client_id])
    return {"client": c, "allocation": by_class, "holdings": holdings, "signals": signals,
            "interactions": interactions, "sips": sips, "activity": activity, "product_views": product_views,
            "daily_opens": daily, "recent_txns": recent_txns}


def _prompt_context(ctx: dict[str, Any]) -> dict[str, Any]:
    """The subset of the 360 that goes to the model — no phone/email/PAN, no IDs the model doesn't need."""
    c = ctx["client"]
    return {
        "as_of": str(c["as_of"]),
        "rm": {"name": c["rm_name"]},
        "client": {
            "name": c["name"], "segment": c["segment"], "risk_profile": c["risk_profile"], "age": c["age"],
            "occupation": c["occupation"], "city": c["city"], "tenure_months": c["tenure_months"],
            "kyc_status": c["kyc_status"], "ips_equity_target_pct": c["ips_equity_target"],
        },
        "portfolio": {
            "aum": inr(c["aum"]), "cash": inr(c["cash"]), "equity_pct_of_invested": c["equity_pct_invested"],
            "allocation": [{"asset_class": a["asset_class"], "value": inr(a["value"]), "pct": a["pct"]} for a in ctx["allocation"]],
            "largest_holdings": [{"instrument": h["instrument"], "asset_class": h["asset_class"], "value": inr(h["current_value"]),
                                  "pct_of_aum": h["pct_of_aum"], "gain_pct": h["gain_pct"]} for h in ctx["holdings"][:6]],
            "sips": [{"fund": s["instrument"], "monthly": inr(s["amount"]), "last_debit": s["last_debit_status"],
                      "mandate_expiry": str(s["mandate_expiry"])} for s in ctx["sips"][:4]],
        },
        "signals": [{"type": s["signal_type"], "headline": s["headline"], "suggested_action": s["rm_action"],
                     "in_play": inr(s["impact_inr"]), "urgency": s["urgency"],
                     "deadline": str(s["deadline_on"]) if s["deadline_on"] else None,
                     "evidence": s["evidence"]} for s in ctx["signals"]],
        "recent_conversations": [{"on": str(i["occurred_on"]), "channel": i["channel"], "summary": i["summary"],
                                  "outcome": i["outcome"], "next_action": i["next_action"]} for i in ctx["interactions"][:4]],
        "app_behaviour": {
            "opens_last_14d": ctx["activity"]["opens_14d"], "opens_prior_14d_avg": ctx["activity"]["opens_prior_14d_avg"],
            "withdraw_screen_views_14d": ctx["activity"]["withdraw_views_14d"],
            "ai_questions_30d": ctx["activity"]["ai_questions_30d"],
            "product_views_30d": [{"product": p["name"], "type": p["type"], "views": p["views"]} for p in ctx["product_views"]],
        },
        "recent_transactions": [{"on": str(t["txn_date"]), "type": t["txn_type"], "instrument": t["instrument"],
                                 "amount": inr(t["amount"]), "status": t["status"]} for t in ctx["recent_txns"][:5]],
    }


# ------------------------------------------------------------------------------------------------
# call brief
# ------------------------------------------------------------------------------------------------
BRIEF_SYSTEM = """You are Pulse, the AI copilot inside STORM, the relationship-manager platform of an Indian wealth firm serving HNI and UHNI clients. You write call briefs for relationship managers (RMs) before they pick up the phone.

Ground every sentence in the context you are given. Never invent holdings, numbers, events or preferences. If something is unknown, say what the RM should ask.

House rules:
- Indian money formatting (₹ lakh / crore). Warm, direct, senior-private-banker tone. No jargon dumps.
- Never promise or forecast returns. Never compare to "guaranteed" anything.
- Suitability is non-negotiable: PMS needs ₹50 L minimum, AIF ₹1 Cr, and the product's risk profile must fit the client. If a signal suggests a product the client can't or shouldn't buy, say so instead of pitching it.
- If a churn or withdraw signal is present, the first goal of the call is to listen and find the trigger (service issue, competitor, need for funds) — not to sell.
- The money is the client's. Propose, don't push. Offer a next step and a time.
- message_draft: a WhatsApp message, at most 80 words, no emojis, no bullet points. Address as "Mr/Ms <surname>" unless tenure_months >= 12, then first name. One clear reason for reaching out, one specific ask (a time to talk).
- talking_points: 3 to 5. Each has the point, the specific evidence from the context (with numbers), and the ask/next step.
- objections: the 2 most likely pushbacks from this specific client and a good response.
- compliance_checks: concrete things the RM must verify before acting (KYC status, suitability form, product minimums, lock-ins, tax implications).
- do_not_say: 2-3 phrases to avoid with this client, given what you know."""

BRIEF_SCHEMA = {
    "type": "object",
    "properties": {
        "situation": {"type": "string", "description": "2-3 sentences for the RM: who this client is right now and why today."},
        "talking_points": {
            "type": "array",
            "items": {"type": "object",
                      "properties": {"point": {"type": "string"}, "evidence": {"type": "string"}, "ask": {"type": "string"}},
                      "required": ["point", "evidence", "ask"], "additionalProperties": False},
        },
        "message_draft": {"type": "string"},
        "objections": {
            "type": "array",
            "items": {"type": "object",
                      "properties": {"objection": {"type": "string"}, "response": {"type": "string"}},
                      "required": ["objection", "response"], "additionalProperties": False},
        },
        "compliance_checks": {"type": "array", "items": {"type": "string"}},
        "do_not_say": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["situation", "talking_points", "message_draft", "objections", "compliance_checks", "do_not_say"],
    "additionalProperties": False,
}


def generate_brief(client_id: str) -> dict[str, Any]:
    ctx = client_context(client_id)
    if ctx is None:
        raise KeyError(client_id)
    if ai_available():
        try:
            return _brief_with_claude(ctx)
        except Exception as e:  # noqa: BLE001 — the demo must never break; surface the reason instead
            fb = _brief_template(ctx)
            fb["mode"] = "template"
            fb["note"] = f"Claude call failed ({type(e).__name__}: {str(e)[:160]}). Showing the template brief."
            return fb
    fb = _brief_template(ctx)
    fb["mode"] = "template"
    fb["note"] = "No ANTHROPIC_API_KEY set — this is the deterministic template brief. Add a key for the Claude-written one."
    return fb


def _brief_with_claude(ctx: dict[str, Any]) -> dict[str, Any]:
    import anthropic  # noqa: F401  (typed exceptions come from here)

    client = _client()
    payload = json.dumps(_prompt_context(ctx), ensure_ascii=False, indent=1)
    response = client.messages.create(
        model=MODEL,
        max_tokens=4096,
        system=BRIEF_SYSTEM,
        messages=[{"role": "user", "content": f"Write the call brief for this client.\n\n<context>\n{payload}\n</context>"}],
        output_config={"format": {"type": "json_schema", "schema": BRIEF_SCHEMA}, "effort": EFFORT},
    )
    if response.stop_reason == "refusal":
        raise RuntimeError("model declined the request")
    text = next(b.text for b in response.content if b.type == "text")
    brief = json.loads(text)
    brief["mode"] = "claude"
    brief["model"] = MODEL
    brief["usage"] = {"input_tokens": response.usage.input_tokens, "output_tokens": response.usage.output_tokens}
    return brief


def _brief_template(ctx: dict[str, Any]) -> dict[str, Any]:
    c = ctx["client"]
    sigs = ctx["signals"]
    first = c["name"].split(" ")[0]
    surname = c["name"].split(" ")[-1]
    salutation = first if (c["tenure_months"] or 0) >= 12 else f"Mr/Ms {surname}"
    lead = sigs[0] if sigs else None
    points = []
    for s in sigs[:4]:
        points.append({"point": s["title"], "evidence": s["headline"], "ask": s["rm_action"]})
    if not points:
        points.append({"point": "Routine check-in", "evidence": f"No open signals. Last contact {dmy(c['last_contact_on'])}.",
                       "ask": "Confirm nothing has changed on goals or liquidity; book the next review."})
    if lead:
        reason = {
            "idle_cash": f"there's about {inr(lead['evidence'].get('idle_cash'))} sitting idle in your account",
            "liquidity_event": "I noticed a sizeable credit into your account and wanted to make sure it's put to work the way you'd like",
            "buy_intent": f"I saw you've been looking at {lead['evidence'].get('product_name')} — happy to walk you through it",
            "product_closing": f"{lead['evidence'].get('product_name')} closes on {dmy(lead['deadline_on'])} and you'd shown interest",
            "lockin_maturity": f"about {inr(lead['evidence'].get('maturing_value'))} is maturing shortly and I'd like to plan what happens next",
            "onboarding_stuck": "your mutual-fund onboarding is one step from done and I can finish it with you in two minutes",
            "churn_risk": "I wanted to check in and make sure everything is working the way you expect",
            "sip_at_risk": f"your SIP of {inr(lead['evidence'].get('monthly_amount'))} a month needs a quick mandate renewal",
            "concentration_risk": f"{lead['evidence'].get('instrument')} is now a large part of your portfolio and I'd like to discuss a phased plan",
            "allocation_drift": "your equity allocation has drifted from the plan we agreed and a small rebalance would bring it back",
            "fund_overlap": "a few of your funds overlap heavily and consolidating could simplify things",
            "tax_harvest": "there's a tax-saving opportunity in the portfolio worth discussing before the financial year ends",
            "overdue_review": "it's been a while since we spoke and I'd like to walk you through the portfolio",
        }.get(lead["signal_type"], "I'd like to walk you through the portfolio")
    else:
        reason = "I'd like to walk you through the portfolio"
    draft = (f"Hello {salutation}, {c['rm_name']} here from the wealth desk. Reaching out because {reason}. "
             f"Would a 15-minute call on Tuesday at 11 or Wednesday at 4 work for you? Happy to keep it short.")
    return {
        "situation": (f"{c['name']} — {c['segment']}, {c['risk_profile']}, {c['occupation']}, {c['city']}. AUM {inr(c['aum'])}, "
                      f"cash {inr(c['cash'])}. Last contact {dmy(c['last_contact_on'])} ({c['days_since_contact']} days ago). "
                      f"{len(sigs)} open signal{'s' if len(sigs) != 1 else ''}, {inr(sum(s['impact_inr'] for s in sigs))} in play."),
        "talking_points": points,
        "message_draft": draft,
        "objections": [
            {"objection": "I'm waiting for the market to correct before deploying.",
             "response": "Park it in a liquid/arbitrage fund now so it earns while you wait; we can stagger deployment over 3-6 months."},
            {"objection": "Send me something on email, I'll look at it.",
             "response": "Of course — I'll send a one-pager today. Can I also hold 15 minutes on Thursday to walk through it?"},
        ],
        "compliance_checks": [
            f"KYC status: {c['kyc_status']}",
            "Confirm risk profile and suitability form before any PMS/AIF discussion (min ₹50 L / ₹1 Cr).",
            "Log the conversation and outcome in STORM; no return commitments.",
        ],
        "do_not_say": ["guaranteed", "this will definitely go up", "everyone is buying this"],
    }


# ------------------------------------------------------------------------------------------------
# Ask STORM — NL → SQL agent
# ------------------------------------------------------------------------------------------------
SCHEMA_DOC = """Tables (DuckDB; dates are DATE, timestamps TIMESTAMP, money is INR as DOUBLE):
- rms(rm_id, name, region, tenure_months, email)
- clients(client_id, name, rm_id, segment['Affluent'|'HNI'|'UHNI'], risk_profile['Conservative'|'Moderate'|'Aggressive'], ips_equity_target, city, age, occupation, onboarded_on, last_review_on, kyc_status, engagement_tier)
- holdings(holding_id, client_id, asset_class['Equity MF'|'Debt MF'|'Hybrid MF'|'Direct Equity'|'PMS'|'AIF'|'Unlisted'|'FD'|'Bonds'], instrument, category, sector, manager, invested_value, current_value, purchase_date, lock_in_until, is_equity)
- cash_snapshots(client_id, as_of, ledger_balance)  -- weekly; latest = idle cash in the wealth account
- sips(sip_id, client_id, instrument, amount, start_date, end_date, status, mandate_expiry, last_debit_status, next_due)
- transactions(txn_id, client_id, txn_date, txn_type, asset_class, instrument, amount, channel, status)
- interactions(interaction_id, client_id, rm_id, occurred_on, channel, summary, outcome, next_action, next_action_on, product_id)
- app_events(event_id, client_id, ts, event_name, screen, product_id, session_id, platform)  -- client-app analytics
- products(product_id, name, type['PMS'|'AIF'|'Unlisted'], strategy, manager, min_ticket, suitable_for, status, closes_on, note)
- signals(signal_id, client_id, signal_type, family, headline, rm_action, impact_inr, urgency, conversion_prior, expected_value_inr, deadline_on, evidence_json)  -- the engine's output
Views/macros: v_client_aum(client_id, aum, invested_aum, equity_value, cash, equity_pct, equity_pct_invested);
v_last_contact(client_id, last_contact_on, days_since_contact); v_client_priority(client_id, rm_id, name, segment, aum, signal_count, expected_value_inr, top_signal, top_headline, ...); as_of() returns the book date.
signal_type values: idle_cash, liquidity_event, buy_intent, product_closing, lockin_maturity, onboarding_stuck, churn_risk, sip_at_risk, concentration_risk, allocation_drift, fund_overlap, tax_harvest, overdue_review."""

ASK_SYSTEM_TMPL = """You are Pulse, the data copilot inside STORM (an Indian wealth firm's RM platform). You answer a relationship manager's questions about their book by writing SQL and running it with the run_sql tool.

{schema}

Rules:
- The RM asking is {rm_name} ({rm_id}). "My clients", "my book", "I" mean clients.rm_id = '{rm_id}'. If they say "all clients" or "the firm", drop the filter.
- Only SELECT queries. Always LIMIT to 50 rows unless the question is an aggregate. Use readable column aliases.
- Use as_of() for "today". Money is INR; return raw numbers (the UI formats them) but mention them in ₹ lakh/crore in your answer.
- Prefer the signals / v_client_priority tables when the question is about who to call or what's urgent.
- Run the query, look at the result, and if it's empty or looks wrong, fix the SQL and run again (max 4 attempts).
- Final answer: 2-4 sentences, specific, with the key numbers. Mention what the query counted if there's any ambiguity. Do not paste the table; the UI shows it."""

RUN_SQL_TOOL = {
    "name": "run_sql",
    "description": "Run a read-only DuckDB SELECT query against the book and return up to 50 rows as JSON.",
    "input_schema": {
        "type": "object",
        "properties": {"sql": {"type": "string", "description": "A single SELECT (or WITH ... SELECT) statement."}},
        "required": ["sql"],
        "additionalProperties": False,
    },
    "strict": True,
}

_FORBIDDEN = re.compile(
    r"\b(insert|update|delete|drop|create|alter|attach|detach|copy|export|import|install|load|pragma|set|reset|"
    r"call|truncate|merge|vacuum|checkpoint|begin|commit|rollback|use|read_csv|read_csv_auto|read_parquet|read_json|"
    r"read_text|read_blob|glob|sniff_csv|httpfs|getenv|system)\b", re.I)


def guard_sql(sql: str) -> str:
    """Accept a single read-only SELECT; reject everything else. Appends LIMIT 200 if absent."""
    s = re.sub(r"--[^\n]*", " ", sql)
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S)
    s = s.strip().rstrip(";").strip()
    if ";" in s:
        raise ValueError("One statement at a time.")
    if not re.match(r"^(select|with)\b", s, re.I):
        raise ValueError("Only SELECT queries are allowed.")
    no_strings = re.sub(r"'(?:[^']|'')*'", "''", s)
    m = _FORBIDDEN.search(no_strings)
    if m:
        raise ValueError(f"'{m.group(0)}' is not allowed in the console.")
    if re.search(r"\.(csv|parquet|json|db|duckdb)\b", no_strings, re.I):
        raise ValueError("File access is not allowed.")
    if not re.search(r"\blimit\s+\d+", no_strings, re.I):
        s += "\nLIMIT 200"
    return s


def run_sql(sql: str, max_rows: int = 200) -> dict[str, Any]:
    safe = guard_sql(sql)
    rows = db.q(safe)
    rows = rows[:max_rows]
    cols = list(rows[0].keys()) if rows else _columns_of(safe)
    return {"sql": safe, "columns": cols, "rows": [[_cell(r[c]) for c in cols] for r in rows], "row_count": len(rows)}


def _columns_of(sql: str) -> list[str]:
    cur = db.connect().cursor()
    try:
        res = cur.execute(sql)
        return [d[0] for d in res.description]
    finally:
        cur.close()


def _cell(v):
    if v is None:
        return None
    if isinstance(v, (int, float, str, bool)):
        return v
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    return str(v)


SUGGESTED_QUESTIONS = [
    "Which of my clients have the most idle cash, and how long has it been sitting?",
    "Who in my book has SIPs expiring or failing this month?",
    "Which clients viewed a PMS or AIF in the app this week but I haven't spoken to?",
    "Who haven't I contacted in 60+ days, ranked by AUM?",
    "How much is maturing across my book in the next 30 days?",
    "Which of my clients have more than 25% in a single stock?",
    "What is my total AUM by segment, and how much of it has an open churn signal?",
    "Show clients stuck in MF onboarding and which step they stalled at.",
]


def ask(question: str, rm_id: str) -> dict[str, Any]:
    rm = db.q1("SELECT rm_id, name FROM rms WHERE rm_id = ?", [rm_id]) or {"rm_id": rm_id, "name": "the RM"}
    if ai_available():
        try:
            return _ask_with_claude(question, rm)
        except Exception as e:  # noqa: BLE001
            out = _ask_canned(question, rm)
            out["note"] = f"Claude call failed ({type(e).__name__}: {str(e)[:160]}). Showing the closest canned query."
            return out
    out = _ask_canned(question, rm)
    out["note"] = "No ANTHROPIC_API_KEY set — matched your question to a canned query. Add a key for the full NL→SQL agent."
    return out


def _ask_with_claude(question: str, rm: dict[str, Any]) -> dict[str, Any]:
    client = _client()
    system = ASK_SYSTEM_TMPL.format(schema=SCHEMA_DOC, rm_name=rm["name"], rm_id=rm["rm_id"])
    messages: list[dict[str, Any]] = [{"role": "user", "content": question}]
    last_result: dict[str, Any] | None = None
    attempts: list[dict[str, Any]] = []
    response = None
    for _ in range(6):
        response = client.messages.create(
            model=MODEL, max_tokens=4096, system=system, messages=messages, tools=[RUN_SQL_TOOL],
            output_config={"effort": EFFORT},
        )
        if response.stop_reason == "refusal":
            raise RuntimeError("model declined the request")
        tool_uses = [b for b in response.content if b.type == "tool_use"]
        if not tool_uses:
            break
        messages.append({"role": "assistant", "content": response.content})
        results = []
        for tu in tool_uses:
            sql = tu.input.get("sql", "")
            try:
                res = run_sql(sql, max_rows=50)
                last_result = res
                attempts.append({"sql": res["sql"], "ok": True, "rows": res["row_count"]})
                content = json.dumps({"columns": res["columns"], "rows": res["rows"][:50], "row_count": res["row_count"]},
                                     ensure_ascii=False, default=str)
                results.append({"type": "tool_result", "tool_use_id": tu.id, "content": content})
            except Exception as e:  # noqa: BLE001 — feed the error back so the model can fix the SQL
                attempts.append({"sql": sql, "ok": False, "error": str(e)[:300]})
                results.append({"type": "tool_result", "tool_use_id": tu.id, "content": f"Error: {str(e)[:500]}", "is_error": True})
        messages.append({"role": "user", "content": results})
    answer = "".join(b.text for b in (response.content if response else []) if b.type == "text").strip()
    return {"mode": "claude", "model": MODEL, "answer": answer or "I couldn't get to an answer — try rephrasing.",
            "sql": last_result["sql"] if last_result else None,
            "columns": last_result["columns"] if last_result else [],
            "rows": last_result["rows"] if last_result else [], "attempts": attempts}


CANNED: list[tuple[list[str], str, str]] = [
    (["idle", "parked", "sitting"], "Clients with idle cash (6+ weeks), largest first.",
     "SELECT c.name, c.segment, s.impact_inr AS idle_cash_inr, json_extract(s.evidence_json,'$.pct_of_aum') AS pct_of_aum, s.headline "
     "FROM signals s JOIN clients c USING(client_id) WHERE s.signal_type='idle_cash' AND c.rm_id='{rm}' ORDER BY s.impact_inr DESC"),
    (["sip", "mandate", "expir", "fail"], "SIPs at risk in your book.",
     "SELECT c.name, s.instrument, s.amount AS monthly_sip, s.last_debit_status, s.mandate_expiry, s.end_date, s.next_due "
     "FROM sips s JOIN clients c USING(client_id) WHERE c.rm_id='{rm}' AND s.status='Active' AND (s.last_debit_status='Failed' "
     "OR s.mandate_expiry <= as_of() + INTERVAL 30 DAY OR s.end_date <= as_of() + INTERVAL 45 DAY) ORDER BY s.amount DESC"),
    (["pms", "aif", "unlisted", "viewed", "interested", "looking"], "Clients viewing exclusive products in the last 7 days, with last contact.",
     "SELECT c.name, p.name AS product, p.type, COUNT(*) AS views_7d, lc.days_since_contact "
     "FROM app_events e JOIN clients c USING(client_id) JOIN products p USING(product_id) LEFT JOIN v_last_contact lc USING(client_id) "
     "WHERE c.rm_id='{rm}' AND e.event_name='view_product' AND e.ts >= as_of() - INTERVAL 7 DAY GROUP BY 1,2,3,5 ORDER BY views_7d DESC"),
    (["contact", "spoken", "spoke", "silent", "overdue", "haven't"], "Clients not contacted in 60+ days, by AUM.",
     "SELECT c.name, c.segment, a.aum, lc.last_contact_on, lc.days_since_contact FROM clients c JOIN v_client_aum a USING(client_id) "
     "LEFT JOIN v_last_contact lc USING(client_id) WHERE c.rm_id='{rm}' AND COALESCE(lc.days_since_contact,999) > 60 ORDER BY a.aum DESC"),
    (["matur", "lock", "coming free", "fd"], "Holdings maturing in the next 30 days.",
     "SELECT c.name, h.instrument, h.asset_class, h.current_value, h.lock_in_until, datediff('day', as_of(), h.lock_in_until) AS days_left "
     "FROM holdings h JOIN clients c USING(client_id) WHERE c.rm_id='{rm}' AND h.lock_in_until BETWEEN as_of() - INTERVAL 7 DAY AND as_of() + INTERVAL 30 DAY ORDER BY h.lock_in_until"),
    (["concentrat", "single stock", "one stock", "25%", "20%"], "Single-security concentration above 20% of AUM.",
     "SELECT c.name, h.instrument, h.sector, h.current_value, ROUND(100.0*h.current_value/a.aum,1) AS pct_of_aum FROM holdings h "
     "JOIN clients c USING(client_id) JOIN v_client_aum a USING(client_id) WHERE c.rm_id='{rm}' AND h.asset_class IN ('Direct Equity','Unlisted') "
     "AND h.current_value >= 0.20*a.aum ORDER BY pct_of_aum DESC"),
    (["churn", "withdraw", "redeem", "leaving", "at risk"], "Churn-risk signals in your book.",
     "SELECT c.name, c.segment, a.aum, s.headline, s.urgency FROM signals s JOIN clients c USING(client_id) JOIN v_client_aum a USING(client_id) "
     "WHERE s.signal_type='churn_risk' AND c.rm_id='{rm}' ORDER BY s.expected_value_inr DESC"),
    (["onboard", "stuck", "kyc", "step"], "Clients stuck in MF onboarding and the step they stalled at.",
     "SELECT c.name, json_extract_string(s.evidence_json,'$.last_step') AS stalled_at, json_extract(s.evidence_json,'$.hours_stuck') AS hours_stuck, s.impact_inr AS expected_first_ticket "
     "FROM signals s JOIN clients c USING(client_id) WHERE s.signal_type='onboarding_stuck' AND c.rm_id='{rm}' ORDER BY hours_stuck"),
    (["segment", "aum by", "total aum", "book size"], "Your AUM by segment, with churn-flagged share.",
     "SELECT c.segment, COUNT(*) AS clients, SUM(a.aum) AS aum, SUM(a.aum) FILTER (WHERE EXISTS (SELECT 1 FROM signals s WHERE s.client_id=c.client_id AND s.signal_type='churn_risk')) AS aum_with_churn_signal "
     "FROM clients c JOIN v_client_aum a USING(client_id) WHERE c.rm_id='{rm}' GROUP BY 1 ORDER BY aum DESC"),
]


def _ask_canned(question: str, rm: dict[str, Any]) -> dict[str, Any]:
    ql = question.lower()
    best, best_hits = None, 0
    for keys, label, sql in CANNED:
        hits = sum(1 for k in keys if k in ql)
        if hits > best_hits:
            best, best_hits = (label, sql), hits
    if best is None:
        best = ("Your top priorities today (by expected value).",
                "SELECT name, segment, aum, signal_count, top_signal, top_headline, expected_value_inr FROM v_client_priority "
                "WHERE rm_id='{rm}' ORDER BY expected_value_inr DESC")
    label, sql = best
    res = run_sql(sql.format(rm=rm["rm_id"]), max_rows=50)
    return {"mode": "canned", "answer": f"{label} {res['row_count']} row{'s' if res['row_count'] != 1 else ''}.",
            "sql": res["sql"], "columns": res["columns"], "rows": res["rows"], "attempts": []}
