"""
DuckDB data layer.

The book lives as CSVs in data/ (a stand-in for STORM's warehouse tables). At startup we
load them into an in-memory DuckDB, add a handful of convenience views/macros that the
signal SQL relies on, and materialise the `signals` table via the engine.

Swap `load()` for a connection to the real warehouse (Postgres/BigQuery via DuckDB
extensions, or run the same SQL there directly) and nothing else in the app changes.
"""
from __future__ import annotations

import glob
import os
import threading
from typing import Any

import duckdb

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DATA_DIR = os.path.join(ROOT, "data")

_lock = threading.Lock()
_con: duckdb.DuckDBPyConnection | None = None

BASE_VIEWS = """
CREATE OR REPLACE MACRO as_of() AS (SELECT as_of FROM meta);

CREATE OR REPLACE VIEW v_latest_cash AS
SELECT client_id, ledger_balance AS cash
FROM cash_snapshots
WHERE as_of = (SELECT MAX(as_of) FROM cash_snapshots);

CREATE OR REPLACE VIEW v_client_aum AS
SELECT c.client_id,
       COALESCE(h.total, 0) + COALESCE(lc.cash, 0)                              AS aum,
       COALESCE(h.total, 0)                                                     AS invested_aum,
       COALESCE(h.equity, 0)                                                    AS equity_value,
       COALESCE(lc.cash, 0)                                                     AS cash,
       100.0 * COALESCE(h.equity, 0) / NULLIF(COALESCE(h.total, 0) + COALESCE(lc.cash, 0), 0) AS equity_pct,
       100.0 * COALESCE(h.equity, 0) / NULLIF(COALESCE(h.total, 0), 0)          AS equity_pct_invested
FROM clients c
LEFT JOIN (
    SELECT client_id, SUM(current_value) AS total,
           SUM(CASE WHEN is_equity = 1 THEN current_value ELSE 0 END) AS equity
    FROM holdings GROUP BY client_id
) h USING (client_id)
LEFT JOIN v_latest_cash lc USING (client_id);

CREATE OR REPLACE VIEW v_last_contact AS
SELECT c.client_id,
       MAX(i.occurred_on)                                   AS last_contact_on,
       datediff('day', MAX(i.occurred_on), as_of())         AS days_since_contact
FROM clients c
LEFT JOIN interactions i USING (client_id)
GROUP BY c.client_id;

-- clients with an MF onboarding journey started in the last 30 days and not completed
CREATE OR REPLACE VIEW v_mid_onboarding AS
WITH last_step AS (
    SELECT client_id, event_name, ts,
           ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY ts DESC) AS rn
    FROM app_events WHERE event_name LIKE 'onb_%'
)
SELECT client_id FROM last_step
WHERE rn = 1 AND event_name <> 'onb_complete' AND ts >= as_of() - INTERVAL 30 DAY;
"""


def connect() -> duckdb.DuckDBPyConnection:
    """Return the process-wide connection, loading the book on first use."""
    global _con
    if _con is None:
        with _lock:
            if _con is None:
                _con = load()
    return _con


def load() -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(database=":memory:")
    for path in sorted(glob.glob(os.path.join(DATA_DIR, "*.csv"))):
        table = os.path.basename(path)[:-4]
        con.execute(f"CREATE TABLE {table} AS SELECT * FROM read_csv('{path}', header = true)")
    con.execute(BASE_VIEWS)
    from app.engine import materialise_signals  # local import: engine depends on this module
    materialise_signals(con)
    return con


def q(sql: str, params: list[Any] | None = None) -> list[dict[str, Any]]:
    """Run a query and return rows as dicts (DuckDB connections aren't thread-safe; cursor per call)."""
    cur = connect().cursor()
    try:
        res = cur.execute(sql, params or [])
        cols = [d[0] for d in res.description]
        return [dict(zip(cols, row)) for row in res.fetchall()]
    finally:
        cur.close()


def q1(sql: str, params: list[Any] | None = None) -> dict[str, Any] | None:
    rows = q(sql, params)
    return rows[0] if rows else None


def scalar(sql: str, params: list[Any] | None = None) -> Any:
    row = q1(sql, params)
    return next(iter(row.values())) if row else None
