"""
Signal engine.

A signal is a SQL file in app/signals/ that returns, per client, the standard columns
    client_id, impact_inr, urgency (0-1), deadline_on (nullable DATE)
plus any evidence columns it likes. This module adds the product layer on top:

    expected_value = impact_inr × conversion_prior × urgency

- impact_inr        what's in play, in rupees (the SQL decides: idle balance, SIP × 12, AUM at risk ...)
- conversion_prior  how often an RM action on this signal type turns into an outcome. These are
                    *assumptions to be calibrated* from pilot outcomes (see ASSUMPTIONS); the feedback
                    loop in the Morning Brief exists to replace them with measured rates.
- urgency           the SQL's time-decay for this instance (deadline proximity, recency of behaviour)

Headlines are rendered here (not in SQL) so wording, currency formatting and the client-facing
copy live in one place. Adding a signal = one SQL file + one entry in CATALOG.
"""
from __future__ import annotations

import json
import os
from datetime import date, datetime
from typing import Any, Callable

from app.fmt import dmy, inr

SIGNAL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "signals")

# --- business assumptions (all documented in docs/SIGNALS.md; every one is a knob) ---------------
ASSUMPTIONS = {
    "blended_fee_rate": 0.008,        # revenue ≈ AUM × 0.8% (trail on MF + PMS/AIF fees, blended)
    "churn_attrition_if_ignored": 0.30,
    "idle_cash_yield_gap": 0.038,
    "daily_capacity_per_rm": 10,      # meaningful conversations an RM can have in a day
}

STEP_LABEL = {
    "onb_start": "the start screen", "onb_kyc": "KYC", "onb_fatca": "FATCA declaration",
    "onb_bank_mandate": "the bank e-mandate", "onb_nominee": "nominee details", "onb_complete": "complete",
}
REASON_LABEL = {"debit_failed": "debit failed", "mandate_expiring": "mandate expiring", "sip_ending": "SIP ending"}


def _days(n) -> str:
    n = int(n)
    if n < 0:
        return f"{-n} days ago"
    if n == 0:
        return "today"
    return f"in {n} days" if n != 1 else "tomorrow"


# --- the catalog --------------------------------------------------------------------------------
# family: opportunity | retention | portfolio | relationship
# prior:  assumed action→outcome conversion (to be calibrated)
# headline(row): RM-facing one-liner. client_copy(row): how it would render in the client app (or None).
CATALOG: dict[str, dict[str, Any]] = {
    "liquidity_event": dict(
        title="Liquidity event", family="opportunity", prior=0.45, icon="⚡",
        blurb="Cash balance jumped 2.5×+ in three weeks — proceeds just landed and every bank is calling.",
        rm_action="Call within 24h. Ask what the money is earmarked for; propose a parking + phased deployment plan.",
        headline=lambda r: f"{inr(r['inflow_inr'])} landed {r['landed']} — balance now {inr(r['current_cash'])}",
        client_copy=lambda r: (f"₹{r['inflow_inr']/1e5:,.0f} L was credited recently. Park it in a liquid fund today "
                               f"and deploy in phases — your RM has a plan ready."),
        client_cta="See deployment plan",
    ),
    "idle_cash": dict(
        title="Idle cash", family="opportunity", prior=0.35, icon="💤",
        blurb="₹10 L+ sitting in the wealth account for 6+ weeks, ≥5% of the book.",
        rm_action="Propose a liquid/arbitrage fund for the balance; agree a deployment plan for the rest.",
        headline=lambda r: f"{inr(r['idle_cash'])} idle 6+ weeks ({r['pct_of_aum']}% of portfolio) — ~{inr(r['annual_drag_inr'])}/yr left on the table",
        client_copy=lambda r: (f"{inr(r['idle_cash'])} has been idle for over 6 weeks. In a liquid fund it could earn about "
                               f"{inr(r['annual_drag_inr'])} more a year with same-day access."),
        client_cta="Move to a liquid fund",
    ),
    "buy_intent": dict(
        title="Buy intent", family="opportunity", prior=0.40, icon="👀",
        blurb="Repeated views of one exclusive product in 10 days, not invested, not yet discussed. Suitability-gated.",
        rm_action="Send the factsheet with a 2-line note; offer a 15-min call with the fund manager's desk.",
        headline=lambda r: f"Viewed {r['product_name']} {int(r['views_10d'])}× in 10 days — not invested, not discussed",
        client_copy=None, client_cta=None,
    ),
    "product_closing": dict(
        title="Product closing", family="opportunity", prior=0.30, icon="⏳",
        blurb="A product the client showed interest in closes its window within 21 days.",
        rm_action="Confirm interest today; walk through the term sheet and the drawdown timeline before the close.",
        headline=lambda r: f"{r['product_name']} closes {_days(r['days_to_close'])} — client showed interest {int(r['interest_touches'])}×",
        client_copy=lambda r: f"{r['product_name']} closes on {dmy(r['deadline_on'])}. Minimum {inr(r['min_ticket'])}. Talk to your RM before the window shuts.",
        client_cta="Ask my RM",
    ),
    "lockin_maturity": dict(
        title="Lock-in / maturity", family="opportunity", prior=0.40, icon="🔓",
        blurb="ELSS lock-ins, PMS exit-load windows and FDs maturing in the next 30 days (or last 7).",
        rm_action="Reach out a week before maturity with a re-deployment option; pre-empt the bank's FD renewal call.",
        headline=lambda r: f"{inr(r['maturing_value'])} coming free {_days(r['days_to_maturity'])}: {r['instruments']}",
        client_copy=lambda r: f"{inr(r['maturing_value'])} matures {_days(r['days_to_maturity'])} ({r['instruments'].split(';')[0]}). Decide where it goes next.",
        client_cta="Review options",
    ),
    "onboarding_stuck": dict(
        title="Onboarding stuck", family="opportunity", prior=0.45, icon="🧱",
        blurb="Started MF onboarding in the app, stalled 48h+ at a step (usually the e-mandate).",
        rm_action="Call and unblock the exact step; screen-share if needed. Most stalls are the e-NACH bank page.",
        headline=lambda r: f"MF onboarding stalled at {STEP_LABEL.get(r['last_step'], r['last_step'])} for {int(r['hours_stuck']//24)} days — {inr(r['parked_cash'])} parked",
        client_copy=lambda r: f"You're one step away — finish {STEP_LABEL.get(r['last_step'], 'onboarding')} to start investing. It takes about 2 minutes.",
        client_cta="Resume onboarding",
    ),
    "churn_risk": dict(
        title="Churn risk", family="retention", prior=0.30, icon="🚨",
        blurb="Withdraw/redeem screens in the last 14 days, or app usage collapsing — and no RM contact for 3+ weeks.",
        rm_action="Call today, no agenda. Listen for the trigger (service issue, competitor, need for funds) before proposing anything.",
        headline=lambda r: (f"Opened withdraw screen {int(r['withdraw_events_14d'])}× in 14 days; no contact for {int(r['days_since_contact'])} days"
                            if r["trigger"] == "withdraw_intent" else
                            f"App usage down {int(round(100 - 100 * r['opens_last_14d'] / max(r['opens_prior_14d_avg'], 0.1)))}% vs prior month; no contact for {int(r['days_since_contact'])} days"),
        client_copy=None, client_cta=None,
    ),
    "sip_at_risk": dict(
        title="SIP at risk", family="retention", prior=0.55, icon="🔁",
        blurb="A failed debit, an e-mandate expiring within 30 days, or a SIP ending within 45 days.",
        rm_action="WhatsApp the one-tap mandate renewal link; for failed debits, check balance/limit and re-trigger.",
        headline=lambda r: f"{int(r['sips_affected'])} SIP{'s' if r['sips_affected'] > 1 else ''} worth {inr(r['monthly_amount'])}/mo at risk — {', '.join(REASON_LABEL.get(x.strip(), x) for x in r['reasons'].split(','))}",
        client_copy=lambda r: f"Your SIP of {inr(r['monthly_amount'])}/month needs attention ({', '.join(REASON_LABEL.get(x.strip(), x) for x in r['reasons'].split(','))}). Renew the mandate in one tap.",
        client_cta="Renew mandate",
    ),
    "concentration_risk": dict(
        title="Concentration risk", family="portfolio", prior=0.20, icon="🎯",
        blurb="One security above 20% of total AUM (ESOPs, promoter stakes, inherited blocks).",
        rm_action="Propose a phased diversification plan (tax-aware, over 4-6 quarters); never 'sell it all'.",
        headline=lambda r: f"{r['instrument']} is {r['pct_of_aum']}% of the portfolio ({inr(r['position_value'])})",
        client_copy=lambda r: f"{r['instrument']} makes up {r['pct_of_aum']}% of your portfolio. A phased plan can reduce single-stock risk without a big tax hit.",
        client_cta="See a phased plan",
    ),
    "allocation_drift": dict(
        title="Allocation drift", family="portfolio", prior=0.30, icon="⚖️",
        blurb="Invested equity share 12+ points away from the IPS target.",
        rm_action="Share a one-page rebalance proposal; frame it as sticking to the plan the client signed off.",
        headline=lambda r: f"Equity at {r['actual_equity_pct']}% vs {int(r['target_equity_pct'])}% target ({r['drift_pts']:+.0f} pts, {r['direction']}-allocated)",
        client_copy=lambda r: f"Your equity allocation is {r['actual_equity_pct']:.0f}% against a plan of {int(r['target_equity_pct'])}%. A small rebalance brings you back on track.",
        client_cta="Rebalance",
    ),
    "fund_overlap": dict(
        title="Fund overlap", family="portfolio", prior=0.25, icon="🧩",
        blurb="4+ equity funds in one category (or 9+ overall) — the same stocks bought several times over.",
        rm_action="Show the overlap; propose consolidating into the best 1-2 funds in the category.",
        headline=lambda r: f"{int(r['funds_in_category'])} {r['crowded_category']} funds — {inr(r['consolidatable_value'])} could be consolidated",
        client_copy=lambda r: f"You hold {int(r['funds_in_category'])} {r['crowded_category']} funds with heavily overlapping holdings. Consolidating simplifies tracking and can lower costs.",
        client_cta="See overlap",
    ),
    "tax_harvest": dict(
        title="Tax-loss harvest", family="portfolio", prior=0.30, icon="🧾",
        blurb="Unrealised equity losses (≥₹2 L) that could offset realised gains this FY.",
        rm_action="Coordinate with the client's CA; harvest and redeploy into a like-for-like fund the same day.",
        headline=lambda r: f"{inr(r['harvestable_loss'])} unrealised losses across {int(r['positions'])} position{'s' if r['positions'] > 1 else ''} — ~{inr(r['est_tax_offset_inr'])} tax offset",
        client_copy=lambda r: f"You have {inr(r['harvestable_loss'])} in unrealised losses that could offset gains this year (~{inr(r['est_tax_offset_inr'])} tax saved).",
        client_cta="Review with my RM",
    ),
    "overdue_review": dict(
        title="Overdue review", family="relationship", prior=0.15, icon="📅",
        blurb="No logged contact beyond the segment cadence (UHNI 35d / HNI 60d / Affluent 90d).",
        rm_action="A short check-in call or a personal note with the portfolio summary; book the review.",
        headline=lambda r: f"No contact for {int(r['days_since_contact'])} days (cadence {int(r['threshold_days'])}) — last touch {dmy(r['last_contact_on'])}",
        client_copy=None, client_cta=None,
    ),
}

FAMILY_LABEL = {"opportunity": "Opportunity", "retention": "Retention", "portfolio": "Portfolio health",
                "relationship": "Relationship"}

# How each signal turns evidence into money and urgency (shown in the explorer; mirrors the SQL).
MATH = {
    "liquidity_event": ("Latest balance ≥ ₹25 L, up ≥ ₹20 L and ≥ 2.5× vs 3 weeks ago", "the inflow amount",
                        "1.0 if it landed this week, 0.85 last week, 0.7 before"),
    "idle_cash": ("Balance ≥ ₹10 L, ≥ 5% of AUM, and its 6-week minimum ≥ 80% of today's", "the idle balance",
                  "0.8 if ≥ ₹50 L, else 0.6"),
    "buy_intent": ("≥ 2 views of one product in 10 days; not held; not discussed in 10 days; suitability + ticket gates",
                   "a plausible first ticket: between 1× and 3× the minimum, bounded by cash + 10% of AUM",
                   "1.0 if last view ≤ 2 days ago, 0.8 ≤ 5 days, else 0.6"),
    "product_closing": ("Closing-soon product ≤ 21 days out; ≥ 2 app views in 30 days or an RM deck-share in 45; gates as above",
                        "the product's minimum ticket", "1.0 if ≤ 7 days to close, 0.8 ≤ 14, else 0.6"),
    "lockin_maturity": ("lock_in_until between 7 days ago and 30 days ahead", "the maturing value",
                        "0.9 if ≤ 7 days, 0.75 ≤ 14, else 0.55"),
    "onboarding_stuck": ("Last onb_* step ≠ complete, ≥ 48h old, within 30 days", "typical first MF ticket by segment (₹5 L / ₹15 L / ₹50 L)",
                         "0.9 if stuck ≤ 4 days, 0.7 ≤ 10, else 0.5"),
    "churn_risk": ("Withdraw/redeem screens in 14 days, or opens ≤ 40% of prior-month rate; and no contact > 21 days",
                   "AUM × 30% assumed attrition", "1.0 if a redemption was initiated/completed, 0.8 if withdraw viewed, else 0.6"),
    "sip_at_risk": ("Failed debit, mandate expiring ≤ 30 days, or SIP ending ≤ 45 days", "12 × affected monthly SIP amount",
                    "1.0 if ≤ 7 days, 0.8 ≤ 14, 0.6 ≤ 30, else 0.45"),
    "concentration_risk": ("Largest single listed/unlisted security ≥ 20% of AUM", "the amount above a 10% ceiling",
                           "0.7 if ≥ 35% of AUM, else 0.5"),
    "allocation_drift": ("|invested equity % − IPS target| ≥ 12 points", "the amount to move to get back to target",
                         "0.6 if ≥ 20 points, else 0.45"),
    "fund_overlap": ("≥ 4 equity funds in one category, or ≥ 3 with ≥ 9 equity funds overall",
                     "everything in the crowded category except its largest fund", "0.4 flat"),
    "tax_harvest": ("Unrealised equity losses ≥ ₹1.5 L per position, ≥ ₹5 L and ≥ 1.5% of AUM in total",
                    "the harvestable loss", "0.9 within 45 days of 31 March, 0.7 within 90, else 0.35"),
    "overdue_review": ("Days since last logged contact > cadence (UHNI 35 / HNI 60 / Affluent 90)", "5% of AUM (relationship-risk proxy)",
                       "0.7 if ≥ 60 days over cadence, 0.55 ≥ 30, else 0.4"),
}


def sql_for(signal_type: str) -> str:
    with open(os.path.join(SIGNAL_DIR, f"{signal_type}.sql"), encoding="utf-8") as fh:
        return fh.read()


def _jsonable(v):
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    return v


def materialise_signals(con) -> None:
    """Run every signal's SQL and write the scored rows to the `signals` table."""
    con.execute("""
        CREATE OR REPLACE TABLE signals (
            signal_id          VARCHAR,
            client_id          VARCHAR,
            signal_type        VARCHAR,
            family             VARCHAR,
            headline           VARCHAR,
            rm_action          VARCHAR,
            client_copy        VARCHAR,
            client_cta         VARCHAR,
            impact_inr         DOUBLE,
            urgency            DOUBLE,
            conversion_prior   DOUBLE,
            expected_value_inr DOUBLE,
            deadline_on        DATE,
            evidence_json      VARCHAR
        )
    """)
    rows: list[tuple] = []
    seq = 0
    for stype, meta in CATALOG.items():
        res = con.execute(sql_for(stype))
        cols = [d[0] for d in res.description]
        for raw in res.fetchall():
            r = dict(zip(cols, raw))
            seq += 1
            impact = float(r["impact_inr"] or 0)
            urgency = float(r["urgency"] or 0)
            ev = impact * meta["prior"] * urgency
            evidence = {k: _jsonable(v) for k, v in r.items() if k not in ("client_id", "impact_inr", "urgency", "deadline_on")}
            client_copy = meta["client_copy"](r) if meta.get("client_copy") else None
            rows.append((
                f"SIG{seq:05d}", r["client_id"], stype, meta["family"], meta["headline"](r), meta["rm_action"],
                client_copy, meta.get("client_cta"), impact, urgency, meta["prior"], ev, r.get("deadline_on"),
                json.dumps(evidence),
            ))
    con.executemany("INSERT INTO signals VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)

    con.execute("""
        CREATE OR REPLACE VIEW v_client_priority AS
        SELECT s.client_id, c.rm_id, c.name, c.segment, c.risk_profile, a.aum, a.cash,
               COUNT(*)                                                 AS signal_count,
               SUM(s.expected_value_inr)                                AS expected_value_inr,
               SUM(s.impact_inr)                                        AS impact_inr,
               MAX(s.urgency)                                           AS max_urgency,
               list(s.signal_type ORDER BY s.expected_value_inr DESC)   AS signal_types,
               arg_max(s.signal_type, s.expected_value_inr)             AS top_signal,
               arg_max(s.headline, s.expected_value_inr)                AS top_headline,
               arg_max(s.rm_action, s.expected_value_inr)               AS top_action,
               MIN(s.deadline_on)                                       AS next_deadline,
               lc.days_since_contact
        FROM signals s
        JOIN clients c USING (client_id)
        JOIN v_client_aum a USING (client_id)
        LEFT JOIN v_last_contact lc USING (client_id)
        GROUP BY s.client_id, c.rm_id, c.name, c.segment, c.risk_profile, a.aum, a.cash, lc.days_since_contact
    """)


def signal_meta(stype: str) -> dict[str, Any]:
    m = CATALOG[stype]
    trigger, impact, urgency = MATH[stype]
    return {"type": stype, "title": m["title"], "family": m["family"], "family_label": FAMILY_LABEL[m["family"]],
            "prior": m["prior"], "icon": m["icon"], "blurb": m["blurb"], "rm_action": m["rm_action"],
            "trigger": trigger, "impact_rule": impact, "urgency_rule": urgency}


def catalog_list() -> list[dict[str, Any]]:
    return [signal_meta(k) for k in CATALOG]
