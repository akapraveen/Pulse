-- TAX-LOSS HARVEST
-- Equity positions on unrealised losses (>= ₹1.5 L each) that add up to something material -
-- at least ₹5 L and 1.5% of the book - and could offset realised gains this FY.
-- Urgency climbs as 31 March approaches.
WITH fy_end AS (
    SELECT make_date(year(as_of()) + CASE WHEN month(as_of()) > 3 THEN 1 ELSE 0 END, 3, 31) AS fy_end_on
),
losses AS (
    SELECT client_id, instrument, asset_class, invested_value, current_value,
           invested_value - current_value                 AS unrealised_loss,
           datediff('day', purchase_date, as_of())        AS holding_days
    FROM holdings
    WHERE asset_class IN ('Equity MF', 'Direct Equity')
      AND invested_value - current_value >= 150000
)
SELECT
    l.client_id,
    SUM(l.unrealised_loss)                                                  AS impact_inr,
    CASE WHEN datediff('day', as_of(), f.fy_end_on) <= 45 THEN 0.9
         WHEN datediff('day', as_of(), f.fy_end_on) <= 90 THEN 0.7 ELSE 0.35 END AS urgency,
    f.fy_end_on                                                             AS deadline_on,
    COUNT(*)                                                                AS positions,
    SUM(l.unrealised_loss)                                                  AS harvestable_loss,
    ROUND(SUM(CASE WHEN l.holding_days > 365 THEN l.unrealised_loss * 0.125
                   ELSE l.unrealised_loss * 0.20 END))                      AS est_tax_offset_inr,
    ROUND(100.0 * SUM(l.unrealised_loss) / a.aum, 1)                        AS pct_of_aum,
    string_agg(l.instrument || ' (-' || ROUND(l.unrealised_loss / 100000.0, 1) || ' L)', '; '
               ORDER BY l.unrealised_loss DESC)                             AS positions_detail
FROM losses l
JOIN v_client_aum a USING (client_id)
CROSS JOIN fy_end f
GROUP BY l.client_id, f.fy_end_on, a.aum
HAVING SUM(l.unrealised_loss) >= GREATEST(500000, 0.015 * a.aum)
ORDER BY impact_inr DESC
