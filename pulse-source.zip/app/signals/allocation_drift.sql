-- ALLOCATION DRIFT
-- Invested equity share vs the client's IPS target. Measured on invested assets only,
-- so parked cash is handled by the idle-cash signal and this one owns the *mix*.
-- 12 points of drift is the review threshold; 20+ is a rebalance conversation.
SELECT
    a.client_id,
    ABS(a.equity_pct_invested - c.ips_equity_target) / 100.0 * a.invested_aum   AS impact_inr,   -- amount to move
    CASE WHEN ABS(a.equity_pct_invested - c.ips_equity_target) >= 20 THEN 0.6 ELSE 0.45 END AS urgency,
    NULL::DATE                                                                  AS deadline_on,
    ROUND(a.equity_pct_invested, 1)                                             AS actual_equity_pct,
    c.ips_equity_target                                                         AS target_equity_pct,
    ROUND(a.equity_pct_invested - c.ips_equity_target, 1)                       AS drift_pts,
    CASE WHEN a.equity_pct_invested > c.ips_equity_target THEN 'over' ELSE 'under' END AS direction,
    c.risk_profile
FROM v_client_aum a
JOIN clients c USING (client_id)
WHERE a.invested_aum > 0
  AND ABS(a.equity_pct_invested - c.ips_equity_target) >= 12
  AND a.client_id NOT IN (SELECT client_id FROM v_mid_onboarding)
ORDER BY impact_inr DESC
