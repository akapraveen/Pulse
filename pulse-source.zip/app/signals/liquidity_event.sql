-- LIQUIDITY EVENT
-- Cash balance jumped 2.5x+ (and >= ₹20 L) versus three weeks ago: a bonus, ESOP sale,
-- property or business proceeds just landed. The client is deciding where it goes *this week* -
-- and every bank they hold an account with is calling.
WITH snaps AS (
    SELECT client_id, as_of, ledger_balance,
           LAG(ledger_balance, 1) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_1w_ago,
           LAG(ledger_balance, 2) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_2w_ago,
           LAG(ledger_balance, 3) OVER (PARTITION BY client_id ORDER BY as_of) AS bal_3w_ago,
           ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY as_of DESC)      AS rn
    FROM cash_snapshots
),
latest AS (
    SELECT *, ledger_balance - bal_3w_ago AS inflow_inr,
           CASE WHEN ledger_balance - bal_1w_ago >= 0.8 * (ledger_balance - bal_3w_ago) THEN 'this week'
                WHEN ledger_balance - bal_2w_ago >= 0.8 * (ledger_balance - bal_3w_ago) THEN 'last week'
                ELSE '2 weeks ago' END AS landed
    FROM snaps WHERE rn = 1
)
SELECT
    client_id,
    inflow_inr                                                              AS impact_inr,
    CASE landed WHEN 'this week' THEN 1.0 WHEN 'last week' THEN 0.85 ELSE 0.7 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    ledger_balance                                                          AS current_cash,
    bal_3w_ago                                                              AS cash_3w_ago,
    inflow_inr,
    landed
FROM latest
WHERE ledger_balance >= 2500000
  AND inflow_inr >= 2000000
  AND ledger_balance >= 2.5 * GREATEST(bal_3w_ago, 1)
ORDER BY impact_inr DESC
