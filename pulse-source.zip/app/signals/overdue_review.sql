-- OVERDUE REVIEW
-- Relationship hygiene: no logged RM contact beyond the segment's cadence
-- (UHNI 35 days, HNI 60, Affluent 90). Impact is a relationship-risk proxy (5% of AUM),
-- so the biggest silent books rise to the top rather than the longest silences.
WITH cadence AS (
    SELECT c.client_id, c.segment, c.last_review_on,
           CASE c.segment WHEN 'UHNI' THEN 35 WHEN 'HNI' THEN 60 ELSE 90 END AS threshold_days,
           COALESCE(lc.days_since_contact, 999)                              AS days_since_contact,
           lc.last_contact_on
    FROM clients c
    LEFT JOIN v_last_contact lc USING (client_id)
)
SELECT
    k.client_id,
    a.aum * 0.05                                                            AS impact_inr,
    CASE WHEN k.days_since_contact - k.threshold_days >= 60 THEN 0.7
         WHEN k.days_since_contact - k.threshold_days >= 30 THEN 0.55 ELSE 0.4 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    k.last_contact_on,
    k.days_since_contact,
    k.threshold_days,
    k.days_since_contact - k.threshold_days                                 AS days_over,
    k.last_review_on,
    datediff('day', k.last_review_on, as_of())                              AS days_since_review
FROM cadence k
JOIN v_client_aum a USING (client_id)
WHERE k.days_since_contact > k.threshold_days
ORDER BY impact_inr DESC
