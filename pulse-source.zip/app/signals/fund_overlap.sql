-- FUND OVERLAP
-- Four or more equity funds in the same category (or 9+ equity funds overall): the same
-- underlying stocks bought several times over, with several expense ratios.
-- Impact = everything in the crowded category except its largest fund (the consolidation amount).
WITH by_category AS (
    SELECT client_id, category,
           COUNT(*)                                            AS funds_in_category,
           SUM(current_value)                                  AS category_value,
           SUM(current_value) - MAX(current_value)             AS consolidatable_value,
           string_agg(instrument, '; ' ORDER BY current_value DESC) AS funds
    FROM holdings
    WHERE asset_class = 'Equity MF'
    GROUP BY client_id, category
),
totals AS (
    SELECT client_id, COUNT(*) AS equity_funds
    FROM holdings WHERE asset_class = 'Equity MF' GROUP BY client_id
),
crowded AS (
    SELECT b.*, t.equity_funds,
           ROW_NUMBER() OVER (PARTITION BY b.client_id ORDER BY b.funds_in_category DESC, b.category_value DESC) AS rn
    FROM by_category b
    JOIN totals t USING (client_id)
    WHERE b.funds_in_category >= 4 OR (b.funds_in_category >= 3 AND t.equity_funds >= 9)
)
SELECT
    client_id,
    consolidatable_value                                                    AS impact_inr,
    0.4                                                                     AS urgency,
    NULL::DATE                                                              AS deadline_on,
    category                                                                AS crowded_category,
    funds_in_category,
    category_value,
    consolidatable_value,
    equity_funds                                                            AS total_equity_funds,
    funds
FROM crowded
WHERE rn = 1
ORDER BY impact_inr DESC
