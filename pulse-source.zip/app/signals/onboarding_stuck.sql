-- ONBOARDING STUCK
-- Started MF onboarding in the app, hasn't finished, and the last step is 48h+ old
-- (within the last 30 days). The step they stalled on tells the RM exactly what to unblock -
-- almost always the e-mandate. Impact = the segment's typical first MF ticket.
WITH steps AS (
    SELECT client_id, session_id, event_name, ts,
           ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY ts DESC) AS rn
    FROM app_events
    WHERE event_name LIKE 'onb_%'
),
latest AS (
    SELECT client_id, session_id, event_name AS last_step, ts AS last_step_at
    FROM steps WHERE rn = 1
),
journey AS (
    SELECT l.client_id, l.last_step, l.last_step_at, MIN(s.ts) AS started_at,
           datediff('hour', l.last_step_at, as_of()::TIMESTAMP + INTERVAL 23 HOUR) AS hours_stuck
    FROM latest l
    JOIN steps s ON s.client_id = l.client_id AND s.session_id = l.session_id
    GROUP BY 1, 2, 3
)
SELECT
    j.client_id,
    CASE c.segment WHEN 'UHNI' THEN 5000000 WHEN 'HNI' THEN 1500000 ELSE 500000 END AS impact_inr,
    CASE WHEN j.hours_stuck <= 96 THEN 0.9 WHEN j.hours_stuck <= 240 THEN 0.7 ELSE 0.5 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    j.last_step,
    j.last_step_at,
    j.started_at,
    j.hours_stuck,
    a.cash                                                                  AS parked_cash
FROM journey j
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE j.last_step <> 'onb_complete'
  AND j.hours_stuck >= 48
  AND j.last_step_at >= as_of() - INTERVAL 30 DAY
ORDER BY urgency DESC, impact_inr DESC
