-- IDLE CASH
-- A large balance that has sat in the wealth account for 6+ weeks.
-- Money that isn't working costs the client ~3.5-4% a year vs a liquid/arbitrage fund,
-- and it is the cheapest AUM the firm can win: it's already here.
-- Clients mid-way through MF onboarding are excluded: that signal owns the conversation.
WITH latest AS (
    SELECT client_id, ledger_balance AS cash
    FROM cash_snapshots
    WHERE as_of = (SELECT MAX(as_of) FROM cash_snapshots)
),
six_weeks AS (
    SELECT client_id, MIN(ledger_balance) AS min_balance_6w
    FROM cash_snapshots
    WHERE as_of >= as_of() - INTERVAL 42 DAY
    GROUP BY client_id
)
SELECT
    l.client_id,
    l.cash                                              AS impact_inr,
    CASE WHEN l.cash >= 5000000 THEN 0.8 ELSE 0.6 END   AS urgency,
    NULL::DATE                                          AS deadline_on,
    l.cash                                              AS idle_cash,
    ROUND(100.0 * l.cash / a.aum, 1)                    AS pct_of_aum,
    6                                                   AS weeks_idle,
    ROUND(l.cash * 0.038)                               AS annual_drag_inr   -- ~3.8% yield gap vs a liquid fund
FROM latest l
JOIN six_weeks s USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE l.cash >= 1000000                                 -- at least ₹10 L
  AND s.min_balance_6w >= 0.8 * l.cash                  -- it has been sitting there, not just landed
  AND l.cash >= 0.05 * a.aum                            -- material relative to the book
  AND l.client_id NOT IN (SELECT client_id FROM v_mid_onboarding)
ORDER BY impact_inr DESC
