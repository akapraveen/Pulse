-- SIP AT RISK
-- Recurring flows about to stop: a failed debit, an e-mandate expiring within 30 days,
-- or a SIP reaching its end date within 45 days. Impact = 12 months of the affected SIPs.
WITH at_risk AS (
    SELECT sip_id, client_id, instrument, amount,
           CASE WHEN last_debit_status = 'Failed'                          THEN 'debit_failed'
                WHEN mandate_expiry <= as_of() + INTERVAL 30 DAY           THEN 'mandate_expiring'
                WHEN end_date       <= as_of() + INTERVAL 45 DAY           THEN 'sip_ending' END AS reason,
           CASE WHEN last_debit_status = 'Failed'                          THEN 0
                WHEN mandate_expiry <= as_of() + INTERVAL 30 DAY           THEN datediff('day', as_of(), mandate_expiry)
                ELSE datediff('day', as_of(), end_date) END               AS days_left
    FROM sips
    WHERE status = 'Active'
      AND (last_debit_status = 'Failed'
           OR mandate_expiry <= as_of() + INTERVAL 30 DAY
           OR end_date <= as_of() + INTERVAL 45 DAY)
)
SELECT
    client_id,
    SUM(amount) * 12                                                         AS impact_inr,
    CASE WHEN MIN(days_left) <= 7 THEN 1.0 WHEN MIN(days_left) <= 14 THEN 0.8
         WHEN MIN(days_left) <= 30 THEN 0.6 ELSE 0.45 END                     AS urgency,
    as_of() + to_days(MIN(days_left)::INTEGER)                               AS deadline_on,
    COUNT(*)                                                                 AS sips_affected,
    SUM(amount)                                                              AS monthly_amount,
    string_agg(DISTINCT reason, ', ')                                        AS reasons,
    MIN(days_left)                                                           AS days_left,
    string_agg(instrument, '; ')                                             AS instruments
FROM at_risk
GROUP BY client_id
ORDER BY urgency DESC, impact_inr DESC
