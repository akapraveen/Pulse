-- CHURN RISK
-- Behavioural early warning from the client app: withdraw/redeem screens in the last 14 days,
-- or app usage collapsing to <40% of the prior month's rate - and no RM contact for 3+ weeks.
-- Impact = AUM at risk, discounted by an assumed 30% attrition if unaddressed.
WITH activity AS (
    SELECT client_id,
           COUNT(*) FILTER (WHERE event_name IN ('view_withdraw', 'initiate_redeem')
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS withdraw_events_14d,
           COUNT(*) FILTER (WHERE event_name = 'initiate_redeem'
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS redeem_initiated_14d,
           COUNT(*) FILTER (WHERE event_name = 'app_open'
                              AND ts >= as_of() - INTERVAL 14 DAY)                      AS opens_last_14d,
           COUNT(*) FILTER (WHERE event_name = 'app_open'
                              AND ts >= as_of() - INTERVAL 42 DAY
                              AND ts <  as_of() - INTERVAL 14 DAY) / 2.0                AS opens_prior_14d_avg
    FROM app_events
    GROUP BY client_id
),
redemptions AS (
    SELECT client_id, SUM(amount) AS redeemed_30d
    FROM transactions
    WHERE txn_type = 'Redeem' AND status = 'Completed' AND txn_date >= as_of() - INTERVAL 30 DAY
    GROUP BY client_id
)
SELECT
    e.client_id,
    a.aum * 0.30                                                            AS impact_inr,
    CASE WHEN e.redeem_initiated_14d > 0 OR COALESCE(r.redeemed_30d, 0) > 0 THEN 1.0
         WHEN e.withdraw_events_14d > 0 THEN 0.8 ELSE 0.6 END               AS urgency,
    NULL::DATE                                                              AS deadline_on,
    CASE WHEN e.withdraw_events_14d > 0 THEN 'withdraw_intent' ELSE 'engagement_drop' END AS trigger,
    e.withdraw_events_14d,
    e.redeem_initiated_14d,
    e.opens_last_14d,
    ROUND(e.opens_prior_14d_avg, 1)                                         AS opens_prior_14d_avg,
    COALESCE(r.redeemed_30d, 0)                                             AS redeemed_30d,
    lc.days_since_contact
FROM activity e
JOIN v_client_aum a USING (client_id)
LEFT JOIN v_last_contact lc USING (client_id)
LEFT JOIN redemptions r USING (client_id)
WHERE (e.withdraw_events_14d >= 1
       OR (e.opens_prior_14d_avg >= 3 AND e.opens_last_14d <= 0.4 * e.opens_prior_14d_avg))
  AND COALESCE(lc.days_since_contact, 999) > 21
ORDER BY urgency DESC, impact_inr DESC
