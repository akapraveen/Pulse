-- BUY INTENT
-- The client keeps opening one exclusive product (PMS / AIF / unlisted) in the app - 2+ views
-- in 10 days - hasn't invested in it, and the RM hasn't discussed it in the last 10 days.
-- Hard gates: suitability (risk profile) and ticket size (AUM >= 3x minimum) - never surface
-- a product the client can't or shouldn't buy. Products closing soon are handled by product_closing.
WITH views AS (
    SELECT client_id, product_id,
           COUNT(*)                     AS views_10d,
           COUNT(DISTINCT session_id)   AS sessions_10d,
           MAX(ts)                      AS last_view_ts
    FROM app_events
    WHERE event_name = 'view_product'
      AND product_id IS NOT NULL AND product_id <> ''
      AND ts >= as_of() - INTERVAL 10 DAY
    GROUP BY client_id, product_id
    HAVING COUNT(*) >= 2
),
ranked AS (
    SELECT v.*, ROW_NUMBER() OVER (PARTITION BY v.client_id ORDER BY v.views_10d DESC, v.last_view_ts DESC) AS rn
    FROM views v
    JOIN products p USING (product_id)
    WHERE p.status <> 'Closing Soon'
)
SELECT
    r.client_id,
    GREATEST(p.min_ticket, LEAST(a.cash + 0.10 * a.aum, 3 * p.min_ticket))  AS impact_inr,   -- plausible first ticket
    CASE WHEN datediff('day', r.last_view_ts::DATE, as_of()) <= 2 THEN 1.0
         WHEN datediff('day', r.last_view_ts::DATE, as_of()) <= 5 THEN 0.8 ELSE 0.6 END AS urgency,
    NULL::DATE                                                              AS deadline_on,
    r.product_id,
    p.name                                                                  AS product_name,
    p.type                                                                  AS product_type,
    p.min_ticket,
    r.views_10d,
    r.sessions_10d,
    r.last_view_ts,
    lc.days_since_contact,
    a.cash                                                                  AS available_cash
FROM ranked r
JOIN products p USING (product_id)
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
LEFT JOIN v_last_contact lc USING (client_id)
WHERE r.rn = 1
  AND list_contains(string_split(p.suitable_for, '|'), c.risk_profile)          -- suitability gate
  AND a.aum >= 3 * p.min_ticket                                                 -- ticket-size gate
  AND NOT EXISTS (SELECT 1 FROM holdings h
                  WHERE h.client_id = r.client_id AND h.instrument = p.name)    -- not already invested
  AND NOT EXISTS (SELECT 1 FROM interactions i
                  WHERE i.client_id = r.client_id AND i.product_id = r.product_id
                    AND i.occurred_on >= as_of() - INTERVAL 10 DAY)             -- RM hasn't already discussed it
ORDER BY urgency DESC, r.views_10d DESC
