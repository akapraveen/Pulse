-- CONCENTRATION RISK
-- A single listed or unlisted security above 20% of the client's total AUM
-- (ESOPs, promoter stakes, inherited blocks). Impact = the amount above a 10% single-name ceiling.
WITH positions AS (
    SELECT h.client_id, h.instrument, h.sector, h.asset_class, h.current_value, a.aum,
           100.0 * h.current_value / a.aum AS pct_of_aum,
           ROW_NUMBER() OVER (PARTITION BY h.client_id ORDER BY h.current_value DESC) AS rn
    FROM holdings h
    JOIN v_client_aum a USING (client_id)
    WHERE h.asset_class IN ('Direct Equity', 'Unlisted')
)
SELECT
    client_id,
    current_value - 0.10 * aum                            AS impact_inr,
    CASE WHEN pct_of_aum >= 35 THEN 0.7 ELSE 0.5 END      AS urgency,
    NULL::DATE                                            AS deadline_on,
    instrument,
    sector,
    asset_class,
    ROUND(pct_of_aum, 1)                                  AS pct_of_aum,
    current_value                                         AS position_value
FROM positions
WHERE rn = 1 AND pct_of_aum >= 20
ORDER BY impact_inr DESC
