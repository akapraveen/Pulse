-- PRODUCT CLOSING
-- An exclusive product the client has shown real interest in (2+ in-app views in 30 days, or an RM
-- shared the deck in the last 45 days) closes its window within 21 days. Same suitability and
-- ticket-size gates as buy_intent. Impact = minimum ticket.
WITH closing AS (
    SELECT * FROM products
    WHERE status = 'Closing Soon'
      AND closes_on BETWEEN as_of() AND as_of() + INTERVAL 21 DAY
),
interest AS (
    SELECT client_id, product_id, ts AS seen_at, 'app_view' AS source
    FROM app_events
    WHERE event_name = 'view_product' AND ts >= as_of() - INTERVAL 30 DAY
    UNION ALL
    SELECT client_id, product_id, occurred_on::TIMESTAMP, 'rm_shared_deck'
    FROM interactions
    WHERE product_id IS NOT NULL AND product_id <> '' AND occurred_on >= as_of() - INTERVAL 45 DAY
),
candidates AS (
    SELECT i.client_id, p.product_id, p.name AS product_name, p.type AS product_type, p.min_ticket, p.closes_on,
           p.suitable_for, MAX(i.seen_at) AS last_interest_at, COUNT(*) AS interest_touches,
           COUNT(*) FILTER (WHERE i.source = 'rm_shared_deck') AS rm_touches,
           ROW_NUMBER() OVER (PARTITION BY i.client_id ORDER BY p.closes_on) AS rn
    FROM interest i
    JOIN closing p USING (product_id)
    GROUP BY 1, 2, 3, 4, 5, 6, 7
    HAVING COUNT(*) >= 2 OR COUNT(*) FILTER (WHERE i.source = 'rm_shared_deck') >= 1   -- one stray tap isn't interest
)
SELECT
    k.client_id,
    k.min_ticket                                                            AS impact_inr,
    CASE WHEN datediff('day', as_of(), k.closes_on) <= 7 THEN 1.0
         WHEN datediff('day', as_of(), k.closes_on) <= 14 THEN 0.8 ELSE 0.6 END AS urgency,
    k.closes_on                                                             AS deadline_on,
    k.product_id,
    k.product_name,
    k.product_type,
    k.min_ticket,
    datediff('day', as_of(), k.closes_on)                                   AS days_to_close,
    k.interest_touches,
    k.rm_touches,
    k.last_interest_at
FROM candidates k
JOIN clients c USING (client_id)
JOIN v_client_aum a USING (client_id)
WHERE k.rn = 1
  AND list_contains(string_split(k.suitable_for, '|'), c.risk_profile)
  AND a.aum >= 3 * k.min_ticket
  AND NOT EXISTS (SELECT 1 FROM holdings h WHERE h.client_id = k.client_id AND h.instrument = k.product_name)
ORDER BY urgency DESC, impact_inr DESC
