-- LOCK-IN / MATURITY
-- Money about to come free: ELSS lock-ins ending, PMS exit-load windows closing,
-- FDs maturing (last 7 days to next 30). The natural moment for a re-deployment conversation
-- and the moment competitor banks call about the FD.
WITH maturing AS (
    SELECT client_id, instrument, asset_class, category, current_value, lock_in_until,
           datediff('day', as_of(), lock_in_until) AS days_to_maturity
    FROM holdings
    WHERE lock_in_until IS NOT NULL
      AND lock_in_until BETWEEN as_of() - INTERVAL 7 DAY AND as_of() + INTERVAL 30 DAY
)
SELECT
    client_id,
    SUM(current_value)                                                       AS impact_inr,
    CASE WHEN MIN(days_to_maturity) <= 7 THEN 0.9
         WHEN MIN(days_to_maturity) <= 14 THEN 0.75 ELSE 0.55 END            AS urgency,
    MIN(lock_in_until)                                                       AS deadline_on,
    COUNT(*)                                                                 AS holdings_maturing,
    string_agg(instrument || ' (' || asset_class || ')', '; ' ORDER BY lock_in_until) AS instruments,
    MIN(days_to_maturity)                                                    AS days_to_maturity,
    SUM(current_value)                                                       AS maturing_value
FROM maturing
GROUP BY client_id
ORDER BY urgency DESC, impact_inr DESC
